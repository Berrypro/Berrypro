<?php

// PHP time zone for all date/time functions
date_default_timezone_set('Africa/Nairobi');

// Enable full error reporting (for development)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$host = 'localhost';
$db   = 'u973594995_flexhela'; // Your database name
$user = 'u973594995_flexhela'; // Your database user
$pass = '20941000Jj.';            // Your database password
$charset = 'utf8mb4';

// DSN and PDO options
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Show errors as exceptions
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false, // Safer for SQL
];

// Try to connect
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // Only show detailed errors during development
    echo "Database connection failed: " . $e->getMessage();
    exit;
}
