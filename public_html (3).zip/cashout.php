<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$betId = $input['bet_id'] ?? 0;
$payout = $input['payout'] ?? 0;
$multiplier = $input['multiplier'] ?? 0;

try {
    $pdo->beginTransaction();
    
    // Verify bet belongs to user and is pending
    $stmt = $pdo->prepare("
        SELECT id FROM crash_bets 
        WHERE id = ? AND user_id = ? AND status = 'pending'
        LIMIT 1 FOR UPDATE
    ");
    $stmt->execute([$betId, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        throw new Exception("Invalid bet or already settled");
    }
    
    // Update bet status
    $stmt = $pdo->prepare("
        UPDATE crash_bets 
        SET cashed_out_at = ?, payout = ?, status = 'cashed_out' 
        WHERE id = ?
    ");
    $stmt->execute([$multiplier, $payout, $betId]);
    
    // Credit to wallet only
    $stmt = $pdo->prepare("
        UPDATE Users 
        SET wallet_balance = wallet_balance + ?, 
            has_active_bet = FALSE 
        WHERE id = ?
    ");
    $stmt->execute([$payout, $_SESSION['user_id']]);
    
    $pdo->commit();
    
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>