<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$validDays = [1, 2, 4, 6]; // M, T, TH, SAT
$currentDay = date('N');

$stmt = $pdo->prepare("SELECT survey_balance FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$survey_balance = number_format($user['survey_balance'], 2);

$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT COUNT(*) FROM survey_results WHERE user_id = ? AND DATE(submitted_at) = ?");
$stmt->execute([$user_id, $today]);
$alreadyTaken = $stmt->fetchColumn() > 0;

$surveyAvailable = in_array($currentDay, $validDays);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Take Survey</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #1a1a1a;
      color: #fff;
      text-align: center;
      padding: 30px 15px;
      margin: 0;
    }

    h1 {
      font-size: 6vw;
      margin-bottom: 15px;
      color: #ffffff;
    }

    p {
      font-size: 4.5vw;
      margin: 8px 0;
    }

    .balance {
      font-size: 5vw;
      color: #00ffae;
      font-weight: bold;
    }

    .notice {
      background: #222;
      border-radius: 10px;
      padding: 15px;
      max-width: 600px;
      margin: 20px auto;
      font-size: 4vw;
      color: #facc15;
      text-align: left;
    }

    ul {
      padding-left: 20px;
      margin: 10px 0 0 0;
    }

    li {
      margin-bottom: 8px;
    }

    a.button {
      display: block;
      background: #00b894;
      color: #fff;
      padding: 14px;
      text-decoration: none;
      font-size: 4.5vw;
      border-radius: 8px;
      margin: 20px auto 10px;
      max-width: 300px;
    }

    a.button:hover {
      background: #019875;
    }

    .message {
      margin-top: 20px;
      color: #f87171;
      font-size: 4.2vw;
      font-weight: bold;
    }

    @media (min-width: 600px) {
      h1 { font-size: 28px; }
      p, .balance, .notice, .message { font-size: 18px; }
      a.button { font-size: 18px; }
    }
  </style>
</head>
<body>

<?php
if (isset($_SESSION['survey_message'])) {
    $msg = addslashes($_SESSION['survey_message']);
    echo "<script>alert('$msg');</script>";
    unset($_SESSION['survey_message']);
}
?>

<h1>Daily Survey</h1>
<p class="balance">Earnings: KES <?= $survey_balance ?></p>

<div class="notice">
  <strong>Instructions</strong>
  <ul>
    <li>Answer 10 questions in 60 seconds.</li>
    <li>Earn <strong>KES 2</strong> per correct answer.</li>
    <li>If time ends, the survey auto-submits.</li><br><br>
    <p>NOTE:</p><br>
    <li>surveys are always available on -</li>
    <li>Monday</li>
    <li>Tuesday</li>
    <li>Thursday</li>
    <li>Saturday</li>
  </ul>
</div>

<?php if ($surveyAvailable && !$alreadyTaken): ?>
  <a href="survey_page.php" class="button">Start Survey</a>
<?php else: ?>
  <div class="message">
    You've either completed today's survey or it's not available.<br>
    Visit on <strong>Monday, Tuesday, Thursday, or Saturday</strong>.
  </div>
<?php endif; ?>

<a href="dashboard.php" class="button" style="background:#6366f1;">Back to Dashboard</a>

</body>
</html>
