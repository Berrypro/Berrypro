<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['referred_by'])) {
    $user_id = (int) $_POST['user_id'];
    $new_upline = trim($_POST['referred_by']);

    // === Start: DEACTIVATE LOGIC (before updating referred_by) ===
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user && $user['status'] === 'active') {
        $pdo->prepare("UPDATE Users SET status = 'inactive', activated_at = NULL WHERE id = ?")->execute([$user_id]);

        $referred_by = $user['referred_by'];
        if (!empty($referred_by)) {
            // Get level 1 upline user info
            $stmt = $pdo->prepare("SELECT id, referred_by FROM Users WHERE username = ?");
            $stmt->execute([$referred_by]);
            $level1 = $stmt->fetch();

            if ($level1) {
                // Reverse level 1 bonus
                $check = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 1");
                $check->execute([$level1['id'], $user_id]);

                if ($check->fetchColumn() > 0) {
                    $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance - 50, total_earned = total_earned - 50, activated_referrals = activated_referrals - 1 WHERE id = ?")
                        ->execute([$level1['id']]);

                    $pdo->prepare("DELETE FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 1")
                        ->execute([$level1['id'], $user_id]);
                }

                // Reverse level 2 bonus if applicable
                if (!empty($level1['referred_by'])) {
                    $stmt = $pdo->prepare("SELECT id FROM Users WHERE username = ?");
                    $stmt->execute([$level1['referred_by']]);
                    $level2 = $stmt->fetch();

                    if ($level2) {
                        $check = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 2");
                        $check->execute([$level2['id'], $user_id]);

                        if ($check->fetchColumn() > 0) {
                            $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance - 20, total_earned = total_earned - 20 WHERE id = ?")
                                ->execute([$level2['id']]);

                            $pdo->prepare("DELETE FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 2")
                                ->execute([$level2['id'], $user_id]);
                        }
                    }
                }
            }
        }
    }
    // === End: Deactivate Logic ===

    // ✅ Validate new upline (if any)
    if (!empty($new_upline)) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM Users WHERE username = ?");
        $stmt->execute([$new_upline]);
        if ($stmt->fetchColumn() == 0) {
            $_SESSION['upline_error'] = "Username '$new_upline' does not exist.";
            header("Location: users.php");
            exit;
        }
    }

    // ✅ Update the upline
    $stmt = $pdo->prepare("UPDATE Users SET referred_by = ? WHERE id = ?");
    $stmt->execute([$new_upline, $user_id]);

    $_SESSION['upline_success'] = "Upline updated successfully after user was deactivated.";
}

header("Location: users.php");
exit;
