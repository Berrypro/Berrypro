<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$actionMsg = '';

// Handle activation/deactivation and amount update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'], $_POST['user_id']) && in_array($_POST['action'], ['activate', 'deactivate'])) {
        $user_id = (int)$_POST['user_id'];
        $newStatus = $_POST['action'] === 'activate' ? 'active' : 'inactive';

        $stmt = $pdo->prepare("UPDATE Users SET status = ? WHERE id = ?");
        if ($stmt->execute([$newStatus, $user_id])) {
            $actionMsg = "User ID $user_id set to $newStatus.";
        } else {
            $actionMsg = "Failed to update user status.";
        }
    }

    if (isset($_POST['update_amount'])) {
        $log_id = $_POST['log_id'] ?? null;
        $amount_paid = $_POST['amount_paid'] ?? null;

        if ($log_id !== null && $amount_paid !== null && is_numeric($amount_paid)) {
            $stmt = $pdo->prepare("UPDATE payments SET amount_paid = ?, status = 'confirmed' WHERE id = ?");
            if ($stmt->execute([$amount_paid, $log_id])) {
                $stmt2 = $pdo->prepare("SELECT msisdn, phone FROM payments WHERE id = ?");
                $stmt2->execute([$log_id]);
                $payment = $stmt2->fetch(PDO::FETCH_ASSOC);

                $msisdn = $payment['msisdn'] ?? null;
                $phone = $payment['phone'] ?? null;

                if ($msisdn) {
                    $stmt3 = $pdo->prepare("SELECT SUM(amount_paid) AS total_paid FROM payments WHERE msisdn = ? AND status = 'confirmed'");
                    $stmt3->execute([$msisdn]);
                    $total = $stmt3->fetch(PDO::FETCH_ASSOC);

                    $stmt4 = $pdo->prepare("SELECT id, phone, msisdn FROM Users WHERE phone = ? OR msisdn = ?");
                    $stmt4->execute([$msisdn, $msisdn]);
                    $user = $stmt4->fetch(PDO::FETCH_ASSOC);

                    if ($user) {
                        if ($total && $total['total_paid'] >= 100) {
                            $stmt5 = $pdo->prepare("UPDATE Users SET status = 'active' WHERE id = ?");
                            $stmt5->execute([$user['id']]);
                            $actionMsg = "Payment updated and user (ID {$user['id']}) activated (total paid: {$total['total_paid']} KES).";
                        } else {
                            $actionMsg = "Payment updated and confirmed (total paid less than 100 KES).";
                        }
                    } else {
                        $actionMsg = "Payment updated, but no user found.";
                    }
                } else {
                    $actionMsg = "Payment updated, but no msisdn found.";
                }
            } else {
                $actionMsg = "Failed to update payment amount.";
            }
        } else {
            $actionMsg = "Invalid data for payment update.";
        }
    }
}

// Search logic
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $sql = "SELECT p.*, u.status AS user_status, u.username, u.phone AS user_phone, u.msisdn AS user_msisdn
            FROM payments p
            LEFT JOIN Users u ON p.user_id = u.id
            WHERE u.username LIKE :search OR u.phone LIKE :search OR u.msisdn LIKE :search OR p.msisdn LIKE :search
            ORDER BY p.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['search' => "%$search%"]);
} else {
    $sql = "SELECT p.*, u.status AS user_status, u.username, u.phone AS user_phone, u.msisdn AS user_msisdn
            FROM payments p
            LEFT JOIN Users u ON p.user_id = u.id
            ORDER BY p.created_at DESC";
    $stmt = $pdo->query($sql);
}
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin Panel - Payments</title>
<style>
    body { font-family: Arial, sans-serif; background: #f9f9f9; padding: 20px; }
    table { border-collapse: collapse; width: 100%; background: #fff; }
    th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
    th { background: #333; color: #fff; }
    .btn { padding: 5px 10px; border: none; border-radius: 3px; cursor: pointer; }
    .activate { background: #27ae60; color: white; }
    .deactivate { background: #c0392b; color: white; }
    .status-active { color: green; font-weight: bold; }
    .status-inactive { color: red; font-weight: bold; }
    .msg { margin-bottom: 20px; padding: 10px; background: #dff0d8; border: 1px solid #3c763d; color: #3c763d; border-radius: 4px; }
    form.inline { display: inline-block; margin: 0; }
    input[type=number] { width: 80px; padding: 5px; }
    input[type=text] { padding: 5px; width: 300px; }
    button { font-weight: bold; }
</style>
</head>
<body>
<h1>Admin Panel - Payments</h1>

<?php if (!empty($actionMsg)): ?>
    <div class="msg"><?= htmlspecialchars($actionMsg) ?></div>
<?php endif; ?>

<form method="GET" style="margin-bottom: 20px;">
    <input type="text" name="search" placeholder="Search username, phone or msisdn..." value="<?= htmlspecialchars($search) ?>">
    <button type="submit" class="btn">Search</button>
    <?php if ($search !== ''): ?>
        <a href="?"><button type="button" class="btn" style="background:#7f8c8d;">Clear</button></a>
    <?php endif; ?>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>User Phone</th>
            <th>Payment MSISDN</th>
            <th>Amount Paid (KES)</th>
            <th>Method</th>
            <th>Payment Status</th>
            <th>Created At</th>
            <th>User Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($logs)): ?>
            <tr><td colspan="12">No records found.</td></tr>
        <?php else: ?>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars($log['id']) ?></td>
                    <td><?= htmlspecialchars($log['username'] ?? '-') ?></td>
                    <td>
                        <?php
                            $rawPhone = $log['user_phone'] ?? '-';
                            if (preg_match('/^2547\d{8}$/', $rawPhone)) {
                                $rawPhone = '0' . substr($rawPhone, 3);
                            }
                            echo htmlspecialchars($rawPhone);
                        ?>
                    </td>
                    <td><?= htmlspecialchars($log['msisdn'] ?? '-') ?></td>
                    <td>
                        <form method="POST" class="inline" onsubmit="return confirm('Update payment amount?');">
                            <input type="hidden" name="log_id" value="<?= htmlspecialchars($log['id']) ?>">
                            <input type="number" step="0.01" name="amount_paid" value="<?= htmlspecialchars($log['amount_paid']) ?>" required>
                            <button type="submit" name="update_amount" class="btn">Update</button>
                        </form>
                    </td>
                    <td><?= htmlspecialchars($log['method'] ?? '-') ?></td>
                    <td><?= htmlspecialchars(ucfirst($log['status'] ?? '-')) ?></td>
                    <td><?= htmlspecialchars($log['created_at'] ?? '-') ?></td>
                    <td class="status-<?= ($log['user_status'] ?? '') === 'active' ? 'active' : 'inactive' ?>">
                        <?= htmlspecialchars(ucfirst($log['user_status'] ?? '-')) ?>
                    </td>
                    <td>
                        <?php if (!empty($log['user_id'])): ?>
                            <form method="POST" class="inline" onsubmit="return confirm('Are you sure?');">
                                <input type="hidden" name="user_id" value="<?= htmlspecialchars($log['user_id']) ?>">
                                <input type="hidden" name="action" value="<?= ($log['user_status'] ?? '') === 'active' ? 'deactivate' : 'activate' ?>">
                                <button type="submit" class="btn <?= ($log['user_status'] ?? '') === 'active' ? 'deactivate' : 'activate' ?>">
                                    <?= ($log['user_status'] ?? '') === 'active' ? 'Deactivate' : 'Activate' ?>
                                </button>
                            </form>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
