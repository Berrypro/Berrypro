<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    die("Unauthorized access.");
}

if (!isset($_GET['id'])) {
    die("User ID required.");
}

$id = (int) $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found.");
}

session_write_close(); // end admin session
session_start(); // fresh session
session_regenerate_id(true);

$_SESSION['user_id'] = $user['id'];
$_SESSION['impersonated_by_admin'] = true;

header("Location: ../dashboard.php");
exit;
