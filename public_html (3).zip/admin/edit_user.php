<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;
$query = $_GET['query'] ?? null;
$user = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
} elseif ($query) {
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE username = ? OR phone = ?");
    $stmt->execute([$query, $query]);
    $user = $stmt->fetch();
}

if (!$user) {
    echo "<p>User not found. <a href='dashboard.php'>Go back</a></p>";
    exit;
}

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $wallet_balance = floatval($_POST['wallet_balance']);
    $total_earned = floatval($_POST['total_earned']);
    $total_withdrawn = floatval($_POST['total_withdrawn']);
    $deposit_balance = floatval($_POST['deposit_balance']);
    $referred_by = trim($_POST['referred_by']);

    if ($username === '' || $email === '' || $phone === '') {
        $msg = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Invalid email format.";
    } else {
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE Users SET username = ?, email = ?, phone = ?, password = ?, wallet_balance = ?, total_earned = ?, total_withdrawn = ?, deposit_balance = ?, referred_by = ? WHERE id = ?");
            $stmt->execute([$username, $email, $phone, $hashed_password, $wallet_balance, $total_earned, $total_withdrawn, $deposit_balance, $referred_by, $user['id']]);
        } else {
            $stmt = $pdo->prepare("UPDATE Users SET username = ?, email = ?, phone = ?, wallet_balance = ?, total_earned = ?, total_withdrawn = ?, deposit_balance = ?, referred_by = ? WHERE id = ?");
            $stmt->execute([$username, $email, $phone, $wallet_balance, $total_earned, $total_withdrawn, $deposit_balance, $referred_by, $user['id']]);
        }

        $msg = "User updated successfully.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit User</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        /* Styles same as before (no changes needed) */
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            margin: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            background: white;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            margin-top: 0;
            font-size: 22px;
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            background-color: #28a745;
            color: white;
            padding: 12px;
            border: none;
            margin-top: 20px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #218838;
        }

        .msg {
            margin-top: 15px;
            font-weight: bold;
            color: green;
            text-align: center;
        }

        .error {
            color: red;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #254aee;
            text-decoration: none;
        }

        .open-dashboard-btn {
            text-align: center;
            margin-top: 10px;
        }

        .open-dashboard-btn a {
            background-color: #007bff;
            color: white;
            padding: 10px 16px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            font-weight: bold;
        }

        .open-dashboard-btn a:hover {
            background-color: #0056b3;
        }

        @media (max-width: 480px) {
            .container {
                padding: 15px;
            }

            h2 {
                font-size: 20px;
            }

            button {
                font-size: 15px;
            }

            input, select {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit User: <?= htmlspecialchars($user['username']) ?></h2>

    <?php if ($msg): ?>
        <div class="<?= strpos($msg, 'successfully') !== false ? 'msg' : 'error' ?>">
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>

        <label for="status">Status:</label>
        <select id="status" name="status" required onchange="handleStatusChange(this)">
            <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>

        <label for="password">Password: <small>(leave blank to keep unchanged)</small></label>
        <input type="password" id="password" name="password">

        <label for="wallet_balance">Wallet Balance:</label>
        <input type="number" step="0.01" name="wallet_balance" value="<?= htmlspecialchars($user['wallet_balance']) ?>">

        <label for="total_earned">Total Earned:</label>
        <input type="number" step="0.01" name="total_earned" value="<?= htmlspecialchars($user['total_earned']) ?>">

        <label for="total_withdrawn">Total Withdrawn:</label>
        <input type="number" step="0.01" name="total_withdrawn" value="<?= htmlspecialchars($user['total_withdrawn']) ?>">

        <label for="deposit_balance">Deposit Balance:</label>
        <input type="number" step="0.01" name="deposit_balance" value="<?= htmlspecialchars($user['deposit_balance']) ?>">

        <label for="referred_by">Upline (Referred By):</label>
        <input type="text" name="referred_by" value="<?= htmlspecialchars($user['referred_by']) ?>">

        <div class="open-dashboard-btn">
            <a href="impersonate.php?id=<?= urlencode($user['id']) ?>">🔓 Login as This User</a>
        </div>

        <button type="submit">Update User</button>
    </form>

    <a href="users.php">← Back to Users List</a>
</div>

<script>
function handleStatusChange(select) {
    const status = select.value;
    const userId = <?= (int)$user['id'] ?>;
    let endpoint = '';

    if (status === 'active') {
        endpoint = 'activate_user.php';
    } else if (status === 'inactive') {
        endpoint = 'deactivate_user.php';
    } else {
        return;
    }

    if (confirm("Are you sure you want to " + status + " this user?")) {
        fetch(`${endpoint}?user_id=${userId}`)
            .then(res => res.text())
            .then(data => {
                alert("Status updated successfully.");
                location.reload();
            }).catch(err => {
                alert("Error updating status.");
                console.error(err);
            });
    }
}
</script>
</body>
</html>
