<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Handle amount update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deposit_id'])) {
    $depositId = (int)$_POST['deposit_id'];

    // Check if this is an amount update
    if (isset($_POST['amount'])) {
        $newAmount = (float)$_POST['amount'];

        // Fetch current deposit info
        $stmt = $pdo->prepare("SELECT amount_deposited, status, user_id FROM deposits WHERE id = ?");
        $stmt->execute([$depositId]);
        $deposit = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($deposit) {
            $oldAmount = (float)$deposit['amount_deposited'];
            $userId = (int)$deposit['user_id'];

            $pdo->beginTransaction();
            try {
                // Update amount, set status = approved, update timestamp
                $stmt = $pdo->prepare("UPDATE deposits SET amount_deposited = ?, status = 'approved', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$newAmount, $depositId]);

                // Add the difference to user's deposit_balance if new amount is higher
                $diff = $newAmount - $oldAmount;
                if ($diff > 0) {
                    $stmt = $pdo->prepare("UPDATE Users SET deposit_balance = deposit_balance + ? WHERE id = ?");
                    $stmt->execute([$diff, $userId]);
                }

                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                die("Failed to update deposit: " . $e->getMessage());
            }
        }
    }

    // Handle approve/reject actions
    if (isset($_POST['action']) && in_array($_POST['action'], ['approve', 'reject'])) {
        $action = $_POST['action'];

        // Fetch deposit info for balance update if approving
        $stmt = $pdo->prepare("SELECT amount_deposited, status, user_id FROM deposits WHERE id = ?");
        $stmt->execute([$depositId]);
        $deposit = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($deposit) {
            $amount = (float)$deposit['amount_deposited'];
            $oldStatus = $deposit['status'];
            $userId = (int)$deposit['user_id'];

            if ($action === 'approve' && $oldStatus !== 'approved') {
                $pdo->beginTransaction();
                try {
                    // Update status to approved
                    $stmt = $pdo->prepare("UPDATE deposits SET status = 'approved', updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$depositId]);

                    // Add amount to user's deposit_balance
                    $stmt = $pdo->prepare("UPDATE Users SET deposit_balance = deposit_balance + ? WHERE id = ?");
                    $stmt->execute([$amount, $userId]);

                    $pdo->commit();
                } catch (Exception $e) {
                    $pdo->rollBack();
                    die("Failed to approve deposit: " . $e->getMessage());
                }
            } elseif ($action === 'reject' && $oldStatus !== 'rejected') {
                $pdo->beginTransaction();
                try {
                    // If previously approved, subtract amount from balance before rejecting
                    if ($oldStatus === 'approved') {
                        $stmt = $pdo->prepare("UPDATE Users SET deposit_balance = deposit_balance - ? WHERE id = ?");
                        $stmt->execute([$amount, $userId]);
                    }

                    // Update status to rejected
                    $stmt = $pdo->prepare("UPDATE deposits SET status = 'rejected', updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$depositId]);

                    $pdo->commit();
                } catch (Exception $e) {
                    $pdo->rollBack();
                    die("Failed to reject deposit: " . $e->getMessage());
                }
            }
        }
    }

    header('Location: admin_deposits.php');
    exit;
}

// Fetch deposits with username and phone
$stmt = $pdo->query("
    SELECT d.id, d.amount_deposited, d.status, d.updated_at, u.username, u.phone 
    FROM deposits d 
    JOIN Users u ON d.user_id = u.id 
    ORDER BY d.updated_at DESC
");
$deposits = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin Deposits - FlexHela</title>
<style>
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 8px; border: 1px solid #ddd; }
    th { background: #f2f2f2; }
    .status-pending { color: orange; font-weight: bold; }
    .status-approved { color: green; font-weight: bold; }
    .status-rejected { color: red; font-weight: bold; }
    form.inline { display: inline; margin: 0; }
    input[type="number"] { width: 80px; }
    button { padding: 4px 8px; margin-left: 4px; }
</style>
</head>
<body>
<h2>Admin Deposits</h2>
<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Username</th>
            <th>Phone</th>
            <th>Amount (Ksh.)</th>
            <th>Status</th>
            <th>Deposited At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($deposits as $i => $d): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= htmlspecialchars($d['username']) ?></td>
            <td><?= htmlspecialchars($d['phone']) ?></td>
            <td>
                <form method="POST" class="inline" style="margin-bottom:0;">
                    <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>" />
                    <input type="number" step="0.01" name="amount" value="<?= $d['amount_deposited'] ?>" min="0" required />
                    <button type="submit">Save</button>
                </form>
            </td>
            <td class="status-<?= htmlspecialchars($d['status']) ?>"><?= ucfirst($d['status']) ?></td>
            <td><?= date('Y-m-d H:i', strtotime($d['updated_at'])) ?></td>
            <td>
                <form method="POST" class="inline" style="margin-bottom:0;">
                    <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>" />
                    <button name="action" value="approve" type="submit" <?= $d['status'] === 'approved' ? 'disabled' : '' ?>>Approve</button>
                    <button name="action" value="reject" type="submit" <?= $d['status'] === 'rejected' ? 'disabled' : '' ?>>Reject</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>
