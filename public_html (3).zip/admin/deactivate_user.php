<?php
session_start();
require_once '../config.php';

// Check admin session or permissions
if (!isset($_SESSION['admin_id'])) {
    die("Unauthorized access.");
}

// Validate user_id
if (!isset($_GET['user_id'])) {
    die("User ID missing");
}

$userId = (int)$_GET['user_id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found.");
}

$currentStatus = $user['status'];
$username = $user['username'];

if ($currentStatus === 'active') {
    // === DEACTIVATE USER ===
    $stmt = $pdo->prepare("UPDATE Users SET status = 'inactive' WHERE id = ?");
    $stmt->execute([$userId]);

    if (!empty($user['referred_by'])) {
        $level1_bonus = 50;
        $level2_bonus = 20;

        // Level 1 upline
        $stmt = $pdo->prepare("SELECT id, referred_by FROM Users WHERE username = ?");
        $stmt->execute([$user['referred_by']]);
        $level1 = $stmt->fetch();

        if ($level1) {
            // Check if bonus was given
            $check = $pdo->prepare("SELECT id FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 1");
            $check->execute([$level1['id'], $userId]);
            $bonus1 = $check->fetchColumn();

            if ($bonus1) {
                // Deduct bonus and delete record
                $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance - ?, total_earned = total_earned - ?, activated_referrals = activated_referrals - 1 WHERE id = ?")
                    ->execute([$level1_bonus, $level1_bonus, $level1['id']]);

                $pdo->prepare("DELETE FROM referral_bonus WHERE id = ?")->execute([$bonus1]);
            }

            // Level 2
            if (!empty($level1['referred_by'])) {
                $stmt = $pdo->prepare("SELECT id FROM Users WHERE username = ?");
                $stmt->execute([$level1['referred_by']]);
                $level2 = $stmt->fetch();

                if ($level2) {
                    $check = $pdo->prepare("SELECT id FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 2");
                    $check->execute([$level2['id'], $userId]);
                    $bonus2 = $check->fetchColumn();

                    if ($bonus2) {
                        $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance - ?, total_earned = total_earned - ? WHERE id = ?")
                            ->execute([$level2_bonus, $level2_bonus, $level2['id']]);

                        $pdo->prepare("DELETE FROM referral_bonus WHERE id = ?")->execute([$bonus2]);
                    }
                }
            }
        }
    }

    echo "🚫 User deactivated and referral bonuses reversed.";
} else {
    echo "User is already inactive.";
}
?>
