<?php
session_start();
require '../config.php';

// Ensure only admin can access
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Validate and sanitize input
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['total_earned'])) {
    $user_id = (int)$_POST['user_id'];
    $total_earned = floatval($_POST['total_earned']);

    // Update total_earned in the database
    $stmt = $pdo->prepare("UPDATE Users SET total_earned = ? WHERE id = ?");
    if ($stmt->execute([$total_earned, $user_id])) {
        $_SESSION['upline_success'] = "Total earned updated successfully.";
    } else {
        $_SESSION['upline_error'] = "Failed to update total earned.";
    }
} else {
    $_SESSION['upline_error'] = "Invalid request.";
}

// Redirect back to users page
header('Location: users.php');
exit;
