<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$adminName = $_SESSION['admin_username'] ?? 'Admin';

// Fetch top 50 users by total_earned
$stmt = $pdo->query("
    SELECT 
        u.username,
        u.wallet_balance,
        u.deposit_balance,
        u.total_earned,
        u.created_at,
        (
            SELECT COUNT(*) 
            FROM Users 
            WHERE referred_by = u.username AND status = 'active'
        ) AS active_referrals
    FROM Users u
    WHERE u.status = 'active'
    ORDER BY u.total_earned DESC
    LIMIT 50
");
$leaders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Leaderboard - FlexHela</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f7f7f7;
      margin: 0;
      padding: 20px;
    }
    .container {
      max-width: 700px;
      margin: 0 auto;
      background: #fff;
      padding: 25px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ccc;
      text-align: center;
      font-size: 14px;
    }
    th {
      background: #007bff;
      color: white;
    }
    tr:nth-child(even) {
      background: #f2f2f2;
    }
    .back-btn {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 16px;
      background: #28a745;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    .back-btn:hover {
      background: #218838;
    }
    @media(max-width: 600px) {
      th, td {
        font-size: 13px;
        padding: 8px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🏆 Top 50 Leaderboard</h1>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Username</th>
          <th>Wallet (KES)</th>
          <th>Deposit Balance (KES)</th>
          <th>Total Earned (KES)</th>
          <th>Active Referrals</th>
          <th>Joined</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($leaders)): ?>
          <tr><td colspan="7">No active users found.</td></tr>
        <?php else: ?>
          <?php foreach ($leaders as $i => $user): ?>
            <tr>
              <td><?= $i + 1 ?></td>
              <td><?= htmlspecialchars($user['username']) ?></td>
              <td><?= number_format($user['wallet_balance'], 2) ?></td>
              <td><?= number_format($user['deposit_balance'], 2) ?></td>
              <td><?= number_format($user['total_earned'], 2) ?></td>
              <td><?= $user['active_referrals'] ?></td>
              <td><?= date('Y-m-d', strtotime($user['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>
</body>
</html>