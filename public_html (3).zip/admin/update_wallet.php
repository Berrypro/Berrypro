<?php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Validate input
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['wallet_balance'])) {
    $user_id = (int)$_POST['user_id'];
    $wallet_balance = (float)$_POST['wallet_balance'];

    // Update wallet balance
    $stmt = $pdo->prepare("UPDATE Users SET wallet_balance = ? WHERE id = ?");
    $stmt->execute([$wallet_balance, $user_id]);

    // Redirect back to user list
    header('Location: users.php');
    exit;
}

// Fallback
header('Location: users.php');
exit;
