
<?php
session_start();
require_once '../config.php';

// Check admin session or permissions here (important!)

if (!isset($_GET['user_id'])) {
    die("User ID missing");
}

$userId = (int)$_GET['user_id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found.");
}

$currentStatus = $user['status'];
$username = $user['username'];

if ($currentStatus !== 'active') {
    // === ACTIVATE USER ===
    $stmt = $pdo->prepare("UPDATE Users SET status = 'active', activated_at = NOW() WHERE id = ?");
    $stmt->execute([$userId]);

    if (!empty($user['referred_by'])) {
        $level1_bonus = 50;
        $level2_bonus = 20;

        // Level 1 upline
        $stmt = $pdo->prepare("SELECT id, referred_by FROM Users WHERE username = ?");
        $stmt->execute([$user['referred_by']]);
        $level1 = $stmt->fetch();

        if ($level1) {
            // Check if already credited
            $check = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 1");
            $check->execute([$level1['id'], $userId]);
            if ($check->fetchColumn() == 0) {
                $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ?, activated_referrals = activated_referrals + 1 WHERE id = ?")
                    ->execute([$level1_bonus, $level1_bonus, $level1['id']]);

                $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, amount, level, created_at) VALUES (?, ?, ?, 1, NOW())")
                    ->execute([$level1['id'], $userId, $level1_bonus]);
            }

            // Level 2
            if (!empty($level1['referred_by'])) {
                $stmt = $pdo->prepare("SELECT id FROM Users WHERE username = ?");
                $stmt->execute([$level1['referred_by']]);
                $level2 = $stmt->fetch();

                if ($level2) {
                    $check = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE upline_id = ? AND referred_id = ? AND level = 2");
                    $check->execute([$level2['id'], $userId]);
                    if ($check->fetchColumn() == 0) {
                        $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ? WHERE id = ?")
                            ->execute([$level2_bonus, $level2_bonus, $level2['id']]);

                        $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, amount, level, created_at) VALUES (?, ?, ?, 2, NOW())")
                            ->execute([$level2['id'], $userId, $level2_bonus]);
                    }
                }
            }
        }
    }

    echo "✅ User activated and referral bonuses credited.";
}
// After updating upline's wallet and inserting referral_bonus (Level 1 only)

$today = date('Y-m-d');

// Check if daily_stats already has a row for this upline today
$checkStats = $pdo->prepare("SELECT id FROM daily_stats WHERE upline_id = ? AND date = ?");
$checkStats->execute([$level1['id'], $today]);
$existingStat = $checkStats->fetch();

if ($existingStat) {
    // Update activated_today count
    $pdo->prepare("UPDATE daily_stats SET activated_today = activated_today + 1 WHERE id = ?")
        ->execute([$existingStat['id']]);
} else {
    // Insert new row for today
    $pdo->prepare("INSERT INTO daily_stats (date, upline_id, upline_username, activated_today) VALUES (?, ?, ?, 1)")
        ->execute([$today, $level1['id'], $user['referred_by']]);
}

?>
