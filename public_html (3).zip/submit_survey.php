<?php
require 'config.php';
session_start();

if (!isset($_POST['user_id'])) {
    header('Location: survey.php');
    exit;
}

$userId = $_POST['user_id'];
$score = 0;

for ($i = 0; $i < 10; $i++) {
    if (isset($_POST["q$i"]) && isset($_POST["correct$i"])) {
        if ((int)$_POST["q$i"] === (int)$_POST["correct$i"]) {
            $score++;
        }
    }
}

$earned = $score * 2;

// Save to Users table
$stmt = $pdo->prepare("UPDATE Users SET survey_balance = survey_balance + :earned WHERE id = :id");
$stmt->execute([
    ':earned' => $earned,
    ':id' => $userId
]);

// Log survey attempt (without `earned` column)
$stmt = $pdo->prepare("INSERT INTO survey_results (user_id, submitted_at, score) VALUES (?, NOW(), ?)");
$stmt->execute([$userId, $score]);

// Show success notification
echo "<script>
    alert('flexhela.com says:\\n\\nSurvey Submitted!\\nYou scored $score/10 and earned KES $earned');
    window.location.href = 'survey.php';
</script>";
