<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Get logged-in upline info
$stmt = $pdo->prepare("SELECT username, wallet_balance, deposit_balance, total_earned FROM Users WHERE id = ?");
$stmt->execute([$userId]);
$upline = $stmt->fetch();

function getTotalPaid($pdo, $ref_username) {
    $stmt1 = $pdo->prepare("SELECT COALESCE(SUM(upline_paid), 0) FROM activation_payments WHERE username = ?");
    $stmt1->execute([$ref_username]);
    $paidByUpline = (float)$stmt1->fetchColumn();

    $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(amount_paid), 0) FROM payments 
                            WHERE user_id = (SELECT id FROM Users WHERE username = ?) AND status = 'confirmed'");
    $stmt2->execute([$ref_username]);
    $paidByUser = (float)$stmt2->fetchColumn();

    return [$paidByUpline, $paidByUser, $paidByUpline + $paidByUser];
}

function getUpline($pdo, $username) {
    $uplines = [];
    for ($i = 0; $i < 2; $i++) {
        $stmt = $pdo->prepare("SELECT referred_by FROM Users WHERE username = ?");
        $stmt->execute([$username]);
        $ref = $stmt->fetchColumn();
        if (!$ref) break;
        $uplines[] = $ref;
        $username = $ref;
    }
    return $uplines;
}

$msg = '';
$ref_user = null;
$ref_username = $_POST['ref_username'] ?? '';
$paidByUpline = $paidByUser = $totalPaid = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Search referral
    if (isset($_POST['search']) && $ref_username) {
        $stmt = $pdo->prepare("SELECT * FROM Users WHERE username = ? AND status = 'inactive'");
        $stmt->execute([$ref_username]);
        $ref_user = $stmt->fetch();

        if ($ref_user) {
            list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $ref_username);
            $pdo->prepare("UPDATE Users SET totalpaid = ?, upline_paid = ? WHERE username = ?")
                ->execute([$totalPaid, $paidByUpline, $ref_username]);

            $msg = "User found. Paid by upline: KES $paidByUpline. Paid by user: KES $paidByUser. Total: KES $totalPaid. Remaining: KES " . max(0, 100 - $totalPaid);
        } else {
            $msg = "Referral user not found or already active.";
        }
    }

    // Activate (pay)
    elseif (isset($_POST['activate'])) {
        $ref_username = $_POST['ref_username'] ?? '';
        $amount = (float)($_POST['amount'] ?? 0);
        $wallet_type = $_POST['wallet_type'] ?? 'wallet_balance';

        if ($ref_username && $amount >= 1 && in_array($wallet_type, ['wallet_balance', 'deposit_balance'])) {
            $stmt = $pdo->prepare("SELECT * FROM Users WHERE username = ? AND status = 'inactive'");
            $stmt->execute([$ref_username]);
            $ref_user = $stmt->fetch();

            if (!$ref_user) {
                $msg = "Referral user not found or already active.";
            } else {
                $uplineUsernames = getUpline($pdo, $ref_username);
                $referrerIsDirect = $ref_user['referred_by'] === $upline['username'];
                $referrerIsLevel2 = in_array($upline['username'], $uplineUsernames);

                if ($referrerIsDirect || $referrerIsLevel2) {
                    if ($upline[$wallet_type] >= $amount) {
                        try {
                            $pdo->beginTransaction();

                            // Deduct from upline wallet
                            $pdo->prepare("UPDATE Users SET $wallet_type = $wallet_type - ? WHERE id = ?")
                                ->execute([$amount, $userId]);

                            // Log payment
                            $pdo->prepare("INSERT INTO activation_payments (username, upline, upline_paid, status, activated_at)
                                           VALUES (?, ?, ?, 'confirmed', NULL)")
                                ->execute([$ref_username, $upline['username'], $amount]);

                            // Recalculate total paid
                            list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $ref_username);
                            $pdo->prepare("UPDATE Users SET upline_paid = ?, totalpaid = ? WHERE username = ?")
                                ->execute([$paidByUpline, $totalPaid, $ref_username]);

                            // Check if now eligible for activation
                            if ($totalPaid >= 100) {
                                // Activate user
                                $pdo->prepare("UPDATE Users SET status = 'active', activated_at = NOW() WHERE username = ?")
                                    ->execute([$ref_username]);

                                $pdo->prepare("UPDATE activation_payments SET status = 'activated', activated_at = NOW() WHERE username = ?")
                                    ->execute([$ref_username]);

                                // Pay referral bonus
                                $bonus = $referrerIsDirect ? 50 : 20;
                                $level = $referrerIsDirect ? 1 : 2;

                                $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ? WHERE id = ?")
                                    ->execute([$bonus, $bonus, $userId]);

                                $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at)
                                               VALUES (?, ?, ?, ?, NOW())")
                                    ->execute([$userId, $ref_user['id'], $level, $bonus]);

                                $msg = "KES 100 paid. Referral activated (Level $level). You earned KES $bonus bonus.";
                            } else {
                                $msg = "KES $amount paid to $ref_username. Total paid so far: KES $totalPaid. Activation requires 100.";
                            }

                            $pdo->commit();
                        } catch (Exception $e) {
                            $pdo->rollBack();
                            $msg = "Error occurred: " . $e->getMessage();
                        }
                    } else {
                        $msg = "Insufficient $wallet_type to pay KES $amount.";
                    }
                } else {
                    $msg = "You are not a valid upline for $ref_username.";
                }
            }
        } else {
            $msg = "Invalid input or wallet type.";
        }
    }
}

// Get payment history
$stmt = $pdo->prepare("SELECT * FROM activation_payments WHERE upline = ? ORDER BY id DESC");
$stmt->execute([$upline['username']]);
$history = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Activate Referral</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #121212;
            color: #e0e0e0;
            margin: 0;
            padding: 20px;
        }

        h2, h3 {
            text-align: center;
            color: #ffffff;
        }

        .msg {
            text-align: center;
            color: #00e676;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .form-grid {
            max-width: 800px;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .col-12 {
            width: 100%;
        }

        .col-6 {
            width: 48%;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #333;
            border-radius: 5px;
            background-color: #1e1e1e;
            color: #fff;
            font-size: 15px;
        }

        button {
            background-color: #007bff;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 40px auto 0;
            color: #fff;
        }

        th, td {
            padding: 10px;
            border: 1px solid #333;
            text-align: center;
        }

        th {
            background-color: #2c2c2c;
        }

        tr:nth-child(even) {
            background-color: #1b1b1b;
        }

        tr:hover {
            background-color: #333;
        }

        @media (max-width: 768px) {
            .col-6 {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <h2>Activate Referral (Level 1 or 2)</h2><br>
     <a href="dashboard.php" style="color:green;">← Back to Dashboard</a><br><br>

    <?php if ($msg): ?>
        <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" class="form-grid">
        <div class="col-12">
            <label for="ref_username">Referral Username:</label>
            <input type="text" name="ref_username" id="ref_username" value="<?= htmlspecialchars($ref_username) ?>" required>
        </div>

        <div class="col-12">
            <button type="submit" name="search">Search</button>
        </div>

        <?php if ($ref_user): ?>
            <div class="col-6">
                <label for="amount">Amount to Pay (KES):</label>
                <input type="number" step="1" min="1" name="amount" id="amount" required>
            </div>

            <div class="col-6">
                <label for="wallet_type">Select Wallet:</label>
                <select name="wallet_type" id="wallet_type">
                    <option value="wallet_balance">Wallet Balance (KES <?= number_format($upline['wallet_balance'], 2) ?>)</option>
                    <option value="deposit_balance">Deposit Balance (KES <?= number_format($upline['deposit_balance'], 2) ?>)</option>
                </select>
            </div>

            <div class="col-12">
                <button type="submit" name="activate">Activate</button>
            </div>
        <?php endif; ?>
    </form>

    <h3>Activation History</h3>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Username</th>
                <th>Upline</th>
                <th>Amount Paid</th>
                <th>Status</th>
                <th>Activated At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($history)): ?>
                <tr><td colspan="6">No history found.</td></tr>
            <?php else: ?>
                <?php foreach ($history as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['upline']) ?></td>
                        <td>KES <?= number_format($row['upline_paid'], 2) ?></td>
                        <td><?= ucfirst($row['status']) ?></td>
                        <td><?= $row['activated_at'] ?? '—' ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
