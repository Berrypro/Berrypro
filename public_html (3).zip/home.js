
  const notifBtn = document.getElementById('notifBtn');
  const menuBtn = document.getElementById('menuBtn');
  const notifDropdown = document.getElementById('notifDropdown');
  const menuDropdown = document.getElementById('menuDropdown');

  notifBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    notifDropdown.style.display = notifDropdown.style.display === 'block' ? 'none' : 'block';
    menuDropdown.style.display = 'none';
  });

  menuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    menuDropdown.style.display = menuDropdown.style.display === 'block' ? 'none' : 'block';
    notifDropdown.style.display = 'none';
  });

  document.addEventListener('click', () => {
    notifDropdown.style.display = 'none';
    menuDropdown.style.display = 'none';
  });
