<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT server_seed, client_seed, nonce FROM crash_rounds ORDER BY id DESC LIMIT 1");
    $round = $stmt->fetch();
    
    if ($round) {
        echo json_encode([
            'success' => true,
            'server_seed_hash' => hash('sha256', $round['server_seed']),
            'client_seed' => $round['client_seed'],
            'nonce' => $round['nonce']
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No rounds found']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>