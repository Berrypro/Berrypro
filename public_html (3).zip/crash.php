<?php 
session_start();
require 'config.php';

// Verify user session
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$balance = 0;

// Get current round or create new one
$round = null;
$crashAt = 0;
$startTime = time();

try {
    $pdo->beginTransaction();
    
    // Check for active round
    $stmt = $pdo->query("SELECT * FROM crash_rounds WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $round = $stmt->fetch();
    
    if (!$round) {
        // Generate random crash point (1.1x to 10x)
        $serverSeed = bin2hex(random_bytes(32));
        $hash = hash('sha256', $serverSeed);
        $hex = substr($hash, 0, 8);
        $int = hexdec($hex);
        $crashPoint = max(1.10, min(10.00, (($int % 9000) / 1000) + 1));
        
        $stmt = $pdo->prepare("INSERT INTO crash_rounds (start_time, crash_point, is_active, server_seed) VALUES (NOW(), ?, 1, ?)");
        $stmt->execute([$crashPoint, $serverSeed]);
        $roundId = $pdo->lastInsertId();
        
        $stmt = $pdo->query("SELECT * FROM crash_rounds WHERE id = $roundId");
        $round = $stmt->fetch();
    }
    
    $pdo->commit();
    
    $crashAt = $round['crash_point'] ?? 2.00;
    $startTime = strtotime($round['start_time'] ?? date('Y-m-d H:i:s'));
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Round initialization error: " . $e->getMessage());
    $crashAt = 2.00;
    $startTime = time();
}

$currentTime = time();
$elapsed = $currentTime - $startTime;

// Get recent winners
$recentWinners = [];
try {
    $stmt = $pdo->query("
        SELECT u.username, b.amount, b.cashed_out_at as multiplier, b.payout as won 
        FROM crash_bets b
        JOIN Users u ON b.user_id = u.id
        WHERE b.status = 'cashed_out'
        ORDER BY b.id DESC
        LIMIT 10
    ");
    $recentWinners = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching recent winners: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Crash Game</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { background-color: #0f0f0f; color: #f5f5f5; font-family: sans-serif; }
    .multiplier { font-size: 3rem; font-weight: bold; color: #f97316; transition: all 0.2s ease-in-out; }
    @media (max-width: 768px) {
      .multiplier { font-size: 2rem; }
      .h-52 { height: 10rem; }
    }
    .graph-container {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0;
    }
    .next-round {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(0,0,0,0.8);
      padding: 10px 20px;
      border-radius: 5px;
      z-index: 10;
      display: none;
    }
    #placeBet.running {
      background-color: #4CAF50 !important;
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.02); }
      100% { transform: scale(1); }
    }
    .spinner {
      display: inline-block;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    #placeBet:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }
  </style>
</head>
<body class="p-4 max-w-screen-md mx-auto">

<div class="flex justify-between items-center mb-4">
  <h1 class="text-xl font-bold text-orange-500">FlexCrash</h1>
  <div class="text-sm bg-green-600 text-white px-2 py-1 rounded">Ksh. <span id="balance"><?php echo number_format($balance, 2); ?></span></div>
</div>

<div class="relative bg-black rounded-lg p-4 h-52 flex items-center justify-center">
  <div class="graph-container" id="graph"></div>
  <div class="multiplier" id="multiplier">1.00x</div>
  <div class="next-round" id="nextRound">Next round begins in <span id="countdown">3</span>s...</div>
</div>

<div class="flex gap-2 mt-4 overflow-x-auto whitespace-nowrap text-sm" id="bustHistory">
  <?php
    try {
        $stmt = $pdo->query("SELECT crash_point FROM crash_rounds WHERE crash_point IS NOT NULL ORDER BY id DESC LIMIT 20");
        while ($row = $stmt->fetch()) {
            $value = $row['crash_point'];
            $color = $value >= 2 ? 'green' : 'red';
            echo "<span class='bg-{$color}-600 px-2 py-1 rounded'>{$value}x</span>";
        }
    } catch (PDOException $e) {
        error_log("History fetch error: " . $e->getMessage());
    }
  ?>
</div>

<div class="bg-gray-800 p-4 mt-4 rounded">
  <div class="flex justify-between items-center mb-2 flex-wrap gap-2">
    <a href="deposit.php" class="text-green-800 bg-green-300 px-3 py-1 rounded font-bold text-sm">DEPOSIT</a>
    <span class="text-green-300">Ksh. <span id="available"><?php echo number_format($balance, 2); ?></span></span>
  </div>
  <div class="flex flex-col md:flex-row gap-4 mb-2">
    <input type="number" id="amount" placeholder="Amount in KES (Min 5, Max 500)" class="w-full p-2 rounded bg-gray-700 text-white" min="5" max="500" step="1" />
    <input type="number" id="autoCashout" step="0.01" min="1.10" placeholder="Auto cashout (e.g. 2.00)" class="w-full p-2 rounded bg-gray-700 text-white" />
  </div>
  <p class="text-xs text-gray-400 mb-2">Award = Bet × Cashout Multiplier. E.g. 50 KES × 3.00 = 150 KES</p>
  <button id="placeBet" class="w-full bg-orange-500 hover:bg-orange-600 text-white p-2 rounded font-bold">Place Bet</button>
  <button id="cashOut" class="w-full bg-green-500 hover:bg-green-600 text-white p-2 rounded font-bold mt-2 hidden">Cash Out</button><br><br>
   <a href="dashboard.php" style="color:green;">← Back to Dashboard</a><br>
</div>

<!-- Recent Winners Table -->
<div class="mt-6 bg-gray-800 rounded-lg overflow-hidden">
  <h3 class="bg-gray-700 px-4 py-2 font-bold">Recent Winners</h3>
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead>
        <tr class="bg-gray-700">
          <th class="px-4 py-2 text-left">Player</th>
          <th class="px-4 py-2 text-right">Bet Amount</th>
          <th class="px-4 py-2 text-right">Burst</th>
          <th class="px-4 py-2 text-right">Won</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($recentWinners as $winner): ?>
        <tr class="border-b border-gray-700">
          <td class="px-4 py-2"><?php echo htmlspecialchars($winner['username'] ?? ''); ?></td>
          <td class="px-4 py-2 text-right"><?php echo number_format($winner['amount'] ?? 0, 2); ?></td>
          <td class="px-4 py-2 text-right"><?php echo number_format($winner['multiplier'] ?? 0, 2); ?>x</td>
          <td class="px-4 py-2 text-right text-green-400"><?php echo number_format($winner['won'] ?? 0, 2); ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($recentWinners)): ?>
        <tr>
          <td colspan="4" class="px-4 py-2 text-center text-gray-400">No recent winners yet</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
let multiplier = 1.00;
let interval;
let placed = false;
let autoCashout = 0;
let gameStarted = false;
const crashAt = <?php echo $crashAt; ?>;
const elapsed = <?php echo $elapsed; ?>;
const display = document.getElementById('multiplier');
const balanceDisplay = document.getElementById('balance');
const cashOutBtn = document.getElementById('cashOut');
const graph = document.getElementById('graph');
const betButton = document.getElementById('placeBet');
const nextRoundDisplay = document.getElementById('nextRound');
const countdownDisplay = document.getElementById('countdown');
let currentBetId = null;
let chart = null;
let gameData = {
    time: [],
    values: []
};

// Initialize Chart
function initChart() {
    const ctx = graph;
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: gameData.time,
            datasets: [{
                data: gameData.values,
                borderColor: '#f97316',
                borderWidth: 2,
                fill: false,
                tension: 0.1,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { display: false },
                y: { 
                    display: false,
                    suggestedMin: 1.00,
                    suggestedMax: Math.max(crashAt, 5)
                }
            }
        }
    });
}

// Update chart data
function updateChart(value) {
    gameData.time.push(gameData.time.length);
    gameData.values.push(value);
    
    if (chart) {
        chart.data.labels = gameData.time;
        chart.data.datasets[0].data = gameData.values;
        
        // Adjust view if approaching crash point
        if (value > chart.options.scales.y.suggestedMax * 0.8) {
            chart.options.scales.y.suggestedMax = value * 1.5;
        }
        
        chart.update();
    }
}

// Game engine
function startGame() {
    if (gameStarted) return;
    gameStarted = true;
    
    let timePassed = elapsed;
    cashOutBtn.classList.add('hidden');
    
    // Initialize chart
    initChart();
    updateChart(1.00);
    
    console.log("Game started with crash point:", crashAt);
    
    interval = setInterval(() => {
        timePassed += 0.1;
        
        // Exponential growth with slight randomness
        const baseGrowth = 0.0005 * Math.pow(timePassed, 1.5);
        const randomFactor = 1 + (Math.random() * 0.002 - 0.001);
        multiplier = 1.00 + baseGrowth * randomFactor;
        
        display.textContent = multiplier.toFixed(2) + 'x';
        updateChart(multiplier);

        // Update running amount display if bet is placed
        if (placed) {
            const amount = parseFloat(document.getElementById('amount').value);
            const currentValue = (amount * multiplier).toFixed(2);
            betButton.innerHTML = `🏃‍♂️ KES ${amount.toFixed(2)} (KES ${currentValue})`;
            betButton.classList.add('running');
        }

        // Auto cashout check
        if (placed && autoCashout && multiplier >= autoCashout) {
            console.log("Auto cashout triggered at", multiplier.toFixed(2));
            handleCashOut();
        }
        
        // Crash check
        if (multiplier >= crashAt) {
            console.log("Crashed at", multiplier.toFixed(2));
            handleCrash();
        }
    }, 100);
}

function handleCrash() {
    clearInterval(interval);
    const bustHistory = document.getElementById('bustHistory');
    const span = document.createElement('span');
    span.className = `px-2 py-1 rounded inline-block ${multiplier >= 2 ? 'bg-green-600' : 'bg-red-600'}`;
    span.textContent = multiplier.toFixed(2) + 'x';
    bustHistory.insertBefore(span, bustHistory.firstChild);
    
    if (placed) {
        // Player didn't cash out - they lose
        placed = false;
        cashOutBtn.classList.add('hidden');
        alert(`Round crashed at ${multiplier.toFixed(2)}x! You lost your bet.`);
        
        // Reset place bet button
        resetBetButton();
        
        // Update bet status to crashed
        if (currentBetId) {
            fetch('update_bet_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    bet_id: currentBetId,
                    status: 'crashed'
                })
            }).catch(err => console.error("Bet update error:", err));
        }
    }
    
    // Start new round countdown
    startNewRoundCountdown();
}

function startNewRoundCountdown() {
    console.log("[ROUND] Starting new round countdown");
    nextRoundDisplay.style.display = 'block';
    let countdown = 3;
    countdownDisplay.textContent = countdown;

    const countInterval = setInterval(() => {
        countdown--;
        countdownDisplay.textContent = countdown;

        if (countdown <= 0) {
            clearInterval(countInterval);
            nextRoundDisplay.style.display = 'none';
            initializeNewRound();
        }
    }, 1000);
}

function initializeNewRound() {
    console.log("[ROUND] Initializing new round");
    fetch('start_new_round.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => {
        if (!response.ok) throw new Error("Network response was not ok");
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Full page reload to ensure clean state
            console.log("[ROUND] New round started, reloading...");
            window.location.reload();
        } else {
            console.error("[ROUND] Failed to start new round:", data.message);
            // Retry after delay
            setTimeout(initializeNewRound, 2000);
        }
    })
    .catch(error => {
        console.error("[ROUND] Error starting new round:", error);
        // Retry after delay
        setTimeout(initializeNewRound, 2000);
    });
}

function handleCashOut() {
    if (!placed || !currentBetId) return;
    
    const betAmount = parseFloat(document.getElementById('amount').value);
    const payout = (betAmount * multiplier).toFixed(2);
    
    fetch('cashout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            bet_id: currentBetId,
            payout: payout,
            multiplier: multiplier.toFixed(2)
        })
    })
    .then(res => res.json())
    .then(res => {
        if (res.success) {
            let balance = parseFloat(balanceDisplay.textContent.replace(/,/g, ''));
            balance += parseFloat(payout);
            balanceDisplay.textContent = balance.toLocaleString('en-US', {minimumFractionDigits: 2});
            document.getElementById('available').textContent = balanceDisplay.textContent;
            
            alert(`You cashed out at ${multiplier.toFixed(2)}x and won KES ${parseFloat(payout).toLocaleString('en-US', {minimumFractionDigits: 2})}`);
            
            // Reset game state
            placed = false;
            currentBetId = null;
            cashOutBtn.classList.add('hidden');
            resetBetButton();
        } else {
            alert(res.message || 'Cashout failed. Please try again.');
        }
    })
    .catch(err => {
        console.error('Cashout error:', err);
        alert('Network error during cashout. Please check your connection.');
    });
}

function resetBetButton() {
    betButton.textContent = 'Place Bet';
    betButton.style.backgroundColor = '';
    betButton.classList.remove('running');
}

// Place Bet functionality
document.getElementById('placeBet').addEventListener('click', async function() {
    const betButton = this;
    const amountInput = document.getElementById('amount');
    const amount = parseFloat(amountInput.value);
    const autoCashoutInput = document.getElementById('autoCashout');
    const autoCashout = parseFloat(autoCashoutInput.value) || null;
    const balance = parseFloat(balanceDisplay.textContent.replace(/,/g, ''));

    // Validate inputs
    if (isNaN(amount)) {
        alert('Please enter a valid amount');
        amountInput.focus();
        return;
    }

    if (amount < 50000 || amount > 500000) {
        alert('Cannot place bet! Game Under mantainance. Coming soon!!');
        amountInput.select();
        return;
    }

    if (amount > balance) {
        alert('Insufficient balance for this bet');
        return;
    }

    if (autoCashout && (autoCashout < 1.10 || autoCashout > 100)) {
        alert('Auto cashout must be between 1.10x and 100x');
        autoCashoutInput.focus();
        return;
    }

    // Disable button and show loading state
    betButton.disabled = true;
    betButton.innerHTML = '<span class="spinner">⌛</span> Processing...';

    try {
        const response = await fetch('place_bet.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                amount: amount,
                auto_cashout: autoCashout,
                round_id: <?php echo $round['id'] ?? 0; ?>
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Network error');
        }

        const data = await response.json();

        if (data.success) {
            // Update UI
            const newBalance = (balance - amount).toFixed(2);
            balanceDisplay.textContent = newBalance;
            document.getElementById('available').textContent = newBalance;
            
            placed = true;
            currentBetId = data.bet_id;
            document.getElementById('cashOut').classList.remove('hidden');
            
            // Update button to show running bet
            betButton.innerHTML = `🏃‍♂️ KES ${amount.toFixed(2)} (KES ${amount.toFixed(2)})`;
            betButton.classList.add('running');
        } else {
            throw new Error(data.message || 'Bet placement failed');
        }
    } catch (error) {
        console.error('Bet error:', error);
        alert(error.message);
        betButton.textContent = 'Place Bet';
    } finally {
        betButton.disabled = false;
    }
});

cashOutBtn.addEventListener('click', handleCashOut);

// Start the game when page loads
window.onload = startGame;
</script>

</body>
</html>