<?php
// Handle STK push request on form submission
function sendstk($amount, $phone) {
    $data = json_encode([
        "amount" => $amount,
        "phone" => $phone,
        "load_response" => true
    ]);

    $ch = curl_init("https://api.boogiecoin.com");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Api-Secret: eythb4vrytju'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $result = "";
    if ($httpcode == 200) {
        $responseData = json_decode($response, true);
        if ($responseData['Status']) {
            $result = "✅ Payment Successful. Await confirmation on your phone.";
        } else {
            $result = "❌ Payment Failed: " . ($responseData['Message'] ?? 'Unknown error');
        }
    } else {
        $result = "❌ Error: HTTP Status Code $httpcode";
    }

    return $result . "<br><pre>" . htmlspecialchars(print_r($responseData ?? [], true)) . "</pre>";
}

$responseMessage = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = $_POST['amount'] ?? 1;
    $phone = $_POST['phone'] ?? '';
    $responseMessage = sendstk($amount, $phone);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pay with STK Push - Mulapal</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f6f6f6;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .container {
      background: white;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
    }
    input, button {
      width: 100%;
      padding: 0.75rem;
      margin-top: 1rem;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      background: #7928ca;
      color: white;
      border: none;
      cursor: pointer;
    }
    .message {
      margin-top: 1rem;
      padding: 1rem;
      background: #e0ffe0;
      border: 1px solid #b2d8b2;
      color: #2d662d;
      border-radius: 5px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>STK Push Payment</h2>
    <form method="POST">
      <label for="amount">Amount (KES)</label>
      <input type="number" id="amount" name="amount" required min="1" value="1">

      <label for="phone">Phone Number (07...)</label>
      <input type="text" id="phone" name="phone" required placeholder="e.g. 0743763095">

      <button type="submit">Pay Now</button>
    </form>

    <?php if (!empty($responseMessage)): ?>
      <div class="message"><?= $responseMessage ?></div>
    <?php endif; ?>
  </div>
</body>
</html>
