<?php
session_start();
require_once 'config.php'; // ensures $pdo is defined

function cleanInput($data) {
    return htmlspecialchars(trim($data));
}

$error = "";
$successMsg = "";

// Handle success alert after signup
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $successMsg = "Account created successfully! Please log in.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = cleanInput($_POST['username']);
    $password = $_POST['password'];

    // Fetch user by username or email
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE username = :username OR email = :email LIMIT 1");
    $stmt->execute([
        'username' => $username_or_email,
        'email' => $username_or_email
    ]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify credentials
    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true); // prevent session fixation

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['phone'] = $user['phone'];
        $_SESSION['LAST_ACTIVITY'] = time();

        // Redirect based on status and country
        $status = strtolower($user['status']);
        if ($status === 'active') {
            header("Location: dashboard.php");
        } else {
            $country = strtolower($user['country']);
            if ($country === 'kenya') {
                header("Location: kepay.php");
            } else {
                header("Location: payment.php");
            }
        }
        exit;
    } else {
        $error = "Invalid username/email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login to Flexhela | Access Your Earnings Dashboard</title>
  <link rel="stylesheet" type="text/css" href="signin.css">
</head>

<style>
  .btn1{
    background-color: #254aee;
    color: white;
    padding: 8px 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 10px;
    text-decoration: none;
  }
</style>
<body>
  <div class="form-container">
    <h1>FLEXHELA</h1>
    <p class="title">Log in to your account</p>

    <?php if (!empty($successMsg)): ?>
      <div class="error" style="background-color: #28a745;"><?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="signin.php" method="POST">
      <label for="username">Username or Email</label>
      <input type="text" id="username" name="username" required />

      <label for="password">Password</label>
      <div class="password-container">
        <input type="password" id="password" name="password" required />
        <span onclick="togglePassword()">Show</span>
      </div>

      <button class="btn" type="submit">Log in</button>
    </form>

    <div class="signup-link">
      New here? <a href="signup.php">Sign up</a>
    </div>
  </div>

  <script>
    function togglePassword() {
      const pass = document.getElementById("password");
      pass.type = pass.type === "password" ? "text" : "password";
    }
  </script>
</body>
</html>
