<?php
session_start();
require 'config.php';

// Security checks
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

// CSRF protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$user_id = $_SESSION['user_id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: signin.php");
    exit;
}

$username = $user['username'];
$notice = '';
$msg = '';

// Calculate total payments
function getTotalPaid($pdo, $username) {
    try {
        $stmt1 = $pdo->prepare("SELECT COALESCE(SUM(upline_paid), 0) FROM activation_payments WHERE username = ?");
        $stmt1->execute([$username]);
        $paidByUpline = (float)$stmt1->fetchColumn();

        $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(amount_paid), 0) FROM payments WHERE username = ? AND status = 'confirmed'");
        $stmt2->execute([$username]);
        $paidByUser = (float)$stmt2->fetchColumn();

        return [$paidByUpline, $paidByUser, $paidByUpline + $paidByUser];
    } catch (PDOException $e) {
        error_log("Payment calculation error: " . $e->getMessage());
        return [0, 0, 0];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $notice = "Invalid form submission. Please try again.";
    } else {
        $amount = filter_var($_POST['amount'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $phone = preg_replace('/\D/', '', $_POST['phone']);

        if ($amount === false || empty($phone) || strlen($phone) < 9) {
            $notice = "Please enter a valid amount (minimum 1 KES) and phone number.";
        } else {
            $payload = json_encode([
                "amount" => $amount,
                "phone" => $phone,
                "load_response" => true
            ]);

            $ch = curl_init("https://api.boogiecoin.com");
            if ($ch === false) {
                error_log("cURL initialization failed");
                $notice = "Payment service unavailable. Please try again later.";
            } else {
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => $payload,
                    CURLOPT_HTTPHEADER => [
                        'Content-Type: application/json',
                        'Api-Secret: eythb4vrytju'
                    ],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_SSL_VERIFYPEER => true
                ]);

                $response = curl_exec($ch);
                $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

       if (curl_errno($ch)) {
    $error = curl_error($ch);
    error_log("cURL Error: $error");

    if (strpos($error, 'timed out') !== false) {
        $notice = "⚠️ Payment request timed out. Please do NOT retry until you confirm whether the STK push reached your phone. If money was deducted, contact support.";
    } else {
        $notice = "Payment processing failed. Please try again.";
    }
                } else {
                    $result = json_decode($response, true);

                    if ($httpcode == 200 && !empty($result['Status']) && $result['Status'] === true) {
                        try {
                            $pdo->beginTransaction();

                            // Record payment
                            $insert = $pdo->prepare("INSERT INTO payments (user_id, username, msisdn, amount_paid, method, status, created_at) 
                                                     VALUES (?, ?, ?, ?, 'STK Push', 'confirmed', NOW())");
                            $insert->execute([$user_id, $username, $phone, $amount]);

                            // Update totals
                            list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $username);
                            $update = $pdo->prepare("UPDATE Users SET amount_paid = ?, upline_paid = ?, totalpaid = ? WHERE id = ?");
                            $update->execute([$paidByUser, $paidByUpline, $totalPaid, $user_id]);

                            // Activation check
                            if ($totalPaid >= 100 && $user['status'] !== 'active') {
                                $pdo->prepare("UPDATE Users SET status = 'active', activated_at = NOW() WHERE id = ?")
                                    ->execute([$user_id]);

                                $_SESSION['status'] = 'active';

                                // Refresh session
                                $stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
                                $stmt->execute([$user_id]);
                                $_SESSION['user'] = $stmt->fetch(PDO::FETCH_ASSOC);

                                // --- Referral Bonuses ---
                                $stmtUpline = $pdo->prepare("SELECT referred_by FROM Users WHERE id = ?");
                                $stmtUpline->execute([$user_id]);
                                $refData = $stmtUpline->fetch();

                                if ($refData && !empty($refData['referred_by'])) {
                                    $referrerUsername = $refData['referred_by'];

                                    // Level 1 upline (active or not)
                                    $stmtLevel1 = $pdo->prepare("SELECT id, referred_by FROM Users WHERE username = ?");
                                    $stmtLevel1->execute([$referrerUsername]);
                                    $level1 = $stmtLevel1->fetch();

                                    if ($level1) {
                                        // Check duplicate
                                        $bonusCheck = $pdo->prepare("SELECT COUNT(*) FROM referral_bonuses WHERE referrer_id = ? AND referee_id = ? AND level = 1");
                                        $bonusCheck->execute([$level1['id'], $user_id]);

                                        if ($bonusCheck->fetchColumn() == 0) {
                                            $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + 50, total_earned = total_earned + 50 WHERE id = ?")
                                                ->execute([$level1['id']]);

                                            $pdo->prepare("INSERT INTO referral_bonuses (referrer_id, referee_id, amount, level, created_at)
                                                           VALUES (?, ?, 50, 1, NOW())")
                                                ->execute([$level1['id'], $user_id]);
                                        }

                                        // Level 2
                                        if (!empty($level1['referred_by'])) {
                                            $stmtLevel2 = $pdo->prepare("SELECT id FROM Users WHERE username = ?");
                                            $stmtLevel2->execute([$level1['referred_by']]);
                                            $level2 = $stmtLevel2->fetch();

                                            if ($level2) {
                                                $bonusCheck2 = $pdo->prepare("SELECT COUNT(*) FROM referral_bonuses WHERE referrer_id = ? AND referee_id = ? AND level = 2");
                                                $bonusCheck2->execute([$level2['id'], $user_id]);

                                                if ($bonusCheck2->fetchColumn() == 0) {
                                                    $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + 20, total_earned = total_earned + 20 WHERE id = ?")
                                                        ->execute([$level2['id']]);

                                                    $pdo->prepare("INSERT INTO referral_bonuses (referrer_id, referee_id, amount, level, created_at)
                                                                   VALUES (?, ?, 20, 2, NOW())")
                                                        ->execute([$level2['id'], $user_id]);
                                                }
                                            }
                                        }
                                    }
                                }

                                $msg = "🎉 Your account has been activated! Redirecting to dashboard...";
                                $pdo->commit();
                                header("Refresh: 3; url=dashboard.php");
                            } else {
                                $msg = "Payment of KES $amount received. Total paid so far: KES $totalPaid.";
                                $pdo->commit();
                            }
                        } catch (PDOException $e) {
                            $pdo->rollBack();
                            error_log("DB Error: " . $e->getMessage());
                            $notice = "Payment processing failed. Please try again.";
                        }
                    } else {
                        $notice = "Payment failed. " . ($result['message'] ?? "Please try again.");
                    }
                }

                curl_close($ch);
            }
        }
    }
}

// Load current totals
list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $username);
$remaining = max(0, 100 - $totalPaid);
$isActive = $user['status'] === 'active';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pay With MPESA</title>
  <style>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Roboto', sans-serif;
      background-color: #1e1e2f;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      line-height: 1.6;
    }
    .container {
      background-color: #292942;
      border-radius: 10px;
      padding: 30px;
      width: 100%;
      max-width: 450px;
      margin: 20px;
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4);
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    h2 {
      text-align: center;
      font-size: 24px;
      font-weight: 600;
      margin-bottom: 10px;
    }
    p {
      text-align: center;
      margin-bottom: 10px;
      color: #1abc9c;
      font-weight: 500;
    }
    .notice, .msg {
      padding: 12px;
      border-radius: 6px;
      font-size: 14px;
      text-align: center;
      margin-bottom: 15px;
    }
    .notice {
      background-color: #34495e;
      color: #ecf0f1;
    }
    .msg {
      background-color: #27ae60;
      color: white;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    label {
      font-size: 14px;
      font-weight: 500;
    }
    input[type="number"],
    input[type="tel"] {
      width: 100%;
      padding: 12px;
      border: 1px solid #34495e;
      border-radius: 5px;
      background: #2c3e50;
      color: #fff;
      font-size: 14px;
    }
    input:focus {
      border-color: #2980b9;
      outline: none;
      box-shadow: 0 0 0 2px rgba(41, 128, 185, 0.3);
    }
    button {
      padding: 14px;
      background-color: #2980b9;
      border: none;
      border-radius: 6px;
      color: white;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
      margin-top: 10px;
    }
    button:hover {
      background-color: #3498db;
    }
    button:disabled {
      background-color: #7f8c8d;
      cursor: not-allowed;
    }
    .whatsapp-link {
      text-align: center;
      margin-top: 15px;
    }
    .whatsapp-link a {
      color: #1abc9c;
      text-decoration: none;
      font-weight: 500;
    }
    .whatsapp-link a:hover {
      text-decoration: underline;
    }
    @media (max-width: 480px) {
      .container {
        padding: 20px;
        margin: 10px;
      }
      h2 {
        font-size: 20px;
      }
      button {
        font-size: 15px;
        padding: 12px;
      }
    }
  </style>
  </style>
</head>
<body>
  <div class="container">
    <h2>Hello, <?= htmlspecialchars($user['username'], ENT_QUOTES) ?> 👋</h2>
    <p>Total Paid: <strong><?= number_format($totalPaid, 2) ?> KES</strong></p>

    <?php if ($notice): ?>
      <div class="notice"><?= htmlspecialchars($notice) ?></div>
    <?php endif; ?>

    <?php if ($msg): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <?php if ($isActive): ?>
      <div class="msg">✅ Your account is active! <a href="dashboard.php">Go to Dashboard</a></div>
    <?php elseif ($remaining > 0): ?>
      <div class="notice">You need to pay <strong><?= number_format($remaining, 2) ?> KES</strong> more to activate your account.</div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        
        <div class="form-group">
          <label for="amount">Amount (KES)</label>
          <input type="number" name="amount" id="amount" required min="1" 
                 value="<?= min($remaining, 100) ?>" 
                 max="<?= $remaining ?>" />
        </div>
        
        <div class="form-group">
          <label for="phone">Phone Number (MPESA)</label>
          <input type="tel" name="phone" id="phone" required 
                 pattern="[0-9]{9,12}" 
                 title="Enter valid MPESA number (e.g., 0712345678)"
                 value="<?= !empty($user['phone']) ? htmlspecialchars($user['phone']) : '' ?>" />
        </div>
        
        <button type="submit">PAY WITH MPESA</button>
      </form>
    <?php else: ?>
      <div class="msg">✅ Payment complete! <a href="dashboard.php">Activate Account</a></div>
    <?php endif; ?>

    <div class="whatsapp-link">
      <p>Trouble? <a href="https://wa.me/254111507271?text=Hello%20I%20have%20a%20payment%20problem" target="_blank">WhatsApp Us</a></p>
    </div>
         <a href="signin.php" style="color:green;">← Back to LOGIN</a>
  </div>

  <script>
    // Auto-format phone number input
    document.getElementById('phone')?.addEventListener('input', function(e) {
      this.value = this.value.replace(/\D/g, '');
    });

    // Set max amount to remaining balance needed
    document.getElementById('amount')?.addEventListener('change', function() {
      const remaining = <?= $remaining ?>;
      if (this.value > remaining) {
        this.value = remaining;
      }
    });
  </script>
</body>
</html>