<?php
function getCrashPoint($serverSeed, $clientSeed, $nonce) {
    $hash = hash_hmac('sha256', "$clientSeed:$nonce", $serverSeed);
    $num = hexdec(substr($hash, 0, 13));
    $max = bcpow('2', '52');
    $result = bcdiv($max, bcsub($max, $num), 6);

    // House edge: 1%
    $crash = floor((1 / (float)$result) * 100) / 100;
    return max(1.00, round($crash, 2));
}

// Example
$serverSeed = 'SECRET123';
$clientSeed = 'USER456';
$nonce = 1;

echo getCrashPoint($serverSeed, $clientSeed, $nonce);
