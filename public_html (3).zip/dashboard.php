<?php
session_start();
require 'config.php';
date_default_timezone_set('Africa/Nairobi');

$inactiveLimit = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $inactiveLimit)) {
    session_unset(); session_destroy();
    header("Location: signin.php?timeout=1"); exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php'); exit;
}

$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy(); header('Location: signin.php'); exit;
}

if ($user['status'] !== 'active') {
    session_destroy(); header("Location: payment.php?notactive=1"); exit;
}

$currency = 'KES';
$level1_bonus = 50;
$level2_bonus = 20;

$fields = ['capital','welcome_bonus','wallet_balance','total_earned','total_withdrawn','monthly_earned','monthly_withdrawn','pending','crash_balance','deposit_balance','survey_balance'];

foreach ($fields as $f) {
    if (!isset($user[$f])) {
        $user[$f] = 0;
    }
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id = ?");
$stmt->execute([$user['id']]);
$withdraw_count = (int) $stmt->fetchColumn();
$withdraw_charges = $withdraw_count * 30;
$user['total_earned'] =
    $user['wallet_balance'] +
    $user['welcome_bonus'] +
    $user['pending'] +
    $user['total_withdrawn'] +
    $user['deposit_balance'] +
    $user['survey_balance'] +
    $user['crash_balance'] +
    $withdraw_charges;

$user['referred_by'] = $user['referred_by'] ?? null;

$upline_name = null;
if ($user['referred_by']) {
    $stmt = $pdo->prepare("SELECT username FROM Users WHERE username = ?");
    $stmt->execute([$user['referred_by']]);
    $upline_name = $stmt->fetchColumn();
}

$stmt = $pdo->prepare("SELECT username, email FROM Users WHERE referred_by = ?");
$stmt->execute([$user['username']]);
$level1 = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT u2.username, u2.email
    FROM Users u1
    JOIN Users u2 ON u2.referred_by = u1.username
    WHERE u1.username = ?
");
$stmt->execute([$user['username']]);
$level2 = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM Users WHERE referred_by = ?");
$stmt->execute([$user['username']]);
$total_referrals = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM Users WHERE referred_by = ? AND status = 'active'");
$stmt->execute([$user['username']]);
$activated_referrals = (int)$stmt->fetchColumn();


$today = date('Y-m-d'); // Define the date first
// Now you can safely use $today
$stmt = $pdo->prepare("SELECT activated_today FROM daily_stats WHERE upline_username = ? AND date = ?");
$stmt->execute([$user['username'], $today]);
$activated_today = (int)($stmt->fetchColumn() ?? 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>FlexHela Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" type="text/css" href="css.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
  
    .card-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .card i, .card1 i {
      margin-left: 10px;
    }

    .fa-animated {
      transition: transform 0.3s ease-in-out;
    }

    .fa-animated:hover {
      transform: scale(1.2) rotate(5deg);
    }

    .fa-spin-slow {
      animation: spin 4s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <div class="container">

    <div class="header">
      <div class="logo">FLEXHELA</div>
      <div class="dropdown">
        <button class="dropdown-btn">Menu</button>
        <div class="dropdown-content">
          <a href="dashboard.php">Home</a>
          <a href="profile.php">Profile</a>
          <a href="https://chat.whatsapp.com/KC9RdJzoxed4QBqFPiahkD">Whatsapp Community</a>
          <a href="deposit.php">Deposit</a>
          <a href="withdraw.php">Withdraw</a>
          <a href="withdraw-history.php">Withdraw History</a>
          <a href="claim.php">Welcome Bonus</a>
          <a href="survey.php">Solve Surveys</a>
          <a href="crash.php">Crash Game</a>
          <a href="payforclient.php">Pay for Client</a>
          <a href="level1.php">Level 1 Referrals</a>
          <a href="level2.php">Level 2 Referrals</a>
          <a href="https://api.whatsapp.com/send?text=FLEXHELA%20SUMMARY%0A%0A%F0%9F%87%B0%F0%9F%87%AA%F0%9F%87%B0%F0%9F%87%AACOMING%20SOON%F0%9F%87%B0%F0%9F%87%AA%F0%9F%87%B0%F0%9F%87%AA%0A%0AActivation%20fee%20-%20100/-%0A%0AWAYS%20OF%20EARNING%0A1%E2%83%A3AFFILIATE%20MARKETING%0A%E2%9C%85%E2%9C%85%E2%9C%85Level%201%20=%2050%20KES%20%0A%E2%9C%85%E2%9C%85Level%202%20=%2020%20KES%0A%0A2%E2%83%A3MONEY%20NOTIFICATIONS%20MAILS%0AUsers%20will%20get%20notified%20for%20affiliate%20commissions,%20earnings%20and%20when%20Withdrawing%20through%20email%E2%9C%8D%0A%0A3%E2%83%A3PAY%20FOR%20CLIENT%0AYou%20will%20be%20able%20to%20pay%20fee%20for%20your%20downline%20or%20any%20other%20client%20in%20your%20team%20and%20activate%20them.%0A%0A4%E2%83%A3SOLVE%20SURVEYS%F0%9F%92%AB%0AFree%20daily%20trivia%20available%20for%20all%20active%20users.%20Answer%20and%20earn%20accordingly.%0A%0A5%E2%83%A3CRASH%20GAME%F0%9F%9B%A9%0APlay%20crash%20and%20earn%20when%20you%20cash%20out%20in%20time%20before%20burst.%0A%0A6%E2%83%A3FINANCIAL%20SAVING%F0%9F%92%B0%0AWe%20have%20the%20deposit%20option,%20where%20you%20can%20deposit%20money%20and%20save%20via%20our%20platform%20and%20withdraw%20it%20anytime%20when%20ready%20to%20use%20it.%0A%0A7%E2%83%A3CUSTOMER%20CARE%E2%98%8E%0ACustomer%20Care%20contact%20will%20be%20available%20on%20the%20site%20so%20incase%20of%20any%20issue,,%20it%20will%20be%20sorted%20out%20easily%0A%0A8%E2%83%A3AGENT%20BONUSES%F0%9F%92%B0%0AOur%20best%20working%20agents%20will%20be%20awarded%20every%20week%20depending%20on%20work%20done%F0%9F%98%87%0A%0A%F0%9F%86%95OTHER%20PRIVILEGES%F0%9F%86%95%0A%E2%9C%85Get%20a%20free%20Welcome%20bonus%20of%20KES%2020%20once%20you%20join.%0A%E2%9C%85Able%20to%20reset%20your%20password%0A%E2%9C%85Easy%20registration%20process%0A%E2%9C%85Automatic%20activations%0A%E2%9C%85Instant%20withdrawals%0A%E2%9C%85User%20friendly%20Dashboard%0A%0AAll%20the%20best%F0%9F%A4%8ERegards.%E2%9A%A1" target="_blank">FLEXHELA SUMMARY</a>
          <a href="logout.php">Log out</a>
        </div>
      </div>
    </div>

    <h2>Hello <?= htmlspecialchars($user['username']) ?> 👋</h2><br>

    <div class="notice">
      Today is the Tomorrow you worried about Yesterday 😊.
      Stop worrying & Focus. Earn big by sharing & referring your friends to Flexhela. When we work together, great things happen! ❤
    </div>

    <!-- Capital & Total Earned -->
    <div class="card1">
      <div class="split">
        <div class="side card-flex">
          <div>
            <p>Capital</p>
            <p style="font-weight: bold;"><?= $currency ?>. <?= number_format($user['capital'], 2) ?></p>
          </div>
          <i class="fas fa-piggy-bank fa-2x fa-animated" style="color: #4caf50;"></i>
        </div>
        <hr />
        <div class="side card-flex">
          <div>
            <p>Total Earned</p>
            <p style="font-weight: bold;" id="totalEarned"><?= $currency ?>. <?= number_format($user['total_earned'], 2) ?></p>
          </div>
          <i class="fas fa-chart-line fa-2x fa-animated" style="color: #2196f3;"></i>
        </div>
      </div>
    </div><br />

    <!-- Wallet Breakdown -->
    <div class="grid">
      <div class="card">
        <div class="card-flex">
          <div>
            <p>Wallet Balance</p>
            <p id="walletBalance"><?= $currency ?>. <?= number_format($user['wallet_balance'], 2) ?></p>
          </div>
          <i class="fas fa-wallet fa-2x fa-animated"></i>
        </div>
      </div>

      <div class="card">
        <div class="card-flex">
          <div>
            <p>Welcome Bonus</p>
            <p><?= $currency ?>. <?= number_format($user['welcome_bonus'], 2) ?></p>
          </div>
          <i class="fas fa-gift fa-2x fa-animated"></i>
        </div>
      </div>

      <div class="card">
        <div class="card-flex">
          <div>
            <p>Pending</p>
            <p><?= $currency ?>. <?= number_format($user['pending'], 2) ?></p>
          </div>
          <i class="fas fa-hourglass-half fa-2x fa-animated fa-spin-slow"></i>
        </div>
      </div>

      <div class="card">
        <div class="card-flex">
          <div>
            <p>Total Withdrawn</p>
            <p><?= $currency ?>. <?= number_format($user['total_withdrawn'], 2) ?></p>
          </div>
          <i class="fas fa-money-bill-wave fa-2x fa-animated"></i>
        </div>
      </div>
    </div><br />

    <div class="card1" style="background-color: rgb(71, 168, 71);">
      <div class="card-flex">
        <div>
          <p>Deposit Balance</p>
          <p><?= $currency ?>. <?= number_format($user['deposit_balance'], 2) ?></p>
        </div>
        <i class="fas fa-arrow-down fa-2x fa-animated fa-spin-slow" style="color:white;"></i>
      </div>
    </div><br />

    <div class="card1" style="background-color: orange;">
      <div class="card-flex">
        <div>
          <p>Solve Surveys</p>
          <p><?= $currency ?>. <?= number_format($user['survey_balance'], 2) ?></p>
        </div>
        <i class="fas fa-pen-to-square fa-2x fa-animated" style="color:white;"></i>
      </div>
    </div><br />

    <div class="card1" style="background-color: rgb(71, 168, 71);">
      <div class="card-flex">
        <div>
          <p>Crash Balance</p>
          <p><?= $currency ?>. <?= number_format($user['crash_balance'], 2) ?></p>
          <a href="crash.php"><button class="btn">Play Crash</button></a>
        </div>
        <i class="fas fa-rocket fa-2x fa-animated fa-spin-slow" style="color:white;"></i>
      </div>
    </div><br />


<!-- Daily Bonus -->
<div class="card" style="border-radius:6px; border: solid orange 1px;">
  <h2 style="text-align:center;">Daily Bonus</h2>
  <?php
    // Set up
    $today = date('Y-m-d');

    // Fetch activated_today from daily_stats
    $stmt = $pdo->prepare("SELECT activated_today FROM daily_stats WHERE upline_id = ? AND date = ?");
    $stmt->execute([$user['id'], $today]);
    $activated_today = (int)$stmt->fetchColumn();

    $daily_target = 10;
    $target_hit = $activated_today;
    $how_much_to_go = max(0, $daily_target - $target_hit);

    // Check if already claimed
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM daily_bonus_claims WHERE user_id = ? AND claim_date = ?");
    $stmt->execute([$user['id'], $today]);
    $already_claimed = (int)$stmt->fetchColumn();
  ?>
  <p>Today's Target: <?= $daily_target ?> points</p>
  <p>Target Reward: 10/10 (KES. 30)</p>
  <p>Target Hit: <?= $activated_today ?> points</p>
  <p>How Much to Go: <span id="howMuchToGo"><?= $how_much_to_go ?> points</span></p>

  <div style="text-align:center;">
    <button id="claimBonusBtn" class="btn btn-center" style="background-color: rgb(71, 168, 71);" <?= ($already_claimed || $how_much_to_go > 0) ?  : '' ?>>
      <?= $already_claimed ? 'Claimed' : 'Tap Here to Claim' ?>
    </button>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('claimBonusBtn');

  btn?.addEventListener('click', function () {
    fetch('claim_bonus.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'ajax=1' // Signal that it's an AJAX request
    })
    .then(res => res.json())
    .then(data => {
      if (data.status === 'success') {
        showPopup(data.message, 'green');
        btn.disabled = true;
        btn.textContent = 'Claimed';
      } else {
        showPopup(data.message, 'orange');
      }
    })
    .catch(() => {
      showPopup('Something went wrong!', 'red');
    });
  });

  function showPopup(message, color = 'blue') {
    const popup = document.createElement('div');
    popup.textContent = message;
    popup.style.position = 'fixed';
    popup.style.bottom = '20px';
    popup.style.left = '50%';
    popup.style.transform = 'translateX(-50%)';
    popup.style.background = color;
    popup.style.color = '#fff';
    popup.style.padding = '10px 20px';
    popup.style.borderRadius = '8px';
    popup.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)';
    popup.style.zIndex = '1000';
    document.body.appendChild(popup);
    setTimeout(() => popup.remove(), 4000);
  }
});
</script>



    <!-- Referral Trend -->
    <br />
    <div class="section">
      <div class="section-title">Referrals Trend</div>
      <div class="card" style="background-color: rgb(71, 168, 71);">
        <p>Total Referrals: <?= (int)$total_referrals ?></p>
        <hr />
        <p>Activated: <?= (int)$activated_referrals ?></p>
        <a href="level1.php"><button class="btn">View Referrals</button></a>
      </div>
    </div>

    <!-- Referral Link -->
    <div class="referral-box">
      <p>Earn <strong style="color:#22c55e;"><?= $currency ?> <?= $level1_bonus ?></strong> for level 1 and <strong style="color:#22c55e;"><?= $currency ?> <?= $level2_bonus ?></strong> for level 2 referrals.</p>
      <div class="referral-input-group">
        <input type="text" id="referralLink" class="referral-input" readonly
          value="https://flexhela.com/signup.php?ref=<?= urlencode($user['username']) ?>" />
        <button class="copy-btn" onclick="copyReferralLink()">Copy</button>
      </div>
    </div>

    <!-- Profile Summary -->
    <div style="border: solid rgb(89, 89, 219) 1px; border-radius: 10px; padding: 25px; max-width: 500px; margin: 40px auto; box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);">
      <h3 style="text-align: center;">User Profile</h3>
      <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Upline:</strong> <?= $upline_name ? htmlspecialchars($upline_name) : 'Flexhela' ?></p>
      <p><strong>Joined:</strong> <?= htmlspecialchars($user['created_at']) ?></p><br>
      <a href="reset_password.php"><button class="btn" style="display: block; margin: 0 auto">Reset Password</button></a>
    </div>

    <br />
    <p style="font-size: smaller; text-align: center;">Crafted with ❤ All Rights Reserved.</p>
  </div>
  <script>
function copyReferralLink() {
  const input = document.getElementById("referralLink");
  input.select();
  input.setSelectionRange(0, 99999); // For mobile devices
  document.execCommand("copy");

  // Optional: Visual feedback
  alert("Referral link copied!");
}
</script>

</body>
</html>
