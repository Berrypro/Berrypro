<?php
session_start();
require 'config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Check day
$allowedDays = ['Monday', 'Tuesday', 'Thursday', 'Saturday'];
$today = date('l');

if (!in_array($today, $allowedDays)) {
    echo "<h3 style='text-align:center;margin-top:50px;'>Surveys are only available on Monday, Tuesday, Thursday, and Saturday.</h3>";
    exit;
}

// Check if already taken today
$check = $pdo->prepare("SELECT id FROM survey_results WHERE user_id = ? AND DATE(submitted_at) = CURDATE()");
$check->execute([$userId]);
if ($check->rowCount() > 0) {
    echo "<h3 style='text-align:center;margin-top:50px;'>You've already taken today's survey. Please come back on the next eligible day.</h3>";
    exit;
}

// Define 6 rotating sets
$questionSets = [
    [ // Set 1
        ["What is Kenya’s capital?", "Mombasa", "Nairobi", "Kisumu", "Nakuru", 2],
        ["Which currency is used in Kenya?", "Dollar", "Pound", "Euro", "Shilling", 4],
        ["How many counties are in Kenya?", "47", "52", "36", "60", 1],
        ["Which is the tallest mountain in Kenya?", "Elgon", "Kenya", "Longonot", "Aberdare", 2],
        ["What is Kenya’s official language?", "English", "Swahili", "Both", "French", 3],
        ["Which lake is in Kenya?", "Lake Victoria", "Lake Chad", "Lake Malawi", "Lake Tanganyika", 1],
        ["What is Kenya known for?", "Tea", "Oil", "Cars", "Diamonds", 1],
        ["Which animal is NOT in the Big Five?", "Lion", "Giraffe", "Elephant", "Buffalo", 2],
        ["Which ocean borders Kenya?", "Atlantic", "Arctic", "Pacific", "Indian", 4],
        ["Where is Jomo Kenyatta Airport?", "Nakuru", "Mombasa", "Nairobi", "Kisumu", 3],
    ],
    [ // Set 2
        ["What color is on the Kenyan flag?", "Pink", "Blue", "Black", "Orange", 3],
        ["Which body governs football in Kenya?", "FIFA", "FKF", "CAF", "UEFA", 2],
        ["Currency code for Kenyan shilling?", "KES", "KSH", "USD", "KSS", 1],
        ["Where is Lake Naivasha?", "Rift Valley", "Central", "Nyanza", "Eastern", 1],
        ["Who is Kenya’s founding president?", "Ruto", "Moi", "Jomo Kenyatta", "Uhuru", 3],
        ["Which tribe is largest in Kenya?", "Maasai", "Luhya", "Luo", "Kikuyu", 4],
        ["What is Nairobi called?", "Sun City", "Green City", "Safari City", "City in the Sun", 4],
        ["Kenya's independence year?", "1960", "1963", "1972", "1980", 2],
        ["Which river is longest in Kenya?", "Athi", "Tana", "Ewaso Nyiro", "Yala", 2],
        ["Where is Diani Beach?", "Lamu", "Malindi", "Mombasa", "Kwale", 4],
    ],
    [ // Set 3
        ["Official residence of Kenyan president?", "State Lodge", "Kasarani", "State House", "Parliament", 3],
        ["Most spoken language in Kenya?", "English", "Swahili", "Luo", "Gikuyu", 2],
        ["Main crop in central Kenya?", "Maize", "Wheat", "Tea", "Coffee", 4],
        ["Which tribe is known for jumping dance?", "Luhya", "Turkana", "Maasai", "Kalenjin", 3],
        ["Kenya lies on which continent?", "Europe", "Asia", "Africa", "Australia", 3],
        ["Kenya is famous for?", "Deserts", "Safari", "Caves", "Mountains", 2],
        ["Kenya borders how many countries?", "3", "5", "6", "4", 3],
        ["Which is not a Kenyan bank?", "KCB", "Equity", "Barclays", "FNB", 4],
        ["Kenya’s main airport?", "Eldoret", "JKIA", "Wilson", "Moi", 2],
        ["Which language is not taught in Kenya?", "German", "Spanish", "Russian", "Mandarin", 3],
    ],
    [ // Set 4
        ["Capital of Turkana County?", "Kitale", "Lodwar", "Kakuma", "Lokichar", 2],
        ["Which national park is near Nairobi?", "Amboseli", "Nairobi NP", "Tsavo", "Meru", 2],
        ["Largest lake in Africa?", "Tanganyika", "Albert", "Victoria", "Kivu", 3],
        ["What’s the color of MPESA logo?", "Red", "Green", "Blue", "Purple", 2],
        ["Popular dish with ugali?", "Pizza", "Pilau", "Chapati", "Sukuma", 4],
        ["Kenya's currency symbol?", "K$", "KES", "Ksh", "Kc", 3],
        ["Maasai wear?", "Suits", "Lesos", "Shukas", "Jeans", 3],
        ["Vehicle plates start with?", "K", "N", "E", "T", 1],
        ["Common tree in Kenya?", "Baobab", "Acacia", "Pine", "Mango", 2],
        ["Kenya's official religion?", "Christianity", "Islam", "Hindu", "None", 4],
    ],
    [ // Set 5
        ["When is Madaraka Day?", "June 1", "Oct 20", "Dec 12", "May 1", 1],
        ["Popular Kenyan marathon?", "Safari Run", "Great Run", "Nairobi Marathon", "Athens", 3],
        ["Color in Kenyan flag?", "Red", "Pink", "Gray", "Brown", 1],
        ["County with Mombasa?", "Mombasa", "Kwale", "Kilifi", "Tana River", 1],
        ["What tribe is known for bulls?", "Luhya", "Maasai", "Turkana", "Kalenjin", 3],
        ["Kenya’s largest port?", "Kisumu", "Mombasa", "Malindi", "Lamu", 2],
        ["Kenya's staple food?", "Rice", "Beans", "Ugali", "Matoke", 3],
        ["Youngest president of Kenya?", "Kibaki", "Moi", "Ruto", "Uhuru", 3],
        ["Most exported crop?", "Tea", "Coffee", "Maize", "Sorghum", 1],
        ["Which phone is common in Kenya?", "Samsung", "Itel", "Infinix", "All of these", 4],
    ],
    [ // Set 6
        ["Which animal is only in Kenya?", "Zebra", "Rhino", "Hirola", "Buffalo", 3],
        ["Kenya’s 2nd President?", "Kenyatta", "Moi", "Uhuru", "Ruto", 2],
        ["Kenya's national flower?", "Hibiscus", "Rose", "Orchid", "Lilac", 1],
        ["Main religion?", "Hindu", "Muslim", "Christianity", "Buddhism", 3],
        ["Common hill in Nairobi?", "Kilimani", "Ngong Hills", "Mt. Kenya", "Mt. Elgon", 2],
        ["National dress?", "Kitenge", "Ankara", "Kimono", "Dashiki", 1],
        ["Safari means?", "Hike", "Journey", "Dance", "Food", 2],
        ["Largest tribe?", "Luo", "Luhya", "Kalenjin", "Kikuyu", 4],
        ["Common drink?", "Tea", "Coffee", "Milk", "Soda", 1],
        ["Wife of President is called?", "Queen", "Prime Lady", "First Lady", "Mother of State", 3],
    ]
];

$dayIndex = date('z') % count($questionSets);
$questions = $questionSets[$dayIndex];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Survey</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body {
      background: #111;
      color: #fff;
      font-family: Arial, sans-serif;
      padding: 20px;
      margin: 0;
    }

    h2 {
      text-align: center;
      color: #22c55e;
      font-size: 24px;
    }

    .timer {
      text-align: center;
      font-size: 20px;
      color: #facc15;
      margin: 20px 0;
    }

    .question {
      background: #222;
      padding: 18px;
      margin-bottom: 20px;
      border-radius: 10px;
      font-size: 18px;
    }

    .question p {
      margin-bottom: 10px;
    }

    label {
      display: block;
      margin: 8px 0;
      font-size: 17px;
      line-height: 1.4;
    }

    input[type="radio"] {
      transform: scale(1.2);
      margin-right: 10px;
    }

    button {
      width: 100%;
      padding: 15px;
      background: #22c55e;
      border: none;
      border-radius: 10px;
      font-weight: bold;
      color: #000;
      font-size: 18px;
      cursor: pointer;
      margin-top: 25px;
    }

    button:hover {
      background: #16a34a;
    }

    @media (max-width: 600px) {
      h2 {
        font-size: 22px;
      }

      .question {
        padding: 14px;
        font-size: 17px;
      }

      label {
        font-size: 16px;
      }

      button {
        font-size: 17px;
        padding: 14px;
      }

      .timer {
        font-size: 18px;
      }
    }
  </style>
</head>
<body>

<h2>Daily Survey - Earn KES 2 per Correct Answer</h2>
<div class="timer">Time left: <span id="timer">60</span>s</div>

<form id="surveyForm" method="POST" action="submit_survey.php">
  <?php foreach ($questions as $index => $q): ?>
    <div class="question">
      <p><strong><?= ($index+1) ?>. <?= htmlspecialchars($q[0]) ?></strong></p>
      <?php for ($i=1; $i<=4; $i++): ?>
        <label>
          <input type="radio" name="q<?= $index ?>" value="<?= $i ?>" required>
          <?= htmlspecialchars($q[$i]) ?>
        </label>
      <?php endfor; ?>
      <input type="hidden" name="correct<?= $index ?>" value="<?= $q[5] ?>">
    </div>
  <?php endforeach; ?>
  <input type="hidden" name="user_id" value="<?= $userId ?>">
  <button type="submit">Submit Survey</button>
</form>

<script>
  let timeLeft = 60;
  const timer = document.getElementById("timer");
  const form = document.getElementById("surveyForm");
  const interval = setInterval(() => {
    timeLeft--;
    timer.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(interval);
      form.submit();
    }
  }, 1000);
</script>

</body>
</html>
