<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

try {
    $pdo->beginTransaction();
    
    // 1. End current round (set ended_at for previous round)
    $stmt = $pdo->prepare("
        UPDATE crash_rounds 
        SET is_active = 0, 
            ended_at = NOW() 
        WHERE is_active = 1
    ");
    $stmt->execute();
    
    // 2. Generate new seeds
    $serverSeed = bin2hex(random_bytes(32)); // Server secret
    $clientSeed = bin2hex(random_bytes(16)); // Public seed
    $nonce = $_SESSION['crash_nonce'] ?? 0;
    
    // 3. Calculate crash point
    $hash = hash_hmac('sha256', $clientSeed.'-'.$nonce, $serverSeed);
    $hex = substr($hash, 0, 8);
    $int = hexdec($hex);
    $crashPoint = max(1.10, min(10.00, (($int % 9000) / 1000) + 1));
    
    // 4. Insert new round with all required fields
    $stmt = $pdo->prepare("
        INSERT INTO crash_rounds 
        (start_time, crash_point, is_active, server_seed, client_seed, nonce) 
        VALUES (NOW(), ?, 1, ?, ?, ?)
    ");
    $stmt->execute([$crashPoint, $serverSeed, $clientSeed, $nonce]);
    
    // 5. Increment nonce for next round
    $_SESSION['crash_nonce'] = $nonce + 1;
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'crash_point' => $crashPoint,
        'server_seed_hash' => hash('sha256', $serverSeed), // For verification
        'client_seed' => $clientSeed,
        'nonce' => $nonce
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Round initialization error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'debug_info' => [
            'serverSeed' => $serverSeed ?? null,
            'clientSeed' => $clientSeed ?? null,
            'nonce' => $nonce ?? null
        ]
    ]);
}
?>