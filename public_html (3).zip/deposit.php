<?php
session_start();
require 'config.php';

// DEBUGGING - show all errors during development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check session
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['status'] !== 'active') {
    header("Location: dashboard.php");
    exit;
}

// Show message after redirect
$notice = $_GET['error'] ?? '';
$msg = $_GET['success'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = floatval($_POST['amount']);
    $phone = trim($_POST['phone']);

    if ($amount <= 0 || empty($phone)) {
        header("Location: deposit.php?error=" . urlencode("Enter a valid amount and phone number."));
        exit;
    }

    // Prepare STK push request
    $data = json_encode([
        "amount" => $amount,
        "phone" => $phone,
        "load_response" => true
    ]);

    // NOTE: Replace with actual BoogieCoin API endpoint
    $ch = curl_init("https://api.boogiecoin.com/stkpush");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Api-Secret: eythb4vrytju' // ← Replace with actual
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        $error = "cURL Error: " . curl_error($ch);
        curl_close($ch);
        header("Location: deposit.php?error=" . urlencode($error));
        exit;
    }

    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $result = json_decode($response, true);

    // Validate response
    if (!$response) {
        header("Location: deposit.php?error=" . urlencode("No response from BoogieCoin."));
        exit;
    } elseif (!is_array($result)) {
        header("Location: deposit.php?error=" . urlencode("Invalid JSON: " . $response));
        exit;
    } elseif ($httpcode !== 200) {
        header("Location: deposit.php?error=" . urlencode("API Error [$httpcode]: " . $response));
        exit;
    } elseif (!isset($result['Status']) || $result['Status'] !== true) {
        header("Location: deposit.php?error=" . urlencode("BoogieCoin payment failed: " . json_encode($result)));
        exit;
    }

    // Process database insert
    try {
        $pdo->beginTransaction();

        // Save deposit
        $insert = $pdo->prepare("INSERT INTO deposits (user_id, msisdn, amount_deposited, method, status, created_at) VALUES (?, ?, ?, 'STK Push', 'completed', NOW())");
        $insert->execute([$user_id, $phone, $amount]);

        // Update balance
        $update = $pdo->prepare("UPDATE Users SET deposit_balance = deposit_balance + ? WHERE id = ?");
        $update->execute([$amount, $user_id]);

        $pdo->commit();

        header("Location: deposit.php?success=" . urlencode("KES " . number_format($amount, 2) . " deposited successfully!"));
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Deposit DB Error: " . $e->getMessage());
        header("Location: deposit.php?error=" . urlencode("Database error during transaction."));
        exit;
    }
}

// Fetch deposit history
$historyStmt = $pdo->prepare("SELECT msisdn, amount_deposited, method, status, created_at FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$historyStmt->execute([$user_id]);
$depositHistory = $historyStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Make a Deposit via STK Push</title>
<style>
    body {
        background: black;
        color: #ecf0f1;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        padding: 20px;
        margin: 0;
    }
    .container {
        max-width: 600px;
        margin: 0 auto;
        background: #2c3e50;
        padding: 25px;
        border-radius: 10px;
        box-sizing: border-box;
    }
    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 14px;
        margin-bottom: 20px;
        border: 1px solid #34495e;
        border-radius: 5px;
        background: #2c3e50;
        color: #fff;
        font-size: 16px;
        box-sizing: border-box;
    }
    input:focus {
        border-color: #2980b9;
        outline: none;
    }
    button {
        width: 100%;
        padding: 14px;
        background: #2980b9;
        border: none;
        border-radius: 5px;
        font-weight: bold;
        color: white;
        font-size: 16px;
        cursor: pointer;
    }
    button:hover {
        background: #1c5980;
    }
    .notice {
        background: #fffbe5;
        color: #8a6d3b;
        padding: 12px;
        border-radius: 5px;
        margin-bottom: 20px;
        font-size: 14px;
    }
    .msg {
        background-color: #e8f5e9;
        color: #2e7d32;
        padding: 12px;
        border-left: 5px solid #2e7d32;
        margin-bottom: 20px;
        border-radius: 4px;
        font-size: 14px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 30px;
        font-size: 15px;
    }
    table th, table td {
        border: 1px solid #34495e;
        padding: 12px;
        text-align: left;
    }
    table th {
        background-color: #34495e;
    }
    .status-completed {
        color: #27ae60;
        font-weight: bold;
    }
    .status-failed {
        color: #c0392b;
        font-weight: bold;
    }

    @media (max-width: 600px) {
        body {
            padding: 10px;
        }
        .container {
            padding: 15px;
        }
        input, button {
            font-size: 16px;
            padding: 14px;
        }
        table th, table td {
            font-size: 14px;
            padding: 10px;
        }
    }
</style>
</head>
<body>
<div class="container">
    <h2>Hello, <?= htmlspecialchars($user['username']) ?> 👋</h2>
    <p><strong>Your Deposit Balance:</strong> KES <?= number_format($user['deposit_balance'], 2) ?></p>

    <?php if ($notice): ?>
        <div class="notice"><?= htmlspecialchars($notice) ?></div>
    <?php endif; ?>

    <?php if ($msg): ?>
        <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <label for="amount">Amount (KES)</label>
        <input type="number" name="amount" id="amount" step="0.01" min="0.01" required placeholder="Enter deposit amount" />

        <label for="phone">Phone Number (07...)</label>
        <input type="text" name="phone" id="phone" required placeholder="e.g. 0712345678" />

        <button type="submit">Make Deposit</button>
    </form><br>
     <a href="dashboard.php" style="color:green;">← Back to Dashboard</a>
     <br>

    <h3>Recent Deposit History</h3>
    <?php if (count($depositHistory) === 0): ?>
        <p>No deposits found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Amount (KES)</th>
                    <th>Phone</th>
                    <th>Method</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($depositHistory as $dep): ?>
                    <tr>
                        <td><?= htmlspecialchars(date("Y-m-d H:i", strtotime($dep['created_at']))) ?></td>
                        <td><?= number_format($dep['amount_deposited'], 2) ?></td>
                        <td><?= htmlspecialchars($dep['msisdn']) ?></td>
                        <td><?= htmlspecialchars($dep['method']) ?></td>
                        <td class="status-<?= strtolower($dep['status']) ?>">
                            <?= htmlspecialchars(ucfirst($dep['status'])) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
