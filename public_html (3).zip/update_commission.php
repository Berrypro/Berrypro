<?php
require 'config.php';

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) exit('User ID missing.');

// Fetch the now-active user
$stmt = $pdo->prepare("SELECT id, username, status, referred_by FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') exit('User not found or not active.');

// Check if bonus already credited
$stmt = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE referred_id = ?");
$stmt->execute([$user['id']]);
$already_credited = $stmt->fetchColumn();

if ($already_credited) exit('Bonus already given.');

// Find upline
$stmt = $pdo->prepare("SELECT id, username, email, referred_by FROM Users WHERE username = ?");
$stmt->execute([$user['referred_by']]);
$upline = $stmt->fetch();

if (!$upline) exit('Upline not found.');

// Determine Level
$level = $upline['referred_by'] ? 2 : 1;
$amount = $level === 1 ? 50 : 20;

// Credit upline
$pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ? WHERE id = ?")
    ->execute([$amount, $amount, $upline['id']]);

// Log bonus
$pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at) VALUES (?, ?, ?, ?, NOW())")
    ->execute([$upline['id'], $user['id'], $level, $amount]);

// Send email
$subject = "Referral Activated!";
$message = "Hello " . htmlspecialchars($upline['username']) . ",\n\n" .
           "Your referral " . htmlspecialchars($user['username']) . " has activated their account.\n" .
           "You have earned a commission of KES $amount.\n\n" .
           "Regards,\nFlexHela Team";
$headers = "From: no-reply@flexhela.com\r\nContent-Type: text/plain";

mail($upline['email'], $subject, $message, $headers);

echo 'Commission and email sent successfully.';
