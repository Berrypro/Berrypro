<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in.']);
    exit;
}

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') {
    echo json_encode(['success' => false, 'message' => 'Invalid user or inactive account.']);
    exit;
}

$today = date('Y-m-d');
$target = 10;

// Count activated referrals
$stmt = $pdo->prepare("SELECT COUNT(*) FROM Users WHERE referred_by = ? AND status = 'active'");
$stmt->execute([$user['username']]);
$activated = (int)$stmt->fetchColumn();

if ($activated < $target) {
    echo json_encode(['success' => false, 'message' => 'Target not yet achieved.']);
    exit;
}

// Check if already claimed
$stmt = $pdo->prepare("SELECT COUNT(*) FROM daily_bonus_claims WHERE user_id = ? AND claim_date = ?");
$stmt->execute([$user['id'], $today]);
if ($stmt->fetchColumn() > 0) {
    echo json_encode(['success' => false, 'message' => 'Daily bonus already claimed.']);
    exit;
}

// Grant bonus (FCFA 300)
$bonusAmount = 300;
$newWallet = $user['wallet_balance'] + $bonusAmount;
$newTotalEarned = $user['total_earned'] + $bonusAmount;

// Update user's balances
$stmt = $pdo->prepare("UPDATE Users SET wallet_balance = ?, total_earned = ? WHERE id = ?");
$stmt->execute([$newWallet, $newTotalEarned, $user['id']]);

// Record the claim
$stmt = $pdo->prepare("INSERT INTO daily_bonus_claims (user_id, claim_date) VALUES (?, ?)");
$stmt->execute([$user['id'], $today]);

echo json_encode([
    'success' => true,
    'message' => 'FCFA 300 bonus claimed successfully!',
    'wallet_balance' => number_format($newWallet, 2),
    'total_earned' => number_format($newTotalEarned, 2)
]);
