<?php
session_start();
require 'config.php';
date_default_timezone_set('Africa/Nairobi');

$inactiveLimit = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $inactiveLimit)) {
    session_unset(); session_destroy();
    header("Location: signin.php?timeout=1"); exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php'); exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy(); header('Location: signin.php'); exit;
}

if ($user['status'] !== 'active') {
    session_destroy(); header("Location: payment.php?notactive=1"); exit;
}

// Kenya-only logic
$currency = 'FCFA';
$level1_bonus = 1500;
$level2_bonus = 1000;

// Define relevant fields
$fields = ['capital','welcome_bonus','wallet_balance','total_earned','total_withdrawn','monthly_earned','monthly_withdrawn','pending','crash_balance','deposit_balance','survey_balance'];

foreach ($fields as $f) {
    if (!isset($user[$f])) {
        $user[$f] = 0;
    }
}

// ✅ Recalculate total earned dynamically
$stmt = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id = ?");
$stmt->execute([$user['id']]);
$withdraw_count = (int) $stmt->fetchColumn();
$withdraw_charges = $withdraw_count * 300; // e.g. fixed FCFA 300 per withdrawal
$user['total_earned'] =
    $user['wallet_balance'] +
    $user['welcome_bonus'] +
    $user['pending'] +
    $user['total_withdrawn'] +
    $user['deposit_balance'] +
    $user['survey_balance'] +
    $user['crash_balance'] +
    $withdraw_charges;

$user['referred_by'] = $user['referred_by'] ?? null;

$upline_name = null;
if ($user['referred_by']) {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE username = ?");
    $stmt->execute([$user['referred_by']]);
    $upline_name = $stmt->fetchColumn();
}

$stmt = $pdo->prepare("SELECT username, email FROM users WHERE referred_by = ?");
$stmt->execute([$user['username']]);
$level1 = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT u2.username, u2.email
    FROM users u1
    JOIN users u2 ON u2.referred_by = u1.username
    WHERE u1.username = ?
");
$stmt->execute([$user['username']]);
$level2 = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by = ?");
$stmt->execute([$user['username']]);
$total_referrals = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by = ? AND status = 'active'");
$stmt->execute([$user['username']]);
$activated_referrals = (int)$stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>FlexHela Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" type="text/css" href="css.css" />
<script>
function copyReferralLink() {
  const input = document.getElementById("referralLink");
  navigator.clipboard.writeText(input.value)
    .then(() => alert("Referral link copied!"))
    .catch(() => alert("Failed to copy link."));
  }
</script>
</head>
<body>
  <div class="container">

    <!-- Header -->
    <div class="header">
      <div class="logo">FLEXHELA</div>
      <div class="dropdown">
        <button class="dropdown-btn">Menu</button>
        <div class="dropdown-content">
          <a href="dashboard.php">Home</a>
          <a href="profile.php">Profile</a>
          <a href="crash.php">Whatsapp Community</a>
          <a href="deposit.php">Deposit</a>
          <a href="withdraw.php">Withdraw</a>
          <a href="withdraw-history.php">Withdraw History</a>
          <a href="claim.php">Welcome Bonus</a>
           <a href="survey.php">Solve Surveys</a>
            <a href="crash.php">Crash Game</a>
          <a href="payforclient.php">Pay for Client</a>
          <a href="level1.php">Level 1 Referrals</a>
          <a href="level2.php">Level 2 Referrals</a>
          <a href="logout.php">Log out</a>
        </div>
      </div>
    </div>

    <!-- Greeting -->
    <h2>Hello <?= htmlspecialchars($user['username']) ?> 👋</h2><br>

    <!-- Notice -->
    <div class="notice">
      Today is the Tomorrow you worried about Yesterday 😊.
      Stop worrying & Focus. Earn big by sharing & referring your friends to Flexhela. When we work together, great things happen! ❤
    </div>

    <!-- Wallet Summary -->
    <div class="card1">
      <div class="split">
        <div class="side">
          <p>Capital</p>
          <p style="font-weight: bold;"><?= $currency ?>. <?= number_format($user['capital'], 2) ?></p>
        </div>
        <hr />
        <div class="side" style="margin-right:50px;">
        <p>Total Earned</p>
        <p style="font-weight: bold;" id="totalEarned">
         <?= $currency ?>. <?= number_format($user['total_earned'], 2) ?>
         </p>
      </div>
      </div>
    </div><br />

    <div class="grid">
      <div class="card">
        <p>Wallet Balance</p>
        <p id="walletBalance"><?= $currency ?>. <?= number_format($user['wallet_balance'], 2) ?></p>
      </div>
      <div class="card">
        <p>Welcome Bonus</p>
        <p><?= $currency ?>. <?= number_format($user['welcome_bonus'], 2) ?></p>
      </div>
      <div class="card">
        <p>Pending</p>
        <p><?= $currency ?>. <?= number_format($user['pending'], 2) ?></p>
      </div>
      <div class="card">
        <p>Total Withdrawn</p>
        <p><?= $currency ?>. <?= number_format($user['total_withdrawn'], 2) ?></p>
      </div>
    </div>
   <div class="card
::contentReference[oaicite:0]{index=0}
     <div class="card1" style="background-color: rgb(71, 168, 71);">
      <p>Deposit Balance</p>
      <p><?= $currency ?>. <?= number_format($user['deposit_balance'], 2) ?></p>
    </div><br />
        <div class="card
::contentReference[oaicite:0]{index=0}
    <div class="card1" style="background-color: orange;">
      <p>Solve Surveys</p>
      <p><?= $currency ?>. <?= number_format($user['survey_balance'], 2) ?></p>
    </div><br />
    <div class="card
::contentReference[oaicite:0]{index=0}
     <div class="card1" style="background-color: rgb(71, 168, 71);">
      <p>Crash Balance</p>
      <p><?= $currency ?>. <?= number_format($user['crash_balance'], 2) ?></p>
      <a href="crash.php"><button class="btn">Play Crash</button></a>
    </div><br />

    <!-- Daily Bonus -->
    <div class="card" style="border-radius:6px; border: solid orange 1px;">
      <h2 style="text-align:center;">Daily Bonus</h2>
      <?php
        $daily_target = 10;
        $target_hit = (int)$activated_referrals;
        $how_much_to_go = max(0, $daily_target - $target_hit);

        // Check if already claimed today
        $today = date('Y-m-d');
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM daily_bonus_claims WHERE user_id = ? AND claim_date = ?");
        $stmt->execute([$user['id'], $today]);
        $already_claimed = (int)$stmt->fetchColumn();
      ?>
      <p>Today's Target: <?= $daily_target ?> points</p>
      <p>Target Reward: 10/10</p>
      <p>Target Hit: <?= $target_hit ?> points</p>
      <p>How Much to Go: <span id="howMuchToGo"><?= $how_much_to_go ?> points</span></p>
      <div style="text-align:center;">
  <button id="claimBtn" class="btn btn-center" style="background-color: rgb(71, 168, 71);">
  <?= $already_claimed ? 'Claimed' : 'Tap Here to Claim' ?>
</button>
</div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const dailyTarget = <?= $daily_target ?>;
    let targetHit = <?= $target_hit ?>;
    const alreadyClaimed = <?= $already_claimed ?>;

    function updateRemaining() {
      const remaining = Math.max(0, dailyTarget - targetHit);
      document.getElementById('howMuchToGo').textContent = remaining + " points";
    }

    updateRemaining();

    const claimBtn = document.getElementById('claimBtn');

    // Disable button if already claimed
    if (alreadyClaimed) {
      claimBtn.disabled = true;
      claimBtn.textContent = "Claimed";
    }

    claimBtn.addEventListener('click', function () {
      if (targetHit < dailyTarget) {
        alert("You have not hit the target yet. Keep going!");
        return;
      }

      if (alreadyClaimed || this.disabled) {
        alert("Bonus already claimed today.");
        return;
      }

      fetch('claim_bonus.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'same-origin',
        body: JSON.stringify({})
      })
        .then(response => response.json())
        .then(data => {
          if (!data.success) {
            alert(data.message);
            return;
          }

          alert(data.message);
          document.getElementById('walletBalance').textContent = '<?= $currency ?>. ' + data.wallet_balance;
          document.getElementById('totalEarned').textContent = '<?= $currency ?>. ' + data.total_earned;

          this.disabled = true;
          this.textContent = "Claimed";
        })
        .catch(() => alert("An error occurred. Please try again."));
    });
  });
</script>


    <!-- Referral Trend -->
    <br />
    <div class="section">
      <div class="section-title">Referrals Trend</div>
      <div class="card" style="background-color: rgb(71, 168, 71);">
        <p>Total Referrals: <?= (int)$total_referrals ?></p>
        <hr />
        <p>Activated: <?= (int)$activated_referrals ?></p>
        <a href="level1.php"><button class="btn">View Referrals</button></a>
      </div>
    </div>

    <!-- Referral Link -->
    <div class="referral-box">
      <p>Earn <strong style="color:#22c55e;"><?= $currency ?> <?= $level1_bonus ?></strong> for level 1 and <strong style="color:#22c55e;"><?= $currency ?> <?= $level2_bonus ?></strong> for level 2 referrals.</p>
      <div class="referral-input-group">
        <input type="text" id="referralLink" class="referral-input" readonly
          value="https://flexhela.com/user/signup.php?ref=<?= urlencode($user['username']) ?>" />
        <button class="copy-btn" onclick="copyReferralLink()">Copy</button>
      </div>
    </div>

    <!-- Profile Summary -->
    <div style="border: solid rgb(89, 89, 219) 1px; border-radius: 10px; padding: 25px; max-width: 500px; margin: 40px auto; box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);">
      <h3 style="text-align: center;">User Profile</h3>
      <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
      <p><strong>Upline:</strong> <?= $upline_name ? htmlspecialchars($upline_name) : 'No upline' ?></p>
      <p><strong>Joined:</strong> <?= htmlspecialchars($user['created_at']) ?></p><br>
      <a href="reset_password.php"><button class="btn" style="display: block; margin: 0 auto">Reset Password</button></a>
    </div>

    <br />
    <p style="font-size: smaller; text-align: center;">Crafted with ❤ All Rights Reserved.</p>
  </div>
</body>
</html>
