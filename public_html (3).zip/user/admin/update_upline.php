<?php
require 'config.php';

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) exit('User ID missing.');

// Fetch the active user
$stmt = $pdo->prepare("SELECT id, username, status, referred_by FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') exit('User not found or not active.');

// Check if bonus already exists
$stmt = $pdo->prepare("SELECT * FROM referral_bonus WHERE referred_id = ?");
$stmt->execute([$user['id']]);
$existingBonus = $stmt->fetch();

// CASE 1: Bonus exists, but user has no current upline —> REVERSE bonus
if ($existingBonus && !$user['referred_by']) {
    // Reverse commission
    $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ?, total_earned = total_earned - ? WHERE id = ?")
        ->execute([$existingBonus['amount'], $existingBonus['amount'], $existingBonus['upline_id']]);

    // Delete bonus log
    $pdo->prepare("DELETE FROM referral_bonus WHERE id = ?")->execute([$existingBonus['id']]);

    exit('Upline removed. Bonus reversed.');
}

// CASE 2: Bonus does NOT exist but user has a referred_by —> ADD commission
if (!$existingBonus && $user['referred_by']) {
    // Fetch upline
    $stmt = $pdo->prepare("SELECT id, username, email, referred_by FROM users WHERE username = ?");
    $stmt->execute([$user['referred_by']]);
    $upline = $stmt->fetch();

    if (!$upline) exit('Upline not found.');

    $level = $upline['referred_by'] ? 2 : 1;
    $amount = $level === 1 ? 1500 : 1000;

    // Credit bonus
    $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ? WHERE id = ?")
        ->execute([$amount, $amount, $upline['id']]);

    // Log bonus
    $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at)
                   VALUES (?, ?, ?, ?, NOW())")
        ->execute([$upline['id'], $user['id'], $level, $amount]);

    // Optional: send email
    $subject = "Referral Bonus Restored";
    $message = "Hello " . htmlspecialchars($upline['username']) . ",\n\n" .
               "Your referral " . htmlspecialchars($user['username']) . " has been linked to you again.\n" .
               "You have earned a bonus of FCFA $amount.\n\n" .
               "Regards,\nFlexHela Team";
    $headers = "From: no-reply@flexhela.com\r\nContent-Type: text/plain";
    mail($upline['email'], $subject, $message, $headers);

    exit('Bonus restored and upline updated.');
}

// CASE 3: Bonus and upline both exist —> no action needed
exit('No changes made to bonus.');
