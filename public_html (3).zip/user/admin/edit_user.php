<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: users.php');
    exit;
}

$msg = '';

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: users.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $referred_by = trim($_POST['referred_by']);

    if ($email === '' || $phone === '') {
        $msg = "Email and phone are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Invalid email format.";
    } else {
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET email = ?, phone = ?, password = ?, referred_by = ? WHERE id = ?");
            $stmt->execute([$email, $phone, $hashed_password, $referred_by, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET email = ?, phone = ?, referred_by = ? WHERE id = ?");
            $stmt->execute([$email, $phone, $referred_by, $id]);
        }

        $msg = "User updated successfully.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit User</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        form { max-width: 500px; }
        label { display: block; margin-top: 15px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px 15px; }
        .msg { margin-top: 10px; font-weight: bold; color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Edit User: <?= htmlspecialchars($user['username']) ?></h2>

    <?php if ($msg): ?>
        <div class="<?= strpos($msg, 'successfully') !== false ? 'msg' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>

        <label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>

        <label for="password">Password: <small>(leave blank to keep unchanged)</small></label>
        <input type="password" id="password" name="password">

        <label for="wallet_balance">Wallet Balance:</label>
        <input type="number" step="0.01" id="wallet_balance" name="wallet_balance" value="<?= htmlspecialchars($user['wallet_balance']) ?>">

        <label for="total_earned">Total Earned:</label>
        <input type="number" step="0.01" id="total_earned" name="total_earned" value="<?= htmlspecialchars($user['total_earned']) ?>">

        <label for="total_withdrawn">Total Withdrawn:</label>
        <input type="number" step="0.01" id="total_withdrawn" name="total_withdrawn" value="<?= htmlspecialchars($user['total_withdrawn']) ?>">

        <label for="deposit_balance">Deposit Balance:</label>
        <input type="number" step="0.01" id="deposit_balance" name="deposit_balance" value="<?= htmlspecialchars($user['deposit_balance']) ?>">

        <label for="referred_by">Upline (Referred By):</label>
        <input type="text" id="referred_by" name="referred_by" value="<?= htmlspecialchars($user['referred_by']) ?>">

        <button type="submit">Update User</button>
    </form>

    <p><a href="users.php">Back to users List</a></p>
</body>
</html>
