<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$actionMsg = '';

// Activation / Amount update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'], $_POST['user_id']) && in_array($_POST['action'], ['activate', 'deactivate'])) {
        $user_id = (int)$_POST['user_id'];
        $newStatus = $_POST['action'] === 'activate' ? 'active' : 'inactive';
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $user_id]);
        $actionMsg = "User ID $user_id set to $newStatus.";
    }

    if (isset($_POST['update_amount'])) {
        $log_id = $_POST['log_id'];
        $amount_paid = $_POST['amount_paid'];
        $stmt = $pdo->prepare("UPDATE payments SET amount_paid = ?, status = 'confirmed' WHERE id = ?");
        if ($stmt->execute([$amount_paid, $log_id])) {
            $stmt2 = $pdo->prepare("SELECT msisdn FROM payments WHERE id = ?");
            $stmt2->execute([$log_id]);
            $payment = $stmt2->fetch(PDO::FETCH_ASSOC);
            $msisdn = $payment['msisdn'];

            if ($msisdn) {
                $stmt3 = $pdo->prepare("SELECT SUM(amount_paid) AS total_paid FROM payments WHERE msisdn = ? AND status = 'confirmed'");
                $stmt3->execute([$msisdn]);
                $total = $stmt3->fetch(PDO::FETCH_ASSOC);

                $stmt4 = $pdo->prepare("SELECT id, phone FROM users WHERE phone = ? OR msisdn = ?");
                $stmt4->execute([$msisdn, $msisdn]);
                $user = $stmt4->fetch(PDO::FETCH_ASSOC);

                if ($user && $total['total_paid'] >= 3000) {
                    $stmt5 = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                    $stmt5->execute([$user['id']]);
                    $actionMsg = "Payment confirmed. User {$user['id']} activated.";
                } else {
                    $actionMsg = "Payment confirmed. Total paid: {$total['total_paid']} FCFA.";
                }
            } else {
                $actionMsg = "No MSISDN found for payment.";
            }
        } else {
            $actionMsg = "Failed to update payment.";
        }
    }
}

// Search support
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("
        SELECT p.*, u.username, u.phone AS user_phone, u.status AS user_status, u.id AS user_id
        FROM payments p
        LEFT JOIN users u ON p.user_id = u.id
        WHERE u.username LIKE :search OR u.phone LIKE :search OR p.msisdn LIKE :search
        ORDER BY p.created_at DESC
    ");
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt = $pdo->query("
        SELECT p.*, u.username, u.phone AS user_phone, u.status AS user_status, u.id AS user_id
        FROM payments p
        LEFT JOIN users u ON p.user_id = u.id
        ORDER BY p.created_at DESC
    ");
}
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Panel - Payments</title>
<style>
    body { font-family: Arial, sans-serif; background: #f9f9f9; padding: 20px; }
    table { width: 100%; border-collapse: collapse; background: #fff; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
    th { background: #333; color: #fff; }
    .btn { padding: 5px 10px; border: none; border-radius: 3px; cursor: pointer; }
    .activate { background: #27ae60; color: #fff; }
    .deactivate { background: #c0392b; color: #fff; }
    .status-active { color: green; font-weight: bold; }
    .status-inactive { color: red; font-weight: bold; }
    .msg { margin: 15px 0; background: #dff0d8; color: #3c763d; padding: 10px; border-radius: 5px; }
    input[type=number] { width: 80px; }
    input[type=text] { width: 300px; padding: 5px; }
</style>
</head>
<body>

<h1>Admin Panel - Payments</h1>

<?php if (!empty($actionMsg)): ?>
    <div class="msg"><?= htmlspecialchars($actionMsg) ?></div>
<?php endif; ?>

<form method="GET" style="margin-bottom: 20px;">
    <input type="text" name="search" placeholder="Search by username, phone or msisdn" value="<?= htmlspecialchars($search) ?>">
    <button type="submit" class="btn">Search</button>
</form>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>User Phone</th>
            <th>Payment MSISDN</th>
            <th>Amount Paid (FCFA)</th>
            <th>Method</th>
            <th>Payment Status</th>
            <th>Created At</th>
            <th>User Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($logs)): ?>
            <tr><td colspan="10">No payment records found.</td></tr>
        <?php else: ?>
            <?php foreach ($logs as $log): ?>
            <tr>
                <td><?= htmlspecialchars($log['id']) ?></td>
                <td><?= htmlspecialchars($log['username'] ?? '-') ?></td>
                <td><?= htmlspecialchars($log['user_phone'] ?? '-') ?></td>
                <td><?= htmlspecialchars($log['msisdn'] ?? '-') ?></td>
                <td>
                    <form method="POST" class="inline" onsubmit="return confirm('Update amount?');">
                        <input type="hidden" name="log_id" value="<?= $log['id'] ?>">
                        <input type="number" name="amount_paid" step="0.01" value="<?= htmlspecialchars($log['amount_paid']) ?>" required>
                        <button type="submit" name="update_amount" class="btn">Update</button>
                    </form>
                </td>
                <td><?= htmlspecialchars($log['method']) ?></td>
                <td><?= ucfirst(htmlspecialchars($log['status'])) ?></td>
                <td><?= htmlspecialchars($log['created_at']) ?></td>
                <td class="status-<?= $log['user_status'] === 'active' ? 'active' : 'inactive' ?>">
                    <?= ucfirst($log['user_status'] ?? '-') ?>
                </td>
                <td>
                    <?php if (!empty($log['user_id'])): ?>
                        <form method="POST" onsubmit="return confirm('Confirm action?');">
                            <input type="hidden" name="user_id" value="<?= $log['user_id'] ?>">
                            <input type="hidden" name="action" value="<?= $log['user_status'] === 'active' ? 'deactivate' : 'activate' ?>">
                            <button type="submit" class="btn <?= $log['user_status'] === 'active' ? 'deactivate' : 'activate' ?>">
                                <?= $log['user_status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                            </button>
                        </form>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
