<?php
session_start();
require '../config.php';

// Restrict access to logged-in admins
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$adminName = $_SESSION['admin_username'] ?? 'Admin';

// User count stats
$stmt = $pdo->query("SELECT 
    COUNT(*) AS total, 
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active, 
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) AS inactive 
    FROM users");
$counts = $stmt->fetch(PDO::FETCH_ASSOC);

// Ensure values are not null
$activeUsers = (int)($counts['active'] ?? 0);
$totalReceived = $activeUsers * 3000;

// Get total approved withdrawals
$withdrawStmt = $pdo->query("SELECT SUM(amount) AS total_withdrawn FROM withdrawals WHERE status = 'approved'");
$withdrawResult = $withdrawStmt->fetch(PDO::FETCH_ASSOC);
$totalWithdrawn = (float)($withdrawResult['total_withdrawn'] ?? 0);

// Net balance = total received - total withdrawn
$netBalance = $totalReceived - $totalWithdrawn;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard - FlexHela</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: #f7f7f7;
      margin: 0;
      padding: 0;
    }

    .dashboard {
      max-width: 500px;
      width: 90%;
      margin: 60px auto;
      padding: 25px 20px;
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    h1 {
      color: #333;
      font-size: 24px;
      margin-bottom: 20px;
    }

    .user-counts {
      background: #e9ecef;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    .user-counts h3 {
      margin: 8px 0;
      font-weight: normal;
      font-size: 16px;
      color: #333;
    }

    .user-counts span {
      font-weight: bold;
      color: #000;
    }

    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      background: #28a745;
      color: #fff;
      text-decoration: none;
      font-weight: bold;
      border-radius: 6px;
      font-size: 16px;
      transition: background 0.3s ease;
    }

    .btn:hover {
      background: #218838;
    }

    .logout {
      background: #dc3545;
    }

    .logout:hover {
      background: #c82333;
    }

    @media (max-width: 480px) {
      h1 {
        font-size: 20px;
      }

      .btn {
        padding: 14px;
        font-size: 15px;
      }

      .user-counts h3 {
        font-size: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="dashboard">
    <h1>Welcome, <?= htmlspecialchars($adminName) ?> 👋</h1>

    <div class="user-counts">
      <h3>Total Balance: <span>FCFA <?= number_format($netBalance) ?></span></h3>
      <h3>Total users: <span><?= $counts['total'] ?></span></h3>
      <h3>Active users: <span><?= $counts['active'] ?></span></h3>
      <h3>Inactive users: <span><?= $counts['inactive'] ?></span></h3>
    </div>

    <a href="users.php" class="btn">Manage Users</a>
    <a href="admin_deposits.php" class="btn">View Deposits</a>
    <a href="withdrawals.php" class="btn">View Withdrawals</a>
    <a href="admin_payments.php" class="btn">View Payments</a>
    <a href="logout.php" class="btn logout">Log Out</a>
  </div>
</body>
</html>
