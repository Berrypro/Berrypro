<?php
session_start();
require '../config.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $msg = "❌ Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f4f4f4;
      padding: 20px;
      margin: 0;
    }

    .login-box {
      max-width: 400px;
      width: 90%;
      margin: 60px auto;
      background: #ffffff;
      padding: 30px 25px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #333;
    }

    label {
      display: block;
      margin-top: 15px;
      margin-bottom: 5px;
      font-weight: 600;
      color: #444;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 12px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }

    button {
      margin-top: 20px;
      width: 100%;
      padding: 12px;
      background-color: #28a745;
      border: none;
      color: white;
      font-weight: bold;
      font-size: 16px;
      border-radius: 6px;
      cursor: pointer;
    }

    button:hover {
      background-color: #218838;
    }

    .msg {
      margin-top: 15px;
      color: red;
      text-align: center;
      font-weight: bold;
    }

    @media (max-width: 480px) {
      .login-box {
        padding: 20px 15px;
      }

      h2 {
        font-size: 22px;
      }

      input, button {
        font-size: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="login-box">
    <h2>Admin Login</h2>
    <?php if ($msg): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <form method="post">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" required autofocus />

      <label for="password">Password</label>
      <input type="password" name="password" id="password" required />

      <button type="submit">Log In</button>
    </form>
  </div>
</body>
</html>
