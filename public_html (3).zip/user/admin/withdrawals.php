
<?php
session_start();
require '../config.php';

// Admin authentication
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Handle approval/rejection
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];

    $stmt = $pdo->prepare("
        SELECT w.user_id, w.amount, w.fee, w.status, w.wallet_source, u.pending, u.wallet_balance, u.total_withdrawn
        FROM withdrawals w
        JOIN users u ON w.user_id = u.id
        WHERE w.id = ?
        FOR UPDATE
    ");
    $stmt->execute([$id]);
    $withdrawal = $stmt->fetch();

    if (!$withdrawal) {
        header("Location: withdrawals.php?error=notfound");
        exit;
    }

    if ($withdrawal['status'] !== 'pending') {
        header("Location: withdrawals.php");
        exit;
    }

    $pdo->beginTransaction();
    try {
        if ($action === 'approve') {
            $stmt = $pdo->prepare("UPDATE withdrawals SET status = 'approved' WHERE id = ?");
            $stmt->execute([$id]);

            $newPending = max(0, $withdrawal['pending'] - $withdrawal['amount']);
            $newTotalWithdrawn = $withdrawal['total_withdrawn'] + $withdrawal['amount'] + $withdrawal['fee'];

            $stmt = $pdo->prepare("UPDATE users SET pending = ?, total_withdrawn = ? WHERE id = ?");
            $stmt->execute([$newPending, $newTotalWithdrawn, $withdrawal['user_id']]);

        } elseif ($action === 'reject') {
            $stmt = $pdo->prepare("UPDATE withdrawals SET status = 'rejected' WHERE id = ?");
            $stmt->execute([$id]);

            $newPending = max(0, $withdrawal['pending'] - $withdrawal['amount']);
            $newWalletBalance = $withdrawal['wallet_balance'] + $withdrawal['amount'] + $withdrawal['fee'];

            $stmt = $pdo->prepare("UPDATE users SET pending = ?, wallet_balance = ? WHERE id = ?");
            $stmt->execute([$newPending, $newWalletBalance, $withdrawal['user_id']]);
        }

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: withdrawals.php?error=failed");
        exit;
    }

    header("Location: withdrawals.php");
    exit;
}

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// Search
$where = '';
$params = [];
if (!empty($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $where = 'WHERE u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ?';
    $params = [$search, $search, $search];
}

// Fetch withdrawals
$stmt = $pdo->prepare("
    SELECT w.id, u.username, u.email, u.phone, w.amount, w.fee, w.status, w.wallet_source, w.created_at
    FROM withdrawals w
    JOIN users u ON w.user_id = u.id
    $where
    ORDER BY w.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute(array_merge($params, [$limit, $offset]));
$withdrawals = $stmt->fetchAll();

// Total count
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM withdrawals w
    JOIN users u ON w.user_id = u.id
    $where
");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Withdrawals</title>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #eee;
        }
        .pagination a {
            margin: 0 5px;
            text-decoration: none;
            color: blue;
        }
        .pagination span {
            margin: 0 5px;
            font-weight: bold;
        }
        .actions a {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <h1>Withdrawal Requests</h1>

    <form method="get" style="margin-bottom: 20px;">
        <input type="text" name="search" placeholder="Search by username, email, or phone" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" style="padding: 6px; width: 250px;">
        <button type="submit" style="padding: 6px 12px;">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Amount (FCFA.)</th>
                <th>Fee (FCFA.)</th>
                <th>Wallet</th>
                <th>Status</th>
                <th>Requested At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($withdrawals)): ?>
                <tr><td colspan="10" style="text-align:center;">No withdrawal requests found.</td></tr>
            <?php else: ?>
                <?php foreach ($withdrawals as $i => $w): ?>
                    <tr>
                        <td><?= htmlspecialchars($offset + $i + 1) ?></td>
                        <td><?= htmlspecialchars($w['username']) ?></td>
                        <td><?= htmlspecialchars($w['email']) ?></td>
                        <td><?= htmlspecialchars($w['phone']) ?></td>
                        <td><?= number_format($w['amount'], 2) ?></td>
                        <td><?= number_format($w['fee'], 2) ?></td>
                        <td><?= ucwords(str_replace('_', ' ', $w['wallet_source'] ?? 'Unknown')) ?></td>
                        <td><?= ucfirst(htmlspecialchars($w['status'])) ?></td>
                        <td><?= htmlspecialchars($w['created_at']) ?></td>
                        <td class="actions">
                            <?php if ($w['status'] === 'pending'): ?>
                                <a href="?action=approve&id=<?= $w['id'] ?>" onclick="return confirm('Approve this withdrawal?')">Approve</a> |
                                <a href="?action=reject&id=<?= $w['id'] ?>" onclick="return confirm('Reject this withdrawal?')">Reject</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination" style="margin-top: 20px;">
        <?php if ($page > 1): ?>
            <a href="?page=1<?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">First</a>
            <a href="?page=<?= $page - 1 ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Previous</a>
        <?php endif; ?>
        <span>Page <?= $page ?> of <?= $totalPages ?></span>
        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Next</a>
            <a href="?page=<?= $totalPages ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Last</a>
        <?php endif; ?>
    </div>
</body>
</html>
