<?php
session_start();
require_once 'config.php';

// Check admin session or permissions here (important!)

if (!isset($_GET['user_id'])) {
    die("User ID missing");
}

$userId = (int)$_GET['user_id'];

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found.");
}

// Only activate if currently inactive
if ($user['status'] !== 'active') {
    // Activate user
    $stmt = $pdo->prepare("UPDATE Users SET status = 'active' WHERE id = ?");
    $stmt->execute([$userId]);

    // Add referral bonuses if has upline
    if (!empty($user['referred_by'])) {
        $level1_bonus = 1500;
        $level2_bonus = 1000;

        // Level 1 upline
        $stmt = $pdo->prepare("UPDATE Users SET 
            wallet_balance = wallet_balance + ?,
            total_earned = total_earned + ?,
            activated_referrals = activated_referrals + 1
            WHERE username = ?");
        $stmt->execute([$level1_bonus, $level1_bonus, $user['referred_by']]);

        // Level 2 upline (upline of upline)
        $stmt = $pdo->prepare("SELECT referred_by FROM Users WHERE username = ?");
        $stmt->execute([$user['referred_by']]);
        $level2 = $stmt->fetchColumn();

        if ($level2) {
            $stmt = $pdo->prepare("UPDATE Users SET 
                wallet_balance = wallet_balance + ?,
                total_earned = total_earned + ?
                WHERE username = ?");
            $stmt->execute([$level2_bonus, $level2_bonus, $level2]);
        }
    }

    echo "User activated and referral bonuses credited.";
} else {
    echo "User already active.";
}
?>
