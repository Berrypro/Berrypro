<?php
require_once '../config.php';

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle amount update and status sync
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_amount'])) {
    $username = $_POST['username'] ?? '';
    $amount = intval($_POST['amount_paid']);

    // Update amount_paid in users
    $stmt = $pdo->prepare("UPDATE users SET amount_paid = ? WHERE username = ?");
    $stmt->execute([$amount, $username]);

    // Sync status from submissions to users
    $stmt = $pdo->prepare("SELECT status FROM submissions WHERE username = ?");
    $stmt->execute([$username]);
    $submissionStatus = $stmt->fetchColumn();

    if ($submissionStatus !== false) {
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE username = ?");
        $stmt->execute([$submissionStatus, $username]);
    }

    header("Location: admin_submissions.php");
    exit;
}

// Handle status toggle
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Get current status and username
    $stmt = $pdo->prepare("SELECT username, status FROM submissions WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    if ($row) {
        $newStatus = ($row['status'] === 'active') ? 'inactive' : 'active';

        // Update submissions table
        $stmt = $pdo->prepare("UPDATE submissions SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $id]);

        // Update users table
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE username = ?");
        $stmt->execute([$newStatus, $row['username']]);
    }

    header("Location: admin_submissions.php");
    exit;
}

// Fetch all submissions with amount from users
$stmt = $pdo->query("SELECT s.*, u.amount_paid AS user_amount 
                     FROM submissions s 
                     LEFT JOIN users u ON s.username = u.username 
                     ORDER BY s.submitted_at DESC");
$submissions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Manage Submissions</title>
  <style>
    body {
      font-family: Arial;
      background: #f4f4f4;
    }
    h2 {
      text-align: center;
      margin-top: 20px;
    }
    table {
      width: 95%;
      margin: 20px auto;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: center;
    }
    th {
      background-color: #2c3e50;
      color: white;
    }
    form {
      display: inline-block;
    }
    input[type="number"] {
      width: 80px;
      padding: 4px;
    }
    button {
      padding: 6px 12px;
      background: #2980b9;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:hover {
      background: #3498db;
    }
    .active {
      color: green;
      font-weight: bold;
    }
    .inactive {
      color: red;
      font-weight: bold;
    }
    a.toggle-button {
      padding: 6px 12px;
      text-decoration: none;
      background: #16a085;
      color: white;
      border-radius: 4px;
    }
    a.toggle-button:hover {
      background: #1abc9c;
    }
  </style>
</head>
<body>
  <h2>Transaction Code Submissions</h2>
  <table>
    <tr>
      <th>#</th>
      <th>Username</th>
      <th>Transaction Code</th>
      <th>Amount Paid (from users)</th>
      <th>Status</th>
      <th>Submitted At</th>
      <th>Actions</th>
    </tr>
    <?php foreach ($submissions as $i => $row): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= htmlspecialchars($row['transaction_code']) ?></td>
        <td>
          <form method="POST">
            <input type="hidden" name="username" value="<?= htmlspecialchars($row['username']) ?>">
            <input type="number" name="amount_paid" value="<?= htmlspecialchars($row['user_amount'] ?? 0) ?>" min="0">
            <button type="submit" name="update_amount">Update</button>
          </form>
        </td>
        <td class="<?= htmlspecialchars($row['status'] ?? 'inactive') ?>">
          <?= htmlspecialchars(ucfirst($row['status'] ?? 'inactive')) ?>
        </td>
        <td><?= htmlspecialchars($row['submitted_at']) ?></td>
        <td>
          <a class="toggle-button" href="?toggle=1&id=<?= $row['id'] ?>">
            <?= ($row['status'] ?? '') === 'active' ? 'Deactivate' : 'Activate' ?>
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</body>
</html>
