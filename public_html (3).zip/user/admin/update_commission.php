<?php
if (!isset($user_id)) exit('User ID missing for commission update.');

// Fetch user details again to get new referred_by
$stmt = $pdo->prepare("SELECT id, username, status, referred_by FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if (!$user || $user['status'] !== 'active') return;

// Check if bonus already credited
$stmt = $pdo->prepare("SELECT * FROM referral_bonus WHERE referred_id = ?");
$stmt->execute([$user['id']]);
$existing_bonus = $stmt->fetch();

if ($existing_bonus) {
    // Reverse old bonus
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$existing_bonus['upline_id']]);
    $old_upline = $stmt->fetch();

    if ($old_upline) {
        $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ?, total_earned = total_earned - ?, referrals = referrals - 1 WHERE id = ?")
            ->execute([$existing_bonus['amount'], $existing_bonus['amount'], $old_upline['id']]);
    }

    $pdo->prepare("DELETE FROM referral_bonus WHERE referred_id = ?")->execute([$user['id']]);
}

// Credit new upline
$stmt = $pdo->prepare("SELECT id, username, email, referred_by FROM users WHERE username = ?");
$stmt->execute([$user['referred_by']]);
$upline = $stmt->fetch();
if (!$upline) return;

$level = $upline['referred_by'] ? 2 : 1;
$amount = $level === 1 ? 1500 : 1000;

$pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ?, referrals = referrals + 1 WHERE id = ?")
    ->execute([$amount, $amount, $upline['id']]);

$pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at) VALUES (?, ?, ?, ?, NOW())")
    ->execute([$upline['id'], $user['id'], $level, $amount]);

// Optional: Email notification
$subject = "Referral Activated!";
$message = "Hi {$upline['username']}, your referral {$user['username']} was updated and you’ve earned KES $amount.";
$headers = "From: no-reply@flexhela.com\r\nContent-Type: text/plain";
mail($upline['email'], $subject, $message, $headers);

function handleUserStatusChange($userId, $newStatus, $pdo) {
    // Update the user's status
    $updateUser = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
    $updateUser->execute([$newStatus, $userId]);

    // Only process commission reversals if deactivating or deleting
    if ($newStatus === 'inactive' || $newStatus === 'deleted') {
        // Get all referral bonuses where this user triggered a payout
        $stmt = $pdo->prepare("SELECT * FROM referral_bonus WHERE referred_id = ?");
        $stmt->execute([$userId]);
        $bonuses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($bonuses as $bonus) {
            $bonusId = $bonus['id'];
            $uplineId = $bonus['upline_id'];
            $amount = (float) $bonus['amount'];

            // Deduct the bonus from upline's wallet
            $deduct = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
            $deduct->execute([$amount, $uplineId]);

            // Update bonus entry to zero or mark as revoked
            $revoke = $pdo->prepare("UPDATE referral_bonus SET amount = 0 WHERE id = ?");
            $revoke->execute([$bonusId]);
        }
    }
}
