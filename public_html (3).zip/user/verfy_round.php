<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

// Admin access control
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);
$serverSeed = $input['server_seed'] ?? '';

try {
    // Validate server seed format
    if (empty($serverSeed) || !ctype_xdigit($serverSeed) || strlen($serverSeed) !== 64) {
        throw new InvalidArgumentException("Invalid server seed format - must be 64-character hex string");
    }

    // Fetch round data
    $stmt = $pdo->prepare("
        SELECT id, client_seed, nonce, crash_point, created_at
        FROM crash_rounds 
        WHERE server_seed = ?
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->execute([$serverSeed]);
    
    if ($stmt->rowCount() === 0) {
        throw new RuntimeException("No round found with this server seed");
    }
    
    $round = $stmt->fetch(PDO::FETCH_ASSOC);

    // Recalculate crash point
    $message = $round['client_seed'].'-'.$round['nonce'];
    $hash = hash_hmac('sha256', $message, $serverSeed);
    $hex = substr($hash, 0, 8);
    $int = hexdec($hex);
    $calculatedPoint = max(1.10, min(10.00, (($int % 9000) / 1000) + 1));

    // Verify against stored value
    $difference = abs($calculatedPoint - $round['crash_point']);
    $tolerance = 0.0001;
    
    if ($difference > $tolerance) {
        error_log("Verification failed for round {$round['id']}: Calculated $calculatedPoint vs Stored {$round['crash_point']}");
        throw new RuntimeException("Verification failed - calculated result differs by $difference");
    }

    // Successful verification
    echo json_encode([
        'success' => true,
        'verification' => [
            'calculated' => $calculatedPoint,
            'stored' => $round['crash_point'],
            'difference' => $difference,
            'inputs' => [
                'server_seed' => substr($serverSeed, 0, 8).'...'.substr($serverSeed, -8),
                'client_seed' => $round['client_seed'],
                'nonce' => $round['nonce'],
                'hash_input' => $message,
                'hash_result' => $hash
            ],
            'round_info' => [
                'id' => $round['id'],
                'created_at' => $round['created_at']
            ]
        ]
    ]);

} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'input_error', 'message' => $e->getMessage()]);
} catch (RuntimeException $e) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'not_found', 'message' => $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    error_log("Verification error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'server_error', 'message' => 'Internal server error']);
}
?>