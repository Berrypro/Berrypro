<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header("Location: signin.php");
    exit;
}

$username = $user['username'];
$notice = '';
$msg = '';

function getTotalPaid($pdo, $username) {
    try {
        $stmt1 = $pdo->prepare("SELECT COALESCE(SUM(upline_paid), 0) FROM activation_payments WHERE username = ?");
        $stmt1->execute([$username]);
        $paidByUpline = (float)$stmt1->fetchColumn();

        $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(amount_paid), 0) FROM payments WHERE username = ? AND status = 'confirmed'");
        $stmt2->execute([$username]);
        $paidByUser = (float)$stmt2->fetchColumn();

        return [$paidByUpline, $paidByUser, $paidByUpline + $paidByUser];
    } catch (PDOException $e) {
        error_log("Payment calculation error: " . $e->getMessage());
        return [0, 0, 0];
    }
}

// Handle manual phone number submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_number'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $notice = "Invalid form submission. Please try again.";
    } else {
        $paymentNumber = preg_replace('/\D+/', '', trim($_POST['payment_number']));
        if (empty($paymentNumber) || strlen($paymentNumber) < 8) {
            $notice = "Please enter a valid number used to deposit.";
        } else {
        $stmt = $pdo->prepare("INSERT INTO payments (user_id, username, msisdn, status, method, created_at)
                       VALUES (?, ?, ?, 'pending', 'SoleasPay Manual', NOW())");
$stmt->execute([$user['id'], $user['username'], $paymentNumber]);
            $msg = "✅ Number submitted successfully. We'll verify and activate your account shortly.";
        }
    }
}

list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $username);

// Auto-activate if totalPaid is 3000 or more and user is not yet active
if ($totalPaid >= 3000 && $user['status'] !== 'active') {
    $activateStmt = $pdo->prepare("UPDATE users SET status = 'active', activated_at = NOW() WHERE id = ?");
    $activateStmt->execute([$user_id]);

    $_SESSION['just_activated'] = true;
   $_SESSION['activation_success'] = "✅ Your account has been activated successfully!";
header("Location: payment.php"); // or current filename if not pay.php
exit;

}

$remaining = max(0, 3000 - $totalPaid);
$isActive = $user['status'] === 'active';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pay with SoleasPay</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Roboto', sans-serif;
      background-color: #1e1e2f;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      line-height: 1.6;
    }
    .container {
      background-color: #292942;
      border-radius: 10px;
      padding: 30px;
      width: 100%;
      max-width: 450px;
      margin: 20px;
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4);
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    h2 {
      text-align: center;
      font-size: 24px;
      font-weight: 600;
      margin-bottom: 10px;
    }
    p {
      text-align: center;
      margin-bottom: 10px;
      color: #1abc9c;
      font-weight: 500;
    }
    .notice, .msg {
      padding: 12px;
      border-radius: 6px;
      font-size: 14px;
      text-align: center;
      margin-bottom: 15px;
    }
    .notice {
      background-color: #34495e;
      color: #ecf0f1;
    }
    .msg {
      background-color: #27ae60;
      color: white;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    label {
      font-size: 14px;
      font-weight: 500;
    }
    input[type="text"] {
      padding: 12px;
      border: 1px solid #34495e;
      border-radius: 5px;
      background: #2c3e50;
      color: #fff;
      font-size: 14px;
    }
    input:focus {
      border-color: #2980b9;
      outline: none;
      box-shadow: 0 0 0 2px rgba(41, 128, 185, 0.3);
    }
    button, .pay-link {
      padding: 14px;
      background-color: #2980b9;
      border: none;
      border-radius: 6px;
      color: white;
      font-size: 16px;
      font-weight: 600;
      text-align: center;
      text-decoration: none;
      cursor: pointer;
      transition: background 0.3s ease;
      margin-top: 10px;
    }
    button:hover, .pay-link:hover {
      background-color: #3498db;
    }
    .whatsapp-link {
      text-align: center;
      margin-top: 15px;
    }
    .whatsapp-link a {
      color: #1abc9c;
      text-decoration: none;
      font-weight: 500;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Hello, <?= htmlspecialchars($username) ?> 👋</h2>
    <p>Total Paid: <strong><?= number_format($totalPaid, 2) ?> FCFA</strong></p>

    <?php if ($notice): ?>
      <div class="notice"><?= htmlspecialchars($notice) ?></div>
    <?php endif; ?>

    <?php if ($msg): ?>
      <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <?php if ($isActive): ?>
      <div class="msg">✅ Your account is active! <a href="dashboard.php">Go to Dashboard</a></div>
    <?php elseif ($remaining > 0): ?>
      <div class="notice">You need to pay <strong><?= number_format($remaining, 2) ?> FCFA</strong> more to activate your account.</div>

      <!-- PAY BUTTON -->
      <a class="pay-link" href="" target="_blank">💰 PAY HERE</a>

      <!-- NUMBER USED TO PAY FORM -->
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <label for="payment_number">Enter Number Used to Deposit:</label>
        <input type="text" name="payment_number" id="payment_number" required placeholder="e.g. 71817332" />
        <button type="submit">Submit Number</button>
      </form>
    <?php else: ?>
      <div class="msg">✅ Payment complete! <a href="dashboard.php">Activate Account</a></div>
    <?php endif; ?>

    <div class="whatsapp-link">
      <p>Trouble? <a href="https://wa.me/+254111507271?text=I%20need%20payment%20help" target="_blank">WhatsApp Us</a></p>
    </div>
  </div>
</body>
</html>
