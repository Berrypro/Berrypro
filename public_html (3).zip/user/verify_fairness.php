<?php
require 'config.php';

$roundId = $_GET['id'] ?? null;
if (!$roundId) {
  die("Missing round ID.");
}

$stmt = $pdo->prepare("SELECT * FROM crash_rounds WHERE id = ?");
$stmt->execute([$roundId]);
$round = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$round) {
  die("Round not found.");
}

function generateCrashPoint($serverSeed, $clientSeed, $nonce) {
    $input = $serverSeed . ':' . $clientSeed . ':' . $nonce;
    $hash = hash('sha256', $input);

    if (substr($hash, 0, 8) === "00000000") {
        return 1000.00;
    }

    $h = substr($hash, 0, 13);
    $num = hexdec($h);
    $e = pow(2, 52);
    $result = floor(($e * 100) / ($e - $num)) / 100;

    return max(1.01, round($result, 2));
}

$expectedCrash = generateCrashPoint($round['server_seed'], $round['client_seed'], $round['nonce']);
?>

<h2>🔍 Crash Round #<?php echo $round['id']; ?> Verification</h2>
<ul>
  <li><strong>Server Seed:</strong> <?php echo $round['server_seed']; ?></li>
  <li><strong>Client Seed:</strong> <?php echo $round['client_seed']; ?></li>
  <li><strong>Nonce:</strong> <?php echo $round['nonce']; ?></li>
  <li><strong>Database Crash:</strong> <?php echo $round['crash_point']; ?>x</li>
  <li><strong>Recomputed Crash:</strong> <?php echo $expectedCrash; ?>x</li>
</ul>
<?php if ($expectedCrash == $round['crash_point']) {
  echo "<p style='color:green'>✅ Fair round confirmed!</p>";
} else {
  echo "<p style='color:red'>❌ Crash mismatch! Something is wrong.</p>";
} ?>
