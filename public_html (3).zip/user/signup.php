<?php
session_start();
require_once 'config.php';

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function sendEmail($to, $subject, $message) {
    $headers = "From: noreply@flexhela.com\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    return mail($to, $subject, $message, $headers);
}

function cleanInput($data) {
    return htmlspecialchars(trim((string) $data), ENT_QUOTES, 'UTF-8');
}

$error = '';
$success = false;
$referred_by = $_SERVER["REQUEST_METHOD"] === "POST"
    ? cleanInput($_POST['referred_by'] ?? '')
    : cleanInput($_GET['ref'] ?? '');


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid form submission.";
    } else {
        $username = cleanInput($_POST['username'] ?? '');
        $email = cleanInput($_POST['email'] ?? '');
        $country = cleanInput($_POST['country'] ?? '');
        $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');
        $password_raw = $_POST['password'] ?? '';

        $capital = 3000;
        $welcome_bonus = 300;

        if (!$username || !$email || !$country || !$phone || !$password_raw) {
            $error = "All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } elseif (!preg_match('/^[a-zA-Z0-9]{3,10}$/', $username)) {
            $error = "Username must be 3-10 characters long and contain only letters and numbers.";
        } elseif (strlen($password_raw) < 4) {
            $error = "Password must be at least 4 characters long.";
        } else {
            $password = password_hash($password_raw, PASSWORD_DEFAULT);
            if ($username === $referred_by) {
                $referred_by = null;
            }

            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
            $stmt->execute(['username' => $username, 'email' => $email]);

            if ($stmt->rowCount() > 0) {
                $error = "Username or email already taken.";
            } else {
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare("INSERT INTO users 
                        (username, email, phone, password, capital, welcome_bonus, total_earned, wallet_balance, referred_by, status, created_at, country) 
                        VALUES (:username, :email, :phone, :password, :capital, :welcome_bonus, :total_earned, 0, :referred_by, 'inactive', NOW(), :country)");

                    $success = $stmt->execute([
                        'username' => $username,
                        'email' => $email,
                        'phone' => $phone,
                        'password' => $password,
                        'capital' => $capital,
                        'welcome_bonus' => $welcome_bonus,
                        'total_earned' => $welcome_bonus,
                        'referred_by' => $referred_by,
                        'country' => $country
                    ]);

                    if ($success) {
                        $subject = "Welcome to Flexhela, $username!";
                        $message = "
                            <h2>Hi $username,</h2>
                            <p>Thank you for registering at Flexhela.</p>
                            <p>Your account has been created successfully. Start referring friends and earning commissions!</p>
                            <br>
                            <p>Best regards,<br>Flexhela Team</p>
                        ";
                        sendEmail($email, $subject, $message);
                        $pdo->commit();
                        $_SESSION['registration_success'] = true;
                        header("Location: signin.php");
                        exit;
                    }
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    error_log("DB error: " . $e->getMessage());
                    $error = "Failed to create account. Try again.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Join Flexhela | Sign Up</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
  <div class="form-container">
    <h1>FLEXHELA</h1>
    <p class="title">Create your new account</p>

    <?php if (!empty($referred_by)): ?>
      <p class="ref-info" style="text-align:center; font-weight:bold; color:#00e676;">
        You were invited by: <?= htmlspecialchars($referred_by) ?>
      </p>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
      <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="signup.php" method="POST" novalidate>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
      <input type="hidden" name="referred_by" value="<?= htmlspecialchars($referred_by ?? '') ?>">

      <label for="username">Username</label>
      <input type="text" id="username" name="username" required 
             value="<?= htmlspecialchars($username ?? '') ?>"
             pattern="[a-zA-Z0-9]{3,10}" title="3-10 letters or numbers only">

      <label for="email">Email</label>
      <input type="email" id="email" name="email" required 
             value="<?= htmlspecialchars($email ?? '') ?>">

      <label for="country">Country</label>
      <select id="country" name="country" required onchange="updatePhonePrefix()">
        <option value="">Select Country</option>
        <option value="Cameroon" <?= ($country ?? '') === 'Cameroon' ? 'selected' : '' ?>>Cameroon</option>
        <option value="Benin" <?= ($country ?? '') === 'Benin' ? 'selected' : '' ?>>Benin</option>
        <option value="Togo" <?= ($country ?? '') === 'Togo' ? 'selected' : '' ?>>Togo</option>
        <option value="Burkina Faso" <?= ($country ?? '') === 'Burkina Faso' ? 'selected' : '' ?>>Burkina Faso</option>
        <option value="Cote d'Ivoire" <?= ($country ?? '') === "Cote d'Ivoire" ? 'selected' : '' ?>>Côte d'Ivoire</option>
        <option value="Congo" <?= ($country ?? '') === 'Congo' ? 'selected' : '' ?>>Congo</option>
        <option value="Niger" <?= ($country ?? '') === 'Niger' ? 'selected' : '' ?>>Niger</option>
      </select>

      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" required value="<?= htmlspecialchars($phone ?? '') ?>">
      <p class="info-text">We will pay you through this number.</p>

      <label for="password">Password (min 4 characters)</label>
      <div class="password-container">
        <input type="password" id="password" name="password" required minlength="4">
        <span onclick="togglePassword()">Show</span>
      </div>

      <button class="btn" type="submit">Sign up</button>
    </form>

    <div class="login-link">
      Already registered? <a href="signin.php">Log in</a>
    </div>
    <div class="login-link">
      Kenyan? <a href="../signup.php">Sign up Here</a>
    </div>
  </div>

<script>
function togglePassword() {
  const passwordField = document.getElementById("password");
  const toggle = passwordField.nextElementSibling;
  if (passwordField.type === "password") {
    passwordField.type = "text";
    toggle.textContent = "Hide";
  } else {
    passwordField.type = "password";
    toggle.textContent = "Show";
  }
}

function updatePhonePrefix() {
  const country = document.getElementById("country").value;
  const phone = document.getElementById("phone");

  const prefixes = {
    "Cameroon": "+237",
    "Benin": "+229",
    "Togo": "+228",
    "Burkina Faso": "+226",
    "Cote d'Ivoire": "+225",
    "Congo": "+242",
    "Niger": "+227"
  };

  const selectedPrefix = prefixes[country];
  if (selectedPrefix && !phone.value.startsWith(selectedPrefix)) {
    phone.value = selectedPrefix;
  }
}
</script>

</body>
</html>
