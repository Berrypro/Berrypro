<?php
session_start();
require 'config.php';

$inactiveLimit = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $inactiveLimit)) {
    session_unset();
    session_destroy();
    header("Location: signin.php?timeout=1");
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

$msg = "";

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: signin.php');
    exit;
}

$wallet = $user['wallet_balance'] ?? 0;
$deposit = $user['deposit_balance'] ?? 0;
$survey = $user['survey_balance'] ?? 0;
$crash = $user['crash_balance'] ?? 0;
$pending = $user['pending'] ?? 0;
$totalWithdrawn = $user['total_withdrawn'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (float) $_POST['amount'];
    $walletType = $_POST['wallet_type'] ?? '';

    $fee = 300;
    $totalRequired = $amount + $fee;

    $validWallets = ['wallet_balance', 'deposit_balance', 'survey_balance', 'crash_balance'];

    if (!in_array($walletType, $validWallets)) {
        $msg = "Please select a valid wallet.";
    } else {
        $available = $user[$walletType];
        $minWithdrawal = ($walletType === 'survey_balance' || $walletType === 'crash_balance') ? 14000 : 4000;

        if ($amount < $minWithdrawal) {
            $msg = "Minimum withdrawal from this wallet is FCFA. $minWithdrawal.";
        } elseif ($totalRequired > $available) {
            $msg = "Insufficient funds in your " . ucwords(str_replace('_', ' ', $walletType)) . ". You need at least FCFA. $totalRequired.";
        } else {
            $newBalance = $available - $totalRequired;

            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("INSERT INTO withdrawals (user_id, amount, fee, status, created_at, wallet_source) VALUES (?, ?, ?, 'pending', NOW(), ?)");
                $stmt->execute([$user['id'], $amount, $fee, $walletType]);

                $stmt = $pdo->prepare("UPDATE users SET $walletType = ?, pending = pending + ? WHERE id = ?");
                $stmt->execute([$newBalance, $amount, $user['id']]);

                $pdo->commit();

                mail(
                    $user['email'],
                    "Withdrawal Request Submitted",
                    "Dear {$user['username']},\n\nYour withdrawal request of FCFA. {$amount} from " . ucwords(str_replace('_', ' ', $walletType)) . " has been submitted.\nFee of FCFA. $fee deducted.\nNew balance: FCFA. " . number_format($newBalance, 2) . ".",
                    "From: no-reply@flexhela.com\r\nReply-To: support@flexhela.com\r\n"
                );

                $msg = "Withdrawal request submitted successfully.";
                
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user = $stmt->fetch();

                $wallet = $user['wallet_balance'];
                $deposit = $user['deposit_balance'];
                $survey = $user['survey_balance'];
                $crash = $user['crash_balance'];
                $pending = $user['pending'];
                $totalWithdrawn = $user['total_withdrawn'];

            } catch (Exception $e) {
                $pdo->rollBack();
                $msg = "An error occurred. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Withdraw Funds</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: black;
            margin: 0;
            color: #eee;
        }
        .container {
            max-width: 480px;
            margin: 20px auto;
            background-color: #292942;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.5);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: green;
            font-weight: bold;
        }
        label {
            font-weight: bold;
            margin-top: 12px;
            display: block;
            color: #cbd5e1;
        }
        select, input[type="number"], button {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 15px;
            border: 1px solid #444767;
            border-radius: 6px;
            font-size: 16px;
            background-color: #1e1e2f;
            color: #eee;
        }
        select:focus, input[type="number"]:focus {
            outline: none;
            border-color: #82aaff;
            box-shadow: 0 0 5px #82aaff;
        }
        button {
            background-color: #82aaff;
            color: #1e1e2f;
            font-weight: 700;
            cursor: pointer;
            border: none;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #4c6ef5;
            color: #fff;
        }
        .msg {
            padding: 12px;
            border-radius: 6px;
            margin-top: 15px;
            text-align: center;
            font-weight: 600;
        }
        .success {
            background-color: #164e63;
            color: #a7f3d0;
        }
        .error {
            background-color: #881337;
            color: #fca5a5;
        }
        .wallets p {
            margin: 5px 0;
            font-size: 14px;
            color: green;
        }
        @media (max-width: 480px) {
            h2 { font-size: 22px; }
            label, .wallets p { font-size: 14px; }
            button { font-size: 16px; }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Withdraw Funds</h2>

    <div class="wallets">
        <h5><strong>Wallet Balance:</strong> FCFA. <?= number_format($wallet, 2) ?></h5>
        <h5><strong>Deposit Balance:</strong> FCFA. <?= number_format($deposit, 2) ?></h5>
        <h5><strong>Survey Balance:</strong> FCFA. <?= number_format($survey, 2) ?></h5>
        <h5><strong>Crash Balance:</strong> FCFA. <?= number_format($crash, 2) ?></h5>
        <h5><strong>Pending Withdrawals:</strong> FCFA. <?= number_format($pending, 2) ?></h5>
        <h5><strong>Total Withdrawn:</strong> FCFA. <?= number_format($totalWithdrawn, 2) ?></h5>
    </div>

    <form method="post" novalidate>
        <label for="wallet_type">Select Wallet</label>
        <select name="wallet_type" id="wallet_type" required>
            <option value="">-- Select Wallet --</option>
            <option value="wallet_balance">Wallet Balance</option>
            <option value="deposit_balance">Deposit Balance</option>
            <option value="survey_balance">Survey Balance (Min: 14000)</option>
            <option value="crash_balance">Crash Balance (Min: 14000)</option>
        </select>

        <label for="amount">Amount to Withdraw</label>
        <input type="number" name="amount" id="amount" min="0.01" step="0.01" placeholder="Enter amount..." required />

        <p><strong>Withdrawal Fee:</strong> FCFA. 300</p>

        <button type="submit">Submit Withdrawal</button>
    </form>

    <?php if ($msg): ?>
        <div class="msg <?= strpos(strtolower($msg), 'success') !== false ? 'success' : 'error' ?>">
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
