<?php
// soleaspay_webhook.php

require_once 'config.php'; // Your DB connection

// Set response content type
header('Content-Type: application/json');

// Read and decode the incoming JSON
$rawPayload = file_get_contents("php://input");
$data = json_decode($rawPayload, true);

// Log raw data (optional, for debugging)
// file_put_contents('webhook_log.txt', $rawPayload . PHP_EOL, FILE_APPEND);

// Basic validation
if (!isset($data['reference']) || !isset($data['status']) || !isset($data['amount'])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid webhook payload"]);
    exit;
}

// Extract required values
$reference = $data['reference'];
$status = strtolower($data['status']); // 'success' or 'failed'
$amount = (int)$data['amount'];
$phone = $data['phone'] ?? '';
$transaction_id = $data['transaction_id'] ?? '';
$currency = $data['currency'] ?? '';

// Handle only successful payments
if ($status === 'success') {
    try {
        // Check if payment already exists (to prevent duplicates)
        $stmt = $pdo->prepare("SELECT id FROM payments WHERE reference = ?");
        $stmt->execute([$reference]);
        if ($stmt->rowCount() > 0) {
            http_response_code(200);
            echo json_encode(["message" => "Payment already recorded."]);
            exit;
        }

        // Try to find user by phone number (you may use other logic like reference-user mapping)
        $stmt = $pdo->prepare("SELECT * FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        $user = $stmt->fetch();

        if (!$user) {
            http_response_code(404);
            echo json_encode(["error" => "User not found"]);
            exit;
        }

        $user_id = $user['id'];
        $username = $user['username'];

        // Insert payment record
        $insert = $pdo->prepare("INSERT INTO payments (user_id, username, msisdn, amount_paid, phone, method, reference, transaction_code, status, created_at) 
                                 VALUES (?, ?, ?, ?, ?, 'SoleasPay', ?, ?, 'confirmed', NOW())");
        $insert->execute([$user_id, $username, $phone, $amount, $phone, $reference, $transaction_id]);

        // Recalculate total paid
        $stmt1 = $pdo->prepare("SELECT COALESCE(SUM(upline_paid), 0) FROM activation_payments WHERE username = ?");
        $stmt1->execute([$username]);
        $paidByUpline = (float)$stmt1->fetchColumn();

        $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(amount_paid), 0) FROM payments WHERE username = ? AND status = 'confirmed'");
        $stmt2->execute([$username]);
        $paidByUser = (float)$stmt2->fetchColumn();

        $totalPaid = $paidByUpline + $paidByUser;

        $update = $pdo->prepare("UPDATE users SET amount_paid = ?, upline_paid = ?, totalpaid = ? WHERE id = ?");
        $update->execute([$paidByUser, $paidByUpline, $totalPaid, $user_id]);

        // Activate account if threshold is met
        if ($totalPaid >= 3000 && $user['status'] !== 'active') {
            $pdo->prepare("UPDATE users SET status = 'active', activated_at = NOW() WHERE id = ?")
                ->execute([$user_id]);

            // Referral bonuses (same logic as before)
            $stmtUpline = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
            $stmtUpline->execute([$user_id]);
            $refData = $stmtUpline->fetch();

            if ($refData && !empty($refData['referred_by'])) {
                $referrerUsername = $refData['referred_by'];

                // Level 1
                $stmtLevel1 = $pdo->prepare("SELECT id, referred_by FROM users WHERE username = ? AND status = 'active'");
                $stmtLevel1->execute([$referrerUsername]);
                $level1 = $stmtLevel1->fetch();

                if ($level1) {
                    $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + 1300, total_earned = total_earned + 1300 WHERE id = ?")
                        ->execute([$level1['id']]);

                    $pdo->prepare("INSERT INTO referral_bonuses (referrer_id, referee_id, amount, level, created_at) 
                                   VALUES (?, ?, 1300, 1, NOW())")
                        ->execute([$level1['id'], $user_id]);

                    // Level 2
                    if (!empty($level1['referred_by'])) {
                        $stmtLevel2 = $pdo->prepare("SELECT id FROM users WHERE username = ? AND status = 'active'");
                        $stmtLevel2->execute([$level1['referred_by']]);
                        $level2 = $stmtLevel2->fetch();

                        if ($level2) {
                            $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + 1000, total_earned = total_earned + 1000 WHERE id = ?")
                                ->execute([$level2['id']]);

                            $pdo->prepare("INSERT INTO referral_bonuses (referrer_id, referee_id, amount, level, created_at) 
                                           VALUES (?, ?, 1000, 2, NOW())")
                                ->execute([$level2['id'], $user_id]);
                        }
                    }
                }
            }
        }

        http_response_code(200);
        echo json_encode(["message" => "Payment received and processed."]);
    } catch (PDOException $e) {
        error_log("Webhook DB error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["error" => "Server error while processing payment."]);
    }
} else {
    http_response_code(200);
    echo json_encode(["message" => "Payment not successful. Ignored."]);
}
