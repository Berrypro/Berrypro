<?php
session_start();
require 'config.php';

// Session timeout
$inactiveLimit = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $inactiveLimit)) {
    session_unset();
    session_destroy();
    header("Location: signin.php?timeout=1");
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

// Check login
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

// Fetch logged-in user
$stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$currentUser = $stmt->fetch();

if (!$currentUser) {
    session_destroy();
    header('Location: signin.php');
    exit;
}

// Search and pagination
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;
$searchTerm = "%$search%";

// Get Level 1 referrals
$l1Stmt = $pdo->prepare("SELECT username FROM users WHERE referred_by = ?");
$l1Stmt->execute([$currentUser['username']]);
$l1Refs = $l1Stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($l1Refs)) {
    $total = 0;
    $totalPages = 1;
    $referrals = [];
} else {
    $inClause = implode(',', array_fill(0, count($l1Refs), '?'));
    $params = array_merge($l1Refs, [$searchTerm, $searchTerm, $searchTerm]);
    
    // Count
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by IN ($inClause) AND (username LIKE ? OR email LIKE ? OR phone LIKE ?)");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();
    $totalPages = ceil($total / $limit);

    // Fetch referrals
    $params = array_merge($l1Refs, [$searchTerm, $searchTerm, $searchTerm, $limit, $offset]);
    $stmt = $pdo->prepare("SELECT username, phone, email, country, created_at, activated_at, referred_by, status FROM users WHERE referred_by IN ($inClause) AND (username LIKE ? OR email LIKE ? OR phone LIKE ?) ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute($params);
    $referrals = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 2 Referrals</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="level.css">
</head>
<body>

<h2>Level 2 Referrals (<?= $total ?>)</h2>

<form method="get" class="search-box">
    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search by username, phone, or email">
    <button type="submit">Search</button>
</form>

<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Username</th>
            <th>Phone</th>
            <th>Upline</th>
            <th>Country</th>
            <th>Amount Paid</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Activated At</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($referrals)): ?>
            <tr><td colspan="9">No results found.</td></tr>
        <?php else: ?>
            <?php foreach ($referrals as $index => $ref): ?>
                <?php
                if ($ref['status'] === 'active') {
                    $refUsername = $ref['username'];

                    // Check bonus
                    $bonusStmt = $pdo->prepare("SELECT COUNT(*) FROM referral_bonus WHERE referred_id = (SELECT id FROM users WHERE username = ?) AND level = 2");
                    $bonusStmt->execute([$refUsername]);
                    $bonusGiven = $bonusStmt->fetchColumn();

                    // Upline's upline check
                    $l1Upline = $ref['referred_by'];
                    $stmtUU = $pdo->prepare("SELECT referred_by FROM users WHERE username = ?");
                    $stmtUU->execute([$l1Upline]);
                    $uplineUpline = $stmtUU->fetchColumn();

                    if ($uplineUpline === $currentUser['username'] && !$bonusGiven) {
                        // Credit bonus
                        $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + 1000, total_earned = total_earned + 1000 WHERE username = ?")
                            ->execute([$currentUser['username']]);

                        $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at)
                                       VALUES ((SELECT id FROM users WHERE username = ?), (SELECT id FROM users WHERE username = ?), 2, 1000, NOW())")
                            ->execute([$currentUser['username'], $refUsername]);
                    } elseif ($uplineUpline !== $currentUser['username'] && $bonusGiven) {
                        // Revoke bonus
                        $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - 1000, total_earned = total_earned - 1000 WHERE username = ?")
                            ->execute([$currentUser['username']]);

                        $pdo->prepare("DELETE FROM referral_bonus WHERE referred_id = (SELECT id FROM users WHERE username = ?) AND level = 2")
                            ->execute([$refUsername]);
                    }
                }
                ?>
                <tr>
                    <td><?= $offset + $index + 1 ?></td>
                    <td><?= htmlspecialchars($ref['username']) ?></td>
                    <td><?= htmlspecialchars($ref['phone']) ?></td>
                    <td><?= htmlspecialchars($ref['referred_by']) ?></td>
                    <td><?= htmlspecialchars($ref['country']) ?></td>
                    <td>FCFA. <?= $ref['status'] === 'active' ? '1000' : '0' ?></td>
                    <td class="<?= $ref['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                        <?= $ref['status'] === 'active' ? 'Active' : 'Inactive' ?>
                    </td>
                    <td><?= htmlspecialchars($ref['created_at']) ?></td>
                    <td><?= $ref['activated_at'] ?? '-' ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="?search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">Prev</a>
    <?php endif; ?>
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?search=<?= urlencode($search) ?>&page=<?= $i ?>" class="<?= ($i === $page) ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($page < $totalPages): ?>
        <a href="?search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">Next</a>
    <?php endif; ?>
</div>

</body>
</html>
