<?php
session_start();
require_once 'config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user info including referred_by
$stmt = $pdo->prepare("
    SELECT id, phone, email, created_at, referred_by
    FROM Users
    WHERE id = :id
");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

$referred_by = $user['referred_by'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="user, profile">
    <title>User Profile</title>
    <link rel="stylesheet" type="text/css" href="p.css">
    <style>
        body {
            background-color: #0d0b1b;
            color: white;
            font-family: sans-serif;
            padding: 20px;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            text-align: center;
            color: blue;
        }

        h3 {
            text-align: center;
        }

        p span {
            font-weight: bold;
        }

        .container {
            border: 1px solid rgb(89, 89, 219);
            border-radius: 10px;
            padding: 20px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            box-sizing: border-box;
        }
      button {
      background-color: #254aee;
      color: white;
      padding: 8px 14px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 10px;
      text-decoration: none;
    }
    </style>
</head>
<body>
    <h1>FLEXHELA</h1>

    <div class="container">
        <h3>User Profile</h3>
        <p><span>Phone:</span> <?= htmlspecialchars($user['phone']) ?></p>
        <p><span>Email:</span> <?= htmlspecialchars($user['email']) ?></p>
        <p><span>Referred By:</span> <?= $referred_by ? htmlspecialchars($referred_by) : 'None' ?></p>
        <p><span>Joined:</span> <?= htmlspecialchars($user['created_at']) ?></p><br>
      <a href="reset_password.php"><button class="btn" style="display: block; margin: 0 auto">Reset Password</button></a>
    </div>

</body>
</html>
