<?php
session_start();
require 'config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch upline info
$stmt = $pdo->prepare("SELECT username, wallet_balance, deposit_balance, total_earned FROM users WHERE id = ?");
$stmt->execute([$userId]);
$upline = $stmt->fetch();

function getTotalPaid($pdo, $ref_username) {
    // Total paid by upline
    $stmt1 = $pdo->prepare("SELECT COALESCE(SUM(upline_paid), 0) FROM activation_payments WHERE username = ?");
    $stmt1->execute([$ref_username]);
    $paidByUpline = (float)$stmt1->fetchColumn();

    // Total paid by user via payments
    $stmt2 = $pdo->prepare("SELECT COALESCE(SUM(amount_paid), 0) FROM payments 
                            WHERE user_id = (SELECT id FROM users WHERE username = ?) AND status = 'confirmed'");
    $stmt2->execute([$ref_username]);
    $paidByUser = (float)$stmt2->fetchColumn();

    return [$paidByUpline, $paidByUser, $paidByUpline + $paidByUser];
}

// Get 2-level uplines
function getUpline($pdo, $username) {
    $uplineUsernames = [];
    $currentUsername = $username;
    for ($i = 0; $i < 2; $i++) {
        $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE username = ?");
        $stmt->execute([$currentUsername]);
        $referrer = $stmt->fetchColumn();
        if (!$referrer) break;
        $uplineUsernames[] = $referrer;
        $currentUsername = $referrer;
    }
    return $uplineUsernames;
}

$msg = '';
$ref_user = null;
$ref_username = $_POST['ref_username'] ?? '';
$paidByUpline = $paidByUser = $totalPaid = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    if ($ref_username) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'inactive'");
        $stmt->execute([$ref_username]);
        $ref_user = $stmt->fetch();

        if ($ref_user) {
            list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $ref_username);

            // Save total paid into user record
            $pdo->prepare("UPDATE users SET totalpaid = ?, upline_paid = ? WHERE username = ?")
                ->execute([$totalPaid, $paidByUpline, $ref_username]);

            $msg = "User found. Paid by upline: FCFA $paidByUpline. Paid by user: FCFA $paidByUser. Total: FCFA $totalPaid. Remaining: FCFA " . max(0, 3000 - $totalPaid);
        } else {
            $msg = "Referral user not found or already active.";
        }
    } else {
        $msg = "Please enter a username to search.";
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activate'])) {
    $amount = (float)($_POST['amount'] ?? 0);
    $wallet_type = $_POST['wallet_type'] ?? 'wallet_balance';

    if ($ref_username && $amount >= 1 && in_array($wallet_type, ['wallet_balance', 'deposit_balance'])) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'inactive'");
        $stmt->execute([$ref_username]);
        $ref_user = $stmt->fetch();

        $uplineUsernames = getUpline($pdo, $ref_username);
        $referrerIsDirect = $ref_user && $ref_user['referred_by'] === $upline['username'];
        $referrerIsLevel2 = $ref_user && in_array($upline['username'], $uplineUsernames);

        if ($ref_user && ($referrerIsDirect || $referrerIsLevel2)) {
            if ($upline[$wallet_type] >= $amount) {
                // Deduct from upline
                $pdo->prepare("UPDATE users SET $wallet_type = $wallet_type - ? WHERE id = ?")
                    ->execute([$amount, $userId]);

                // Record payment
                $pdo->prepare("INSERT INTO activation_payments (username, upline, upline_paid, status, activated_at)
                               VALUES (?, ?, ?, 'confirmed', NULL)")
                    ->execute([$ref_username, $upline['username'], $amount]);

                // Recalculate totals
                list($paidByUpline, $paidByUser, $totalPaid) = getTotalPaid($pdo, $ref_username);

                // Update user's paid status
                $pdo->prepare("UPDATE users SET upline_paid = ?, totalpaid = ? WHERE username = ?")
                    ->execute([$paidByUpline, $totalPaid, $ref_username]);

if ($totalPaid >= 3000) {
    $pdo->prepare("UPDATE users SET status = 'active', activated_at = NOW() WHERE username = ?")
        ->execute([$ref_username]);

    $pdo->prepare("UPDATE activation_payments SET status = 'activated', activated_at = NOW() WHERE username = ?")
        ->execute([$ref_username]);

    $bonusAmount = 0;
    $level = 0;

    if ($referrerIsDirect) {
        $bonusAmount = 1500;
        $level = 1;
    } elseif ($referrerIsLevel2) {
        $bonusAmount = 1000;
        $level = 2;
    }

    if ($bonusAmount > 0) {
        // Credit bonus
        $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ?, total_earned = total_earned + ? WHERE id = ?")
            ->execute([$bonusAmount, $bonusAmount, $userId]);

        // Log bonus
        $pdo->prepare("INSERT INTO referral_bonus (upline_id, referred_id, level, amount, created_at)
                       VALUES (?, ?, ?, ?, NOW())")
            ->execute([$userId, $ref_user['id'], $level, $bonusAmount]);

        $msg = "FCFA 3000 paid. Referral activated (Level $level). You earned FCFA $bonusAmount bonus.";
    }
        }

                } else {
                    $msg = "Payment of FCFA $amount sent to $ref_username. Total paid so far: FCFA $totalPaid.";
                }
            } else {
                $msg = "Insufficient funds in $wallet_type.";
            }
        } else {
            $msg = "Referral user not found or already active.";
        }
    } else {
        $msg = "Invalid input.";
    }

// Activation history
$stmt = $pdo->prepare("SELECT * FROM activation_payments WHERE upline = ? ORDER BY id DESC");
$stmt->execute([$upline['username']]);
$history = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Activate Referral</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #121212;
            color: #e0e0e0;
            margin: 0;
            padding: 20px;
        }

        h2, h3 {
            text-align: center;
            color: #ffffff;
        }

        .msg {
            text-align: center;
            color: #00e676;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .form-grid {
            max-width: 800px;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .col-12 {
            width: 100%;
        }

        .col-6 {
            width: 48%;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #333;
            border-radius: 5px;
            background-color: #1e1e1e;
            color: #fff;
            font-size: 15px;
        }

        button {
            background-color: #007bff;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 40px auto 0;
            color: #fff;
        }

        th, td {
            padding: 10px;
            border: 1px solid #333;
            text-align: center;
        }

        th {
            background-color: #2c2c2c;
        }

        tr:nth-child(even) {
            background-color: #1b1b1b;
        }

        tr:hover {
            background-color: #333;
        }

        @media (max-width: 768px) {
            .col-6 {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <h2>Activate Referral (Level 1 or 2)</h2>

    <?php if ($msg): ?>
        <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" class="form-grid">
        <div class="col-12">
            <label for="ref_username">Referral Username:</label>
            <input type="text" name="ref_username" id="ref_username" value="<?= htmlspecialchars($ref_username) ?>" required>
        </div>

        <div class="col-12">
            <button type="submit" name="search">Search</button>
        </div>

        <?php if ($ref_user): ?>
            <div class="col-6">
                <label for="amount">Amount to Pay (FCFA):</label>
                <input type="number" step="1" min="1" name="amount" id="amount" required>
            </div>

            <div class="col-6">
                <label for="wallet_type">Select Wallet:</label>
                <select name="wallet_type" id="wallet_type">
                    <option value="wallet_balance">Wallet Balance (FCFA <?= number_format($upline['wallet_balance'], 2) ?>)</option>
                    <option value="deposit_balance">Deposit Balance (FCFA <?= number_format($upline['deposit_balance'], 2) ?>)</option>
                </select>
            </div>

            <div class="col-12">
                <button type="submit" name="activate">Activate</button>
            </div>
        <?php endif; ?>
    </form>

    <h3>Activation History</h3>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Username</th>
                <th>Upline</th>
                <th>Amount Paid</th>
                <th>Status</th>
                <th>Activated At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($history)): ?>
                <tr><td colspan="6">No history found.</td></tr>
            <?php else: ?>
                <?php foreach ($history as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['upline']) ?></td>
                        <td>FCFA <?= number_format($row['upline_paid'], 2) ?></td>
                        <td><?= ucfirst($row['status']) ?></td>
                        <td><?= $row['activated_at'] ?? '—' ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
