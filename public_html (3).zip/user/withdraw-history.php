<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch withdrawal history without 'reason'
$stmt = $pdo->prepare("SELECT amount, fee, wallet_source, status, created_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$withdrawals = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Withdraw History - FlexHela</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1e1e2f;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 15px;
            
        }
        th, td {
            padding: 12px 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            border: solid orange 1px;
        }
        th {
            background: #f5f5f5;
        }
        .status-approved { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-rejected { color: red; font-weight: bold; }

        @media (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead {
                display: none;
            }
            tr {
                margin-bottom: 15px;
                background: #fff;
                padding: 10px;
                border-radius: 6px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            td {
                padding: 8px;
                text-align: right;
                position: relative;
            }
            td::before {
                content: attr(data-label);
                float: left;
                font-weight: bold;
                color: #555;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Withdraw History</h2>
    <?php if (empty($withdrawals)): ?>
        <p>You haven’t made any withdrawals yet.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Amount (KES)</th>
                <th>Charges (KES)</th>
                <th>Wallet</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($withdrawals as $i => $row): ?>
                <tr>
                    <td data-label="No."><?= $i + 1 ?></td>
                    <td data-label="Amount"><?= 'Ksh. ' . number_format($row['amount'], 2) ?></td>
                    <td data-label="Charges"><?= 'Ksh. ' . number_format($row['fee'], 2) ?></td>
                    <td data-label="Wallet"><?= ucwords(str_replace('_', ' ', $row['wallet_source'] ?? 'Unknown')) ?></td>
                    <td data-label="Status" class="status-<?= $row['status'] ?>">
                        <?= ucfirst($row['status']) ?>
                    </td>
                    <td data-label="Date"><?= date('d M Y, H:i', strtotime($row['created_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
</body>
</html>
