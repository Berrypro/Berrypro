<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: users.php');
    exit;
}

$msg = '';

// Fetch user
$stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: users.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($password) || empty($confirm_password)) {
        $msg = "Both password fields are required.";
    } elseif ($password !== $confirm_password) {
        $msg = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $msg = "Password must be at least 6 characters.";
    } else {
        // Hash and update password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashedPassword, $id]);
        $msg = "Password reset successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Reset Password for <?= htmlspecialchars($user['username']) ?></title>
    <style>
        body { font-family: Arial; padding: 20px; }
        form { max-width: 400px; }
        label { display: block; margin-top: 15px; }
        input { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px 15px; }
        .msg { margin-top: 10px; font-weight: bold; color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Reset Password for <?= htmlspecialchars($user['username']) ?></h2>

    <?php if ($msg): ?>
        <div class="<?= strpos($msg, 'successfully') !== false ? 'msg' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" required minlength="6" autocomplete="new-password">

        <label for="confirm_password">Confirm New Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required minlength="6" autocomplete="new-password">

        <button type="submit">Reset Password</button>
    </form>

    <p><a href="users.php">Back to users List</a></p>
</body>
</html>
