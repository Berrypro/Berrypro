this too


<?php
session_start();
require '../config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Handle activate/deactivate/delete actions
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];

    if ($action === 'activate') {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();

        if ($user && $user['status'] !== 'active') {
            $stmt = $pdo->prepare("UPDATE users SET status = 'active', activated_at = NOW() WHERE id = ?");
            $stmt->execute([$id]);

            if (!empty($user['referred_by'])) {
                $level1_bonus = 1500;
                $level2_bonus = 1000;

                $stmt = $pdo->prepare("UPDATE users SET 
                    wallet_balance = wallet_balance + ?,
                    total_earned = total_earned + ?,
                    referrals = referrals + 1
                    WHERE username = ?");
                $stmt->execute([$level1_bonus, $level1_bonus, $user['referred_by']]);

                $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE username = ?");
                $stmt->execute([$user['referred_by']]);
                $level2 = $stmt->fetchColumn();

                if ($level2) {
                    $stmt = $pdo->prepare("UPDATE users SET 
                        wallet_balance = wallet_balance + ?,
                        total_earned = total_earned + ?
                        WHERE username = ?");
                    $stmt->execute([$level2_bonus, $level2_bonus, $level2]);
                }
            }
        }
    } elseif ($action === 'deactivate') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
    }

    header("Location: users.php");
    exit;
}

// Handle update of country and phone
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_contact'])) {
    $user_id = $_POST['user_id'];
    $country = $_POST['country'];
    $phone = $_POST['phone'];

    $stmt = $pdo->prepare("UPDATE users SET country = ?, phone = ? WHERE id = ?");
    $stmt->execute([$country, $phone, $user_id]);

    $_SESSION['update_success'] = "Updated contact details.";
    header("Location: users.php");
    exit;
}

$limit = 15;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$where = '';
$params = [];
if (!empty($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $where = "WHERE username LIKE ? OR email LIKE ? OR phone LIKE ?";
    $params = [$search, $search, $search];
}

$stmt = $pdo->prepare("
    SELECT id, username, email, phone, country, wallet_balance, total_earned, pending, total_withdrawn, status, created_at, referred_by, activated_at
    FROM users
    $where
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute(array_merge($params, [$limit, $offset]));
$users = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users $where");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);

$uplineMsg = $_SESSION['upline_success'] ?? $_SESSION['upline_error'] ?? $_SESSION['update_success'] ?? null;
$uplineMsgColor = isset($_SESSION['upline_error']) ? 'red' : 'green';
unset($_SESSION['upline_success'], $_SESSION['upline_error'], $_SESSION['update_success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - users</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #eee; }
        .pagination a { margin: 0 5px; text-decoration: none; color: blue; }
        .pagination span { margin: 0 5px; font-weight: bold; }
        form { margin-bottom: 20px; }
        input { padding: 6px; }
        button { padding: 6px 12px; }
        .btn { padding: 4px 8px; margin-right: 5px; text-decoration: none; border: 1px solid #666; border-radius: 3px; }
        .btn-edit { background-color: #4CAF50; color: white; }
        .btn-delete { background-color: #f44336; color: white; }
        .btn-activate { background-color: #008CBA; color: white; }
        .btn-deactivate { background-color: #ff9800; color: white; }
    </style>
    <script>
        function confirmAction(action, username) {
            return confirm(`Are you sure you want to ${action} user "${username}"?`);
        }
    </script>
</head>
<body>
    <h1>users</h1>

    <?php if ($uplineMsg): ?>
        <p style="color: <?= $uplineMsgColor ?>;"><?= htmlspecialchars($uplineMsg) ?></p>
    <?php endif; ?>

    <form method="get" action="">
        <input type="text" name="search" placeholder="Search by username, email, or phone" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        <button type="submit">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Country</th>
                <th>Phone</th>
                <th>Wallet (FCFA.)</th>
                <th>Total Earned (FCFA.)</th>
                <th>Pending (FCFA.)</th>
                <th>Withdrawn (FCFA.)</th>
                <th>Upline</th>
                <th>Status</th>
                <th>Registered At</th>
                <th>Activated At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($users)): ?>
            <tr><td colspan="14" style="text-align:center;">No users found.</td></tr>
        <?php else: ?>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= $user['id'] ?></td>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
<td colspan="2">
    <form method="post" style="display: flex; gap: 6px;">
        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
        <input type="text" name="country" value="<?= htmlspecialchars($user['country']) ?>" style="width: 90px;" placeholder="Country">
        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" style="width: 120px;" placeholder="Phone">
        <button type="submit" name="update_contact">Save</button>
    </form>
</td>

                    <td><?= number_format($user['wallet_balance'], 2) ?></td>
                    <td><?= number_format($user['total_earned'], 2) ?></td>
                    <td><?= number_format($user['pending'], 2) ?></td>
                    <td><?= number_format($user['total_withdrawn'], 2) ?></td>
                    <td><?= htmlspecialchars($user['referred_by']) ?></td>
                  
                    <td><?= htmlspecialchars(ucfirst($user['status'])) ?></td>
                    <td><?= $user['created_at'] ?></td>
                    <td><?= $user['activated_at'] ?? '' ?></td>
                    <td>
                        <a class="btn btn-edit" href="edit_user.php?id=<?= $user['id'] ?>">Edit</a>
                        <a class="btn btn-edit" href="reset_password.php?id=<?= $user['id'] ?>">Reset Password</a>
                        <?php if ($user['status'] === 'active'): ?>
                            <a class="btn btn-deactivate" href="?action=deactivate&id=<?= $user['id'] ?>" onclick="return confirmAction('deactivate', '<?= htmlspecialchars($user['username']) ?>')">Deactivate</a>
                        <?php else: ?>
                            <a class="btn btn-activate" href="?action=activate&id=<?= $user['id'] ?>" onclick="return confirmAction('activate', '<?= htmlspecialchars($user['username']) ?>')">Activate</a>
                        <?php endif; ?>
                        <a class="btn btn-delete" href="?action=delete&id=<?= $user['id'] ?>" onclick="return confirmAction('delete', '<?= htmlspecialchars($user['username']) ?>')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination" style="margin-top: 20px;">
        <?php if ($page > 1): ?>
            <a href="?page=1<?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">First</a>
            <a href="?page=<?= $page - 1 ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Previous</a>
        <?php endif; ?>
        <span>Page <?= $page ?> of <?= $totalPages ?></span>
        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Next</a>
            <a href="?page=<?= $totalPages ?><?= !empty($_GET['search']) ? '&search=' . urlencode($_GET['search']) : '' ?>">Last</a>
        <?php endif; ?>
    </div>
</body>
</html>
