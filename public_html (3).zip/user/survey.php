<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if today is a valid survey day (Mon=1, ..., Sun=7)
$validDays = [1, 2, 4, 6]; // M, T, TH, SAT
$currentDay = date('N');

// Fetch survey earnings
$stmt = $pdo->prepare("SELECT survey_balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$survey_balance = number_format($user['survey_balance'], 2);

// Check if already completed today's survey
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT COUNT(*) FROM survey_results WHERE user_id = ? AND DATE(submitted_at) = ?");
$stmt->execute([$user_id, $today]);
$alreadyTaken = $stmt->fetchColumn() > 0;

$surveyAvailable = in_array($currentDay, $validDays);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Take Survey</title>
    <style>
        body { font-family: Arial, sans-serif; background: #1a1a1a; color: #fff; text-align: center; padding: 50px;}
        a.button {
            background: #00b894;
            color: #fff;
            padding: 15px 30px;
            text-decoration: none;
            font-size: 20px;
            border-radius: 8px;
            display: inline-block;
            margin-top: 40px;
        }
        a.button:hover {
            background: #019875;
        }
        .notice {
            margin-top: 20px;
            font-size: 16px;
            color: #facc15;
        }
    </style>
</head>
<body>

<?php
if (isset($_SESSION['survey_message'])) {
    $msg = addslashes($_SESSION['survey_message']);
    echo "<script>alert('$msg');</script>";
    unset($_SESSION['survey_message']);
}
?>

<h1>Welcome to the Daily Survey</h1>
<p><strong>Survey Earnings: FCFA <?= $survey_balance ?></strong></p>

<div class="notice">
    <p><strong>Instructions</strong><br>
    You're going to Answer 10 questions, within 60 Seconds.<br>
    Earn FCFA. 10 per each correct answer.<br>
    Click the Submit button when done. If time elapses before clicking Submit, the test will be submitted automatically.
    </p>
</div>

<?php if ($surveyAvailable && !$alreadyTaken): ?>
    <a href="survey_page.php" class="button">Start Survey</a>
<?php else: ?>
    <script>
        alert("You’ve already completed today’s survey or today is not a valid survey day.\nCome back on MONDAY, TUESDAY, THURSDAY or SATURDAY.");
    </script>
<?php endif; ?>
<br><br><a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
