<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$amount = $input['amount'] ?? 0;
$autoCashout = $input['auto_cashout'] ?? null;
$roundId = $input['round_id'] ?? 0;

try {
    $pdo->beginTransaction();
    
    // 1. Check for existing active bet
    $stmt = $pdo->prepare("SELECT has_active_bet FROM Users WHERE id = ? FOR UPDATE");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if ($user['has_active_bet']) {
        throw new Exception("You already have an active bet", 'ACTIVE_BET_EXISTS');
    }

    // 2. Verify round exists and is active
    $stmt = $pdo->prepare("SELECT id FROM crash_rounds WHERE id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$roundId]);
    if (!$stmt->fetch()) {
        throw new Exception("No active round found", 'INVALID_ROUND');
    }
    
    // 3. Verify user balance (wallet + deposit)
    $stmt = $pdo->prepare("SELECT (wallet_balance + deposit_balance) AS total_balance FROM Users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $balance = $stmt->fetchColumn();
    
    if ($amount < 5 || $amount > 500) {
        throw new Exception("Bet amount must be between KES 5 and 500", 'INVALID_AMOUNT');
    }
    
    if ($balance < $amount) {
        throw new Exception("Insufficient balance", 'INSUFFICIENT_BALANCE');
    }
    
    // 4. Deduct from wallet first, then deposit if needed
    $stmt = $pdo->prepare("SELECT wallet_balance FROM Users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $walletBalance = $stmt->fetchColumn();
    
    if ($walletBalance >= $amount) {
        $stmt = $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance - ?, has_active_bet = TRUE WHERE id = ?");
    } else {
        $remaining = $amount - $walletBalance;
        $stmt = $pdo->prepare("UPDATE Users SET wallet_balance = 0, deposit_balance = deposit_balance - ?, has_active_bet = TRUE WHERE id = ?");
        $amount = $remaining;
    }
    $stmt->execute([$amount, $_SESSION['user_id']]);
    
    // 5. Place bet
    $stmt = $pdo->prepare("
        INSERT INTO crash_bets 
        (user_id, round_id, amount, auto_cashout, status) 
        VALUES (?, ?, ?, ?, 'pending')
    ");
    $stmt->execute([$_SESSION['user_id'], $roundId, $input['amount'], $autoCashout]);
    $betId = $pdo->lastInsertId();
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'bet_id' => $betId,
        'new_balance' => $balance - $input['amount']
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error_code' => $e->getCode() ?: 'UNKNOWN_ERROR'
    ]);
}
?>