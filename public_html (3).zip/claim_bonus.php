<?php
session_start();
require_once 'config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

// Get username for current user
$stmt = $pdo->prepare("SELECT username FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user['username'] ?? '';

if (!$username) {
    echo json_encode(['status' => 'error', 'message' => 'User not found.']);
    exit;
}

// Check if bonus already claimed today
$checkClaim = $pdo->prepare("SELECT id FROM daily_bonus_claims WHERE user_id = ? AND DATE(claim_date) = ?");
$checkClaim->execute([$user_id, $today]);

if ($checkClaim->rowCount() > 0) {
    echo json_encode([
        'status' => 'claimed',
        'message' => "You already claimed today's bonus."
    ]);
    exit;
}

// Count how many referrals activated today
$activatedQuery = $pdo->prepare("
    SELECT COUNT(*) FROM Users 
    WHERE referred_by = ? 
    AND status = 'active'
    AND DATE(activated_at) = ?
");
$activatedQuery->execute([$username, $today]);
$activated_today = (int)$activatedQuery->fetchColumn();

// Handle GET request (checking eligibility)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($activated_today >= 10) {
        echo json_encode([
            'status' => 'ready',
            'message' => 'Target met! Claim your bonus.',
            'count' => $activated_today
        ]);
    } else {
        echo json_encode([
            'status' => 'wait',
            'message' => "You need 10 activated referrals today. You have $activated_today.",
            'count' => $activated_today
        ]);
    }
    exit;
}

// Handle POST request (claiming bonus)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($activated_today < 10) {
        echo json_encode([
            'status' => 'error',
            'message' => 'You haven’t met today’s referral target.'
        ]);
        exit;
    }

    // Insert claim into claims table
    $insert = $pdo->prepare("INSERT INTO daily_bonus_claims (user_id, claim_date) VALUES (?, NOW())");
    $insert->execute([$user_id]);

    // Credit bonus to user's wallet
    $bonusAmount = 30;
    $update = $pdo->prepare("UPDATE Users SET wallet_balance = wallet_balance + ? WHERE id = ?");
    $update->execute([$bonusAmount, $user_id]);

    echo json_encode([
        'status' => 'success',
        'message' => 'Congratulations, Bonus claimed successfully. You have earned KES. 30, come again tomorrow!'
    ]);
    exit;
}
?>
