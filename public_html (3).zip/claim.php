<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM Users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: signin.php');
    exit;
}

$activated_referrals = (int)$user['activated_referrals'];
$welcome_bonus = $user['welcome_bonus'] ?? 0;
$wallet_balance = $user['wallet_balance'] ?? 0;
$total_earned = $user['total_earned'] ?? 0;

$min_referrals_needed = 20;
$remaining = max(0, $min_referrals_needed - $activated_referrals);

$message = '';
$error = false;
$already_claimed = false;

// Check if already claimed from DB table (optional double check)
$checkClaim = $pdo->prepare("SELECT * FROM welcome_bonus_claims WHERE user_id = ?");
$checkClaim->execute([$user_id]);
$claimExists = $checkClaim->fetch();

if ($claimExists || $welcome_bonus <= 0) {
    $already_claimed = true;
}

// Handle claim submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$already_claimed) {
    if ($activated_referrals < $min_referrals_needed) {
        $error = true;
        $message = "You need {$remaining} more activated referrals to claim your welcome bonus.";
    } elseif ($welcome_bonus <= 0) {
        $error = true;
        $message = "Welcome bonus already claimed or unavailable.";
    } else {
        // Update user's balances
        $new_wallet_balance = $wallet_balance + $welcome_bonus;
        $new_total_earned = $total_earned + $welcome_bonus;

        $update = $pdo->prepare("UPDATE Users SET wallet_balance = ?, total_earned = ?, welcome_bonus = 0 WHERE id = ?");
        $success = $update->execute([$new_wallet_balance, $new_total_earned, $user_id]);

        if ($success) {
            // Insert into bonus claims table
            $log = $pdo->prepare("INSERT INTO welcome_bonus_claims (user_id, amount_claimed) VALUES (?, ?)");
            $log->execute([$user_id, $welcome_bonus]);

            $message = "Welcome bonus of Ksh. " . number_format($welcome_bonus, 2) . " successfully claimed and added to your wallet.";
            $already_claimed = true; // Mark as claimed
        } else {
            $error = true;
            $message = "Error processing your claim. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Claim Welcome Bonus</title>
<link rel="stylesheet" href="css.css" />
<style>
  .container {
    max-width: 500px;
    margin: 40px auto;
    padding: 20px;
    border: 1px solid rgb(89, 89, 219);
    border-radius: 10px;
    background-color: #12111f;
    color: white;
    font-family: sans-serif;
  }
  button {
    padding: 10px 20px;
    background-color: #22c55e;
    border: none;
    border-radius: 5px;
    color: black;
    font-weight: bold;
    cursor: pointer;
    margin-top: 20px;
  }
  button:disabled {
    background-color: gray;
    cursor: not-allowed;
  }
  .message {
    padding: 10px;
    margin-top: 10px;
    border-radius: 5px;
  }
  .error {
    background-color: #e63946;
    color: white;
  }
  .success {
    background-color: #22c55e;
    color: black;
  }
  #notify {
    background-color: orange;
    color: black;
    padding: 10px;
    border-radius: 5px;
    margin-top: 15px;
    font-weight: bold;
  }
</style>
</head>
<body>
  <div class="container">
    <h2>Claim Your Welcome Bonus</h2>

    <p>Activated Referrals: <strong><?= (int)$activated_referrals ?></strong></p>
    <p>Minimum required referrals: <strong>20</strong></p>
    <p>Welcome Bonus Available: <strong>Ksh. <?= number_format($welcome_bonus, 2) ?></strong></p>

    <?php if ($remaining > 0 && !$already_claimed): ?>
      <p>You need <strong><?= $remaining ?></strong> more activated referrals to claim your welcome bonus.</p>
    <?php endif; ?>

    <?php if ($message): ?>
      <div class="message <?= $error ? 'error' : 'success' ?>">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <?php if ($already_claimed): ?>
      <div id="notify">You have already claimed your welcome bonus.</div>
    <?php endif; ?>

    <form id="claimForm" method="post">
      <button type="submit" <?= ($activated_referrals < $min_referrals_needed || $already_claimed) ? 'disabled' : '' ?>>
        Claim Welcome Bonus
      </button>
    </form>

    <p style="margin-top:20px;">
      <a href="dashboard.php" style="color:#22c55e;">&larr; Back to Dashboard</a>
    </p>
  </div>
</body>
</html>
