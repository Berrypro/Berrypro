<?php
session_start();
require_once 'config.php';

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function sendEmail($to, $subject, $message) {
    $headers = "From: no-reply@flexhela.com\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    return mail($to, $subject, $message, $headers);
}

function cleanInput($data) {
    return htmlspecialchars(trim((string) $data), ENT_QUOTES, 'UTF-8');
}

$error = '';
$success = false;
$referred_by = $_SERVER["REQUEST_METHOD"] === "POST"
    ? cleanInput($_POST['referred_by'] ?? '')
    : cleanInput($_GET['ref'] ?? '');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid form submission.";
    } else {
        $username = cleanInput($_POST['username'] ?? '');
        $email = cleanInput($_POST['email'] ?? '');
        $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');
        $password_raw = $_POST['password'] ?? '';

        // Fixed bonuses
        $capital = 100;
        $welcome_bonus = 20;

        if (!$username || !$email || !$phone || !$password_raw) {
            $error = "All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } elseif (!preg_match('/^[a-zA-Z0-9]{3,10}$/', $username)) {
            $error = "Username must be 3-10 characters long and contain only letters and numbers.";
        } elseif (strlen($password_raw) < 4) {
            $error = "Password must be at least 4 characters long.";
        } else {
            $password = password_hash($password_raw, PASSWORD_DEFAULT);
            if ($username === $referred_by) {
                $referred_by = null;
            }

            $stmt = $pdo->prepare("SELECT id FROM Users WHERE username = :username OR email = :email");
            $stmt->execute(['username' => $username, 'email' => $email]);

            if ($stmt->rowCount() > 0) {
                $error = "Username or email already taken.";
            } else {
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare("INSERT INTO Users 
                        (username, email, phone, password, capital, welcome_bonus, total_earned, wallet_balance, referred_by, status, created_at) 
                        VALUES (:username, :email, :phone, :password, :capital, :welcome_bonus, :total_earned, 0, :referred_by, 'inactive', NOW())");

                    $success = $stmt->execute([
                        'username' => $username,
                        'email' => $email,
                        'phone' => $phone,
                        'password' => $password,
                        'capital' => $capital,
                        'welcome_bonus' => $welcome_bonus,
                        'total_earned' => $welcome_bonus,
                        'referred_by' => $referred_by
                    ]);

               if ($success) {
    $subject = "🎉 Welcome to Flexhela, $username!";
    $message = "
        <div style='font-family: Arial, sans-serif; line-height: 1.6;'>
            <h2 style='color: #2c3e50;'>Hi $username 👋</h2>
            <p>Thanks for joining <strong>Flexhela</strong>!</p>
            <p>You’ve received your free <strong>KES 20 Welcome Bonus</strong>.</p>
            <p>Now you can:</p>
            <ul>
                <li>📱Do surveys and Earn</li>
                <li>🎯 Play Crash Game and Earn</li>
                <li>💵 Pay for others to join</li>
                <li>📱 Deposit easily via MPESA</li>
                <li>🎯 Get activated and start earning</li>
            </ul>
            <p style='margin-top: 20px;'>👉 <a href='https://flexhela.com/signin.php'>Login now</a> to get started!</p>
            <br>
            <p style='font-size: 14px; color: #888;'>This is an automated message. Do not reply.</p>
        </div>
    ";

    sendEmail($email, $subject, $message);

    $pdo->commit();
    $_SESSION['registration_success'] = true;
    header("Location: signin.php");
    exit;
}

                } catch (PDOException $e) {
                    $pdo->rollBack();
                    error_log("DB error: " . $e->getMessage());
                    $error = "Failed to create account. Try again.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Join Flexhela | Sign Up</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
  <div class="form-container">
    <h1>FLEXHELA</h1>
    <p class="title">Create your new account</p>

    <?php if (!empty($error)): ?>
      <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="signup.php" method="POST" novalidate>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
      <input type="hidden" name="referred_by" value="<?= htmlspecialchars($referred_by ?? '') ?>">

      <label for="username">Username</label>
      <input type="text" id="username" name="username" required 
             value="<?= htmlspecialchars($username ?? '') ?>"
             pattern="[a-zA-Z0-9]{3,10}" title="3-10 letters or numbers only">

      <label for="email">Email</label>
      <input type="email" id="email" name="email" required 
             value="<?= htmlspecialchars($email ?? '') ?>">

      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" required value="<?= htmlspecialchars($phone ?? '') ?>">
      <p class="info-text">We will pay you through this number.</p>

      <label for="password">Password (min 4 characters)</label>
      <div class="password-container">
        <input type="password" id="password" name="password" required minlength="4">
        <span onclick="togglePassword()">Show</span>
      </div>

      <button class="btn" type="submit">Sign up</button>
    </form>

    <div class="login-link">
      Already registered? <a href="signin.php">Log in</a>
    </div>
  </div>

<script>
function togglePassword() {
  const passwordField = document.getElementById("password");
  const toggle = passwordField.nextElementSibling;
  if (passwordField.type === "password") {
    passwordField.type = "text";
    toggle.textContent = "Hide";
  } else {
    passwordField.type = "password";
    toggle.textContent = "Show";
  }
}
</script>

</body>
</html>
