<?php
session_start();
require 'config.php';

// Session timeout (10 minutes)
$inactiveLimit = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $inactiveLimit)) {
    session_unset();
    session_destroy();
    header("Location: signin.php?timeout=1");
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

// Check login
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit;
}

// Fetch logged-in user
$stmt = $pdo->prepare("SELECT username FROM Users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$currentUser = $stmt->fetch();

if (!$currentUser) {
    session_destroy();
    header('Location: signin.php');
    exit;
}

// Search and Pagination setup
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;
$searchTerm = "%$search%";

// Count total referrals
$countStmt = $pdo->prepare("
    SELECT COUNT(*) FROM Users 
    WHERE referred_by = ? 
    AND (username LIKE ? OR email LIKE ? OR phone LIKE ?)
");
$countStmt->execute([$currentUser['username'], $searchTerm, $searchTerm, $searchTerm]);
$total = $countStmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Fetch Level 1 referrals
$stmt = $pdo->prepare("
    SELECT username, phone, email, created_at, activated_at, referred_by, status
    FROM Users 
    WHERE referred_by = ? 
    AND (username LIKE ? OR email LIKE ? OR phone LIKE ?)
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$currentUser['username'], $searchTerm, $searchTerm, $searchTerm, $limit, $offset]);
$referrals = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Level 1 Referrals</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="level.css">
</head>
<body>

    <h2>Level 1 Referrals (<?= $total ?>)</h2><br>
     <a href="dashboard.php" style="color:green;">← Back to Dashboard</a><br><br>

    <form method="get" class="search-box">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search by username, phone, or email">
        <button type="submit">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Username</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Earned</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($referrals)): ?>
                <tr><td colspan="9">No results found.</td></tr>
            <?php else: ?>
                <?php foreach ($referrals as $index => $ref): ?>
                    <tr>
                        <td><?= $offset + $index + 1 ?></td>
                        <td><?= htmlspecialchars($ref['username']) ?></td>
                        <td><?= htmlspecialchars($ref['phone']) ?></td>
                        <td class="<?= $ref['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                            <?= $ref['status'] === 'active' ? 'Active' : 'Inactive' ?>
                        </td>
                        <td>Ksh. <?= $ref['status'] === 'active' ? '50' : '0' ?></td>
                        <td><?= htmlspecialchars($ref['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">Prev</a>
        <?php endif; ?>
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?search=<?= urlencode($search) ?>&page=<?= $i ?>" class="<?= ($i === $page) ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if ($page < $totalPages): ?>
            <a href="?search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">Next</a>
        <?php endif; ?>
    </div>

</body>
</html>
