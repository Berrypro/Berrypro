<?php
$survey_sets = [

    // Set 1
    [
        [
            "question" => "What is the capital city of Kenya?",
            "options" => ["Nairobi", "Mombasa", "Kisumu", "Eldoret"],
            "correct" => 0
        ],
        [
            "question" => "Which tribe is known for long-distance running in Kenya?",
            "options" => ["Kikuyu", "Luhya", "Kalenjin", "Luo"],
            "correct" => 2
        ],
        [
            "question" => "Which is the main port city in Kenya?",
            "options" => ["Nairobi", "Mombasa", "Malindi", "Kisumu"],
            "correct" => 1
        ],
        [
            "question" => "Who was the first President of Kenya?",
            "options" => ["Jomo Kenyatta", "Daniel Moi", "Mwai Kibaki", "Uhuru Kenyatta"],
            "correct" => 0
        ],
        [
            "question" => "Which year did Kenya gain independence?",
            "options" => ["1960", "1963", "1970", "1952"],
            "correct" => 1
        ],
        [
            "question" => "What is the currency used in Kenya?",
            "options" => ["Dollar", "Euro", "Shilling", "Pound"],
            "correct" => 2
        ],
        [
            "question" => "Which lake borders Kenya to the west?",
            "options" => ["Lake Victoria", "Lake Turkana", "Lake Naivasha", "Lake Elementaita"],
            "correct" => 0
        ],
        [
            "question" => "What is Kenya's national animal?",
            "options" => ["Lion", "Elephant", "Buffalo", "Giraffe"],
            "correct" => 0
        ],
        [
            "question" => "What does MPESA stand for?",
            "options" => ["Mobile Payment Services", "Mobile Pesa", "Money Postal Service", "Mobile Personal Account"],
            "correct" => 0
        ],
        [
            "question" => "Which of these is a Kenyan national park?",
            "options" => ["Kruger", "Tsavo", "Serengeti", "Maasai Mara"],
            "correct" => 3
        ]
    ],

    // Set 2
    [
        [
            "question" => "What is the official language of Kenya?",
            "options" => ["Swahili", "English", "French", "Arabic"],
            "correct" => 1
        ],
        [
            "question" => "Who is Kenya’s deputy president (as of 2024)?",
            "options" => ["Raila Odinga", "Rigathi Gachagua", "Kalonzo Musyoka", "Musalia Mudavadi"],
            "correct" => 1
        ],
        [
            "question" => "Which desert is found in northern Kenya?",
            "options" => ["Chalbi", "Sahara", "Kalahari", "Danakil"],
            "correct" => 0
        ],
        [
            "question" => "What does IEBC stand for?",
            "options" => ["Independent Electoral and Boundaries Commission", "Internal Elections Board Committee", "Institute of Electoral Board Commission", "International Electoral Board Council"],
            "correct" => 0
        ],
        [
            "question" => "Which is the largest county in Kenya by land area?",
            "options" => ["Turkana", "Marsabit", "Garissa", "Wajir"],
            "correct" => 1
        ],
        [
            "question" => "What does the color black on the Kenyan flag represent?",
            "options" => ["Peace", "People", "Land", "Freedom"],
            "correct" => 1
        ],
        [
            "question" => "Which river is the longest in Kenya?",
            "options" => ["Athi", "Ewaso Nyiro", "Tana", "Mara"],
            "correct" => 2
        ],
        [
            "question" => "Which Kenyan town is famous for tea farming?",
            "options" => ["Eldoret", "Kericho", "Naivasha", "Nakuru"],
            "correct" => 1
        ],
        [
            "question" => "Who was the third President of Kenya?",
            "options" => ["Mwai Kibaki", "Uhuru Kenyatta", "Jomo Kenyatta", "Daniel Moi"],
            "correct" => 0
        ],
        [
            "question" => "Which of the following is a Kenyan mobile network operator?",
            "options" => ["Airtel", "MTN", "Vodacom", "Telkom"],
            "correct" => 0
        ]
    ],

    // Set 3
    [
        [
            "question" => "Which Kenyan mountain is the highest?",
            "options" => ["Mt. Elgon", "Mt. Longonot", "Mt. Kenya", "Mt. Kilimanjaro"],
            "correct" => 2
        ],
        [
            "question" => "Which ocean borders Kenya to the east?",
            "options" => ["Atlantic", "Pacific", "Indian", "Southern"],
            "correct" => 2
        ],
        [
            "question" => "In which year did the new Kenyan constitution get promulgated?",
            "options" => ["2005", "2010", "2013", "2008"],
            "correct" => 1
        ],
        [
            "question" => "Which city hosts the headquarters of the United Nations in Africa?",
            "options" => ["Addis Ababa", "Cairo", "Nairobi", "Lagos"],
            "correct" => 2
        ],
        [
            "question" => "Who leads the opposition in Kenya (as of 2024)?",
            "options" => ["Uhuru Kenyatta", "William Ruto", "Raila Odinga", "Kalonzo Musyoka"],
            "correct" => 2
        ],
        [
            "question" => "Which flower crop is Kenya known for exporting?",
            "options" => ["Roses", "Lilies", "Sunflowers", "Orchids"],
            "correct" => 0
        ],
        [
            "question" => "Which holiday is celebrated on 12th December in Kenya?",
            "options" => ["Labor Day", "Madaraka Day", "Mashujaa Day", "Jamhuri Day"],
            "correct" => 3
        ],
        [
            "question" => "What is the traditional Maasai clothing called?",
            "options" => ["Dashiki", "Shuka", "Kitenge", "Kanzu"],
            "correct" => 1
        ],
        [
            "question" => "Which famous Kenyan athlete broke the 2-hour marathon barrier?",
            "options" => ["David Rudisha", "Wilson Kipsang", "Eliud Kipchoge", "Paul Tergat"],
            "correct" => 2
        ],
        [
            "question" => "Which is the most spoken native language in Kenya?",
            "options" => ["Kikuyu", "Luo", "Swahili", "Kalenjin"],
            "correct" => 0
        ]
    ],

    // Set 4
    [
        [
            "question" => "What does 'Harambee' mean in Kenya's national context?",
            "options" => ["Pulling together", "Celebration", "Freedom", "Victory"],
            "correct" => 0
        ],
        [
            "question" => "Which is the smallest county in Kenya by area?",
            "options" => ["Mombasa", "Nairobi", "Kisumu", "Vihiga"],
            "correct" => 0
        ],
        [
            "question" => "What year did Kenya gain independence?",
            "options" => ["1963", "1960", "1978", "1952"],
            "correct" => 0
        ],
        [
            "question" => "Who is the Chief Justice of Kenya as of 2023?",
            "options" => ["Martha Koome", "Willy Mutunga", "David Maraga", "Mutula Kilonzo"],
            "correct" => 0
        ],
        [
            "question" => "What does the colour green in the Kenyan flag represent?",
            "options" => ["Agriculture", "Blood", "Peace", "Unity"],
            "correct" => 0
        ],
        [
            "question" => "Which Kenyan town is known for tea production?",
            "options" => ["Kericho", "Eldoret", "Nakuru", "Nyeri"],
            "correct" => 0
        ],
        [
            "question" => "What body oversees elections in Kenya?",
            "options" => ["IEBC", "EACC", "DCI", "NCIC"],
            "correct" => 0
        ],
        [
            "question" => "Which community is known for the bullfighting culture?",
            "options" => ["Luhya", "Kalenjin", "Maasai", "Kikuyu"],
            "correct" => 0
        ],
        [
            "question" => "Which lake lies between Kenya and Tanzania?",
            "options" => ["Lake Victoria", "Lake Naivasha", "Lake Turkana", "Lake Elementaita"],
            "correct" => 0
        ],
        [
            "question" => "Which is the largest game reserve in Kenya?",
            "options" => ["Tsavo", "Maasai Mara", "Amboseli", "Meru"],
            "correct" => 0
        ],
    ],

    // Set 5
    [
        [
            "question" => "Who was the first African woman to win a Nobel Peace Prize?",
            "options" => ["Wangari Maathai", "Martha Karua", "Ngina Kenyatta", "Charity Ngilu"],
            "correct" => 0
        ],
        [
            "question" => "Which Kenyan currency note features a giraffe?",
            "options" => ["1000", "100", "200", "500"],
            "correct" => 0
        ],
        [
            "question" => "Which sport is Kenya best known for globally?",
            "options" => ["Long-distance running", "Boxing", "Swimming", "Cricket"],
            "correct" => 0
        ],
        [
            "question" => "What is the capital of Turkana County?",
            "options" => ["Lodwar", "Maralal", "Kapenguria", "Wajir"],
            "correct" => 0
        ],
        [
            "question" => "Which company runs the Nairobi Expressway?",
            "options" => ["Moja Expressway", "KURA", "China Wu Yi", "KeNHA"],
            "correct" => 0
        ],
        [
            "question" => "Which river is the longest in Kenya?",
            "options" => ["Tana River", "Athi River", "Ewaso Nyiro", "Yala River"],
            "correct" => 0
        ],
        [
            "question" => "Which island in Kenya is a UNESCO World Heritage Site?",
            "options" => ["Lamu", "Mombasa", "Wasini", "Funzi"],
            "correct" => 0
        ],
        [
            "question" => "What does KRA stand for?",
            "options" => ["Kenya Revenue Authority", "Kenya Roads Authority", "Kenya Resource Agency", "Kenya Railways Association"],
            "correct" => 0
        ],
        [
            "question" => "Which is a key cash crop grown in Central Kenya?",
            "options" => ["Coffee", "Sugarcane", "Maize", "Sorghum"],
            "correct" => 0
        ],
        [
            "question" => "Which tribe predominantly inhabits Marsabit County?",
            "options" => ["Rendille", "Luo", "Kamba", "Taita"],
            "correct" => 0
        ],
    ],

    // Set 6
    [
        [
            "question" => "What does the Judiciary arm of government do?",
            "options" => ["Interprets the law", "Makes laws", "Implements policies", "Collects taxes"],
            "correct" => 0
        ],
        [
            "question" => "Which wildlife animal is featured on the 50 KES coin?",
            "options" => ["Lion", "Elephant", "Rhino", "Buffalo"],
            "correct" => 0
        ],
        [
            "question" => "Who was Kenya’s third president?",
            "options" => ["Mwai Kibaki", "Uhuru Kenyatta", "Daniel Moi", "William Ruto"],
            "correct" => 0
        ],
        [
            "question" => "Which language is taught as a subject in most Kenyan schools?",
            "options" => ["Kiswahili", "French", "German", "Arabic"],
            "correct" => 0
        ],
        [
            "question" => "In which year did the new Kenyan constitution come into effect?",
            "options" => ["2010", "2005", "2013", "2008"],
            "correct" => 0
        ],
        [
            "question" => "What is the main airport in Nairobi?",
            "options" => ["JKIA", "Wilson", "Moi International", "Eldoret Airport"],
            "correct" => 0
        ],
        [
            "question" => "Which sea borders Kenya?",
            "options" => ["Indian Ocean", "Atlantic Ocean", "Red Sea", "Mediterranean Sea"],
            "correct" => 0
        ],
        [
            "question" => "What is Huduma Namba used for?",
            "options" => ["National identification", "Healthcare", "Voting", "Tax filing"],
            "correct" => 0
        ],
        [
            "question" => "Which Kenyan musician is known for 'Unbwogable'?",
            "options" => ["Gidi Gidi Maji Maji", "Nameless", "Bahati", "Nyashinski"],
            "correct" => 0
        ],
        [
            "question" => "What is the two-third gender rule about?",
            "options" => ["Gender representation in public offices", "School admission", "Election funding", "Land ownership"],
            "correct" => 0
        ],
    ],

];

// 2. Select the set for the day
$day_of_year = date('z'); // 0 to 365
$set_index = $day_of_year % count($survey_sets);
$selected_set = $survey_sets[$set_index];

// 3. Shuffle questions and options within the selected set
shuffle($selected_set);
foreach ($selected_set as &$question) {
    $options = $question['options'];
    $correct_answer = $options[$question['correct']];
    shuffle($options);
    $new_correct_index = array_search($correct_answer, $options);
    $question['options'] = $options;
    $question['correct'] = $new_correct_index;
}
unset($question);

// 4. Output or render the questions

// If your endpoint returns JSON data (for AJAX/fetch):
header('Content-Type: application/json');
echo json_encode($selected_set);
exit;

function getRandomizedQuestions($questions) {
    shuffle($questions);
    foreach ($questions as &$q) {
        $correctAnswerText = $q['options'][$q['correct']];
        shuffle($q['options']);
        $q['correct'] = array_search($correctAnswerText, $q['options']);
    }
    unset($q);
    return $questions;
}
?>

