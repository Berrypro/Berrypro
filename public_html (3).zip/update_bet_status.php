<?php
session_start();
require 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$betId = $input['bet_id'] ?? 0;
$status = $input['status'] ?? '';

if (!in_array($status, ['cashed_out', 'crashed'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit();
}

try {
    $pdo->beginTransaction();
    
    // Verify bet belongs to user
    $stmt = $pdo->prepare("SELECT id FROM crash_bets WHERE id = ? AND user_id = ? FOR UPDATE");
    $stmt->execute([$betId, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        throw new Exception("Bet not found or doesn't belong to user");
    }
    
    // Update status
    $stmt = $pdo->prepare("UPDATE crash_bets SET status = ? WHERE id = ?");
    $stmt->execute([$status, $betId]);
    
    // If crashed, ensure no payout is set
    if ($status === 'crashed') {
        $stmt = $pdo->prepare("UPDATE crash_bets SET payout = 0 WHERE id = ?");
        $stmt->execute([$betId]);
    }
    
    $pdo->commit();
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>