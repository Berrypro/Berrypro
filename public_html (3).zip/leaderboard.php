<?php
require 'config.php';

// Top 10 winners by payout
$stmt = $pdo->query("
  SELECT users.username, w.payout, w.multiplier, w.won_at
  FROM crash_winners w
  JOIN users ON users.id = w.user_id
  ORDER BY w.payout DESC
  LIMIT 10
");

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<div class='bg-gray-900 p-4 rounded mt-6'>";
echo "<h3 class='text-orange-400 font-bold mb-2'>Top Winners</h3>";
echo "<table class='w-full text-sm'>";
echo "<thead><tr><th>User</th><th>Payout</th><th>x</th><th>Time</th></tr></thead><tbody>";

foreach ($rows as $row) {
    echo "<tr class='border-t border-gray-700'>";
    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
    echo "<td>Ksh. " . number_format($row['payout'], 2) . "</td>";
    echo "<td>" . $row['multiplier'] . "x</td>";
    echo "<td>" . date("H:i", strtotime($row['won_at'])) . "</td>";
    echo "</tr>";
}

echo "</tbody></table></div>";
